/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.datastore.utils;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import com.kpmg.registration.constants.RegistrationConstants;

public class LdapHelper
{

	@SuppressWarnings("rawtypes")
	private Hashtable ldapEnvironment = new Hashtable();

	@SuppressWarnings({ "unchecked" })
	public LdapHelper(LdapInfo ldapConnection)
	{
		ldapEnvironment.put(Context.INITIAL_CONTEXT_FACTORY, RegistrationConstants.LDAP_CTX_FACTORY);
		ldapEnvironment.put(Context.SECURITY_AUTHENTICATION, RegistrationConstants.SIMPLE);
		ldapEnvironment.put(Context.SECURITY_PRINCIPAL, ldapConnection.getPrincipal());
		ldapEnvironment.put(Context.SECURITY_CREDENTIALS, ldapConnection.getCredentials());
		ldapEnvironment.put(Context.PROVIDER_URL, ldapConnection.getServerUrl());
	}

	public Boolean deleteEntry(String dn) throws NamingException
	{
		try
		{
			// Create the initial directory context
			LdapContext ctx = new InitialLdapContext(ldapEnvironment, null);
			ctx.destroySubcontext(dn);
			ctx.close();
			return true;

		}
		catch (NamingException e)
		{
			System.err.println("Problem creating user: " + e);
			throw e;
		}
	}

	/**
	 * Add LDAP entry
	 * 
	 * @param dn
	 * @param defaultAttributes
	 * @return
	 */
	public Boolean addEntry(String dn, HashMap<String, String> defaultAttributes)
	{
		try
		{
			BasicAttributes attributesToAdd = new BasicAttributes();
			Attribute objectClass = new BasicAttribute(RegistrationConstants.OBJECT_CLASS);
			objectClass.add(RegistrationConstants.TOP);
			objectClass.add(RegistrationConstants.PERSON);
			objectClass.add(RegistrationConstants.ORGANIZATIONAL_PERSON);
			objectClass.add(RegistrationConstants.INET_ORG_PERSON);
			objectClass.add(RegistrationConstants.BEIS_PERSON);

			attributesToAdd.put(objectClass);

			for (Map.Entry<String, String> e : defaultAttributes.entrySet())
			{
				attributesToAdd.put(new BasicAttribute(e.getKey(), e.getValue()));
			}
			// Create the initial directory context
			LdapContext ldapContext = new InitialLdapContext(ldapEnvironment, null);
			ldapContext.createSubcontext(dn, attributesToAdd);
			ldapContext.close();
			return true;

		}
		catch (NamingException e)
		{
			System.err.println("Problem creating user: " + e);
		}

		return false;
	}

	/**
	 * search and return LDAP entry
	 * 
	 * @throws NamingException
	 */
	public Attributes searchEntry(String searchDn, String uid) throws NamingException
	{
		Attributes ldapAttributes = null;
		SearchControls searchControls = new SearchControls();
		searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);

		LdapContext ldapContext = new InitialLdapContext(ldapEnvironment, null);
		NamingEnumeration<SearchResult> resultEnum = ldapContext.search(searchDn, "(uid=" + uid + ")", searchControls);

		while (resultEnum.hasMore())
		{
			SearchResult searchResult = resultEnum.next();
			ldapAttributes = searchResult.getAttributes();
		}
		ldapContext.close();
		return ldapAttributes;
	}

	/**
	 * modify LDAP entry
	 * 
	 * @throws NamingException
	 */
	public boolean modifyEntry(String dn, List<Attribute> atrributeListToBeUpdated) throws NamingException
	{
		LdapContext ldapContext = new InitialLdapContext(ldapEnvironment, null);
		ModificationItem[] modificationItems = new ModificationItem[atrributeListToBeUpdated.size()];
		int i = 0;
		for (Attribute atrributeToBeUpdated : atrributeListToBeUpdated)
		{
			modificationItems[i++] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, atrributeToBeUpdated);
		}
		ldapContext.modifyAttributes(dn, modificationItems);
		ldapContext.close();
		return false;
	}
	
	/**
	 * modify LDAP entry
	 * 
	 * @throws NamingException
	 */
	public boolean removeEntry(String dn, List<Attribute> atrributeListToBeRemoved) throws NamingException
	{
		LdapContext ldapContext = new InitialLdapContext(ldapEnvironment, null);
		ModificationItem[] modificationItems = new ModificationItem[atrributeListToBeRemoved.size()];
		int i = 0;
		for (Attribute atrributeToBeRemoved : atrributeListToBeRemoved)
		{
			modificationItems[i++] = new ModificationItem(DirContext.REMOVE_ATTRIBUTE, atrributeToBeRemoved);
		}
		ldapContext.modifyAttributes(dn, modificationItems);
		ldapContext.close();
		return false;
	}
	
	public SearchResult findUserIfExists(String searchBase, String pid, String lastName, String postcode, String dateOfBirth) throws ParseException, NamingException 
	{
		SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        LdapContext ldapContext = new InitialLdapContext(ldapEnvironment, null);		
		String searchFilter = "(|(uniqueIdentifier="+pid+")(&(objectClass=beisPerson)(sn=" + lastName + ")(postalCode=" + postcode + ")(dateOfBirth="+dateOfBirth+")))";
		
		NamingEnumeration<SearchResult> results = ldapContext.search(searchBase, searchFilter, searchControls);

        SearchResult searchResult = null;
        if(results.hasMoreElements()) {
             searchResult = (SearchResult) results.nextElement();

            //make sure there is not another item available, there should be only 1 match
            if(results.hasMoreElements()) {
                System.err.println("Matched multiple users for the lastName: " + lastName+", postal code: "+postcode+", dateOfBirth: "+dateOfBirth);
                return null;
            }
        }
        
        return searchResult;
	}
	
	public SearchResult findUserIfExistsWithMatchingUniqueIdentitfier(String searchBase, String uniqueIdentifier) throws ParseException, NamingException 
	{
		SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        LdapContext ldapContext = new InitialLdapContext(ldapEnvironment, null);		
		String searchFilter = "(&(objectClass=beisPerson)(uniqueIdentifier=" + uniqueIdentifier + "))";
		
		NamingEnumeration<SearchResult> results = ldapContext.search(searchBase, searchFilter, searchControls);

        SearchResult searchResult = null;
        if(results.hasMoreElements()) {
             searchResult = (SearchResult) results.nextElement();

            //make sure there is not another item available, there should be only 1 match
            if(results.hasMoreElements()) {
                System.err.println("Matched multiple users for the uniqueIdentifier: " + uniqueIdentifier);
                return null;
            }
        }
        
        return searchResult;
	}
	
	public SearchResult findUserIfExistsWithMatchingUniqueIdentitfier(String searchBase, String pid, String lastName, String dateOfBirth) throws ParseException, NamingException 
	{
		SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        LdapContext ldapContext = new InitialLdapContext(ldapEnvironment, null);		
		String searchFilter = "(&(objectClass=beisPerson)(sn=" + lastName + ")(dateOfBirth="+dateOfBirth+")(uniqueIdentifier="+pid+"))";
		
		NamingEnumeration<SearchResult> results = ldapContext.search(searchBase, searchFilter, searchControls);

        SearchResult searchResult = null;
        if(results.hasMoreElements()) {
             searchResult = (SearchResult) results.nextElement();

            //make sure there is not another item available, there should be only 1 match
            if(results.hasMoreElements()) {
                System.err.println("Matched multiple users for the lastName: " + lastName+", dateOfBirth: "+dateOfBirth);
                return null;
            }
        }
        
        return searchResult;
	}
	
	public SearchResult findUserIfExists(String searchBase, String firstName, String lastName, String emailAddress) throws ParseException, NamingException 
	{
		SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        LdapContext ldapContext = new InitialLdapContext(ldapEnvironment, null);		
		String searchFilter = "(&(objectClass=beisPerson)(sn=" + lastName + ")(mail=" + emailAddress + ")(givenName=" + firstName + "))";
		
		NamingEnumeration<SearchResult> results = ldapContext.search(searchBase, searchFilter, searchControls);

        SearchResult searchResult = null;
        if(results.hasMoreElements()) {
             searchResult = (SearchResult) results.nextElement();

            //make sure there is not another item available, there should be only 1 match
            if(results.hasMoreElements()) {
                System.err.println("Matched multiple users for the firstName: "+firstName+", lastName: " + lastName+", emailAddress: "+emailAddress);
                return null;
            }
        }
        
        return searchResult;
	}
}
