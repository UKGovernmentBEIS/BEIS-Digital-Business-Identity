/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.datastore.utils;

import java.util.ArrayList;
import java.util.List;

import com.kpmg.basic.registration.form.beans.BusinessInformationFormBean;
import com.kpmg.registration.beans.AccountNumber;
import com.kpmg.registration.beans.Business;
import com.kpmg.registration.beans.BusinessAddress;
import com.kpmg.registration.beans.BusinessBankDetails;
import com.kpmg.registration.beans.BusinessCRN;
import com.kpmg.registration.beans.BusinessDUNN;
import com.kpmg.registration.beans.BusinessName;
import com.kpmg.registration.beans.BusinessPAYE;
import com.kpmg.registration.beans.BusinessPSC;
import com.kpmg.registration.beans.BusinessPostCode;
import com.kpmg.registration.beans.BusinessSIC;
import com.kpmg.registration.beans.BusinessTurnOver;
import com.kpmg.registration.beans.BusinessUTR;
import com.kpmg.registration.beans.BusinessVAT;
import com.kpmg.registration.beans.ChBusinessId;
import com.kpmg.registration.beans.NoOfEmployees;
import com.kpmg.registration.beans.PersonWithSignificantControl;
import com.kpmg.registration.beans.Sortcode;
import com.kpmg.registration.utils.ControllerUtils;

public class BusinessObject
{
	Business businessObject;

	public BusinessObject()
	{
		businessObject = new Business();
	}

	public void setBusinessObject(Business businessObject)
	{
		this.businessObject = businessObject;
	}

	public Business getBusinessObject()
	{
		return this.businessObject;
	}

	public void setBusinessAttributes(BusinessInformationFormBean businessFormBean)
	{
		businessObject.setIsOwner(businessFormBean.isOwner());
		businessObject.setIsDelegate(businessFormBean.isDelegate());

		if (!ControllerUtils.isNullOrEmptyString(businessFormBean.getBusinessName()))
		{
			if (null != businessObject.getBusinessName())
			{
				businessObject.getBusinessName().setValue(businessFormBean.getBusinessName());
			}
			else
			{
				businessObject.setBusinessName(new BusinessName(businessFormBean.getBusinessName()));
			}
		}

		if (!ControllerUtils.isNullOrEmptyString(businessFormBean.getBusinessId()))
		{
			if (null != businessObject.getChBusinessId())
			{
				businessObject.getChBusinessId().setValue(businessFormBean.getBusinessId());
			}
			else
			{
				businessObject.setChBusinessId(new ChBusinessId(businessFormBean.getBusinessId()));
			}
		}

		if (!ControllerUtils.isNullOrEmptyString(businessFormBean.getPostCode()))
		{
			if (null != businessObject.getBusinessPostCode())
			{
				businessObject.getBusinessPostCode().setValue(businessFormBean.getPostCode());
			}
			else
			{
				businessObject.setBusinessPostCode(new BusinessPostCode(businessFormBean.getPostCode()));
			}
		}

		if (!ControllerUtils.isNullOrEmptyString(businessFormBean.getPostCode()))
		{
			if (null != businessObject.getBusinessAddress())
			{
				businessObject.getBusinessAddress().setLocality(businessFormBean.getLocality());
				businessObject.getBusinessAddress().setPremise(businessFormBean.getPremise());
				businessObject.getBusinessAddress().setAddressLine1(businessFormBean.getAddressLine1());
				businessObject.getBusinessAddress().setPostcode(businessFormBean.getPostCode());
			}
			else
			{
				businessObject.setBusinessAddress(
						new BusinessAddress(businessFormBean.getLocality(), businessFormBean.getPremise(),
								businessFormBean.getAddressLine1(), businessFormBean.getPostCode()));
			}
		}
		if (!ControllerUtils.isNullOrEmptyString(businessFormBean.getNoOfEmployees()))
		{
			if (null != businessObject.getNoOfEmployees())
			{
				businessObject.getNoOfEmployees().setValue(businessFormBean.getNoOfEmployees());
			}
			else
			{
				businessObject.setNoOfEmployees(new NoOfEmployees(businessFormBean.getNoOfEmployees()));
			}
		}

		if (!ControllerUtils.isNullOrEmptyString(businessFormBean.getBusinessTurnOver()))
		{
			if (null != businessObject.getBusinessTurnOver())
			{
				businessObject.getBusinessTurnOver().setValue(businessFormBean.getBusinessTurnOver());
			}
			else
			{
				businessObject.setBusinessTurnOver(new BusinessTurnOver(businessFormBean.getBusinessTurnOver()));
			}
		}

		if (!ControllerUtils.isNullOrEmptyString(businessFormBean.getBusinessCRN()))
		{
			if (null != businessObject.getBusinessCRN())
			{
				businessObject.getBusinessCRN().setValue(businessFormBean.getBusinessCRN());
			}
			else
			{
				businessObject.setBusinessCRN(new BusinessCRN(businessFormBean.getBusinessCRN()));
			}

		}

		if (!ControllerUtils.isNullOrEmptyString(businessFormBean.getBusinessUTR()))
		{
			if (null != businessObject.getBusinessUTR())
			{
				businessObject.getBusinessUTR().setValue(businessFormBean.getBusinessUTR());
			}
			else
			{
				businessObject.setBusinessUTR(new BusinessUTR(businessFormBean.getBusinessUTR()));
			}
		}

		if (!ControllerUtils.isNullOrEmptyString(businessFormBean.getBusinessDUNN()))
		{
			if (null != businessObject.getBusinessDUNN())
			{
				businessObject.getBusinessDUNN().setValue(businessFormBean.getBusinessDUNN());
			}
			else
			{
				businessObject.setBusinessDUNN(new BusinessDUNN(businessFormBean.getBusinessDUNN()));
			}
		}

		if (!ControllerUtils.isNullOrEmptyString(businessFormBean.getBusinessVAT()))
		{
			if (null != businessObject.getBusinessVAT())
			{
				businessObject.getBusinessVAT().setValue(businessFormBean.getBusinessVAT());
			}
			else
			{
				businessObject.setBusinessVAT(new BusinessVAT(businessFormBean.getBusinessVAT()));
			}
		}

		if (!ControllerUtils.isNullOrEmptyString(businessFormBean.getBusinessPAYE()))
		{
			if (null != businessObject.getBusinessPAYE())
			{
				businessObject.getBusinessPAYE().setValue(businessFormBean.getBusinessPAYE());
			}
			else
			{
				businessObject.setBusinessPAYE(new BusinessPAYE(businessFormBean.getBusinessPAYE()));
			}
		}

		if (!ControllerUtils.isNullOrEmptyString(businessFormBean.getSortcode())
				&& !ControllerUtils.isNullOrEmptyString(businessFormBean.getAccountNumber()))
		{
			if (null != businessObject.getBusinessBankDetails())
			{
				if (null != businessObject.getBusinessBankDetails().getSortcode())
				{
					businessObject.getBusinessBankDetails().getSortcode().setValue(businessFormBean.getSortcode());
				}

				if (null == businessObject.getBusinessBankDetails().getSortcode())
				{
					businessObject.getBusinessBankDetails().setSortcode(new Sortcode(businessFormBean.getSortcode()));
				}

				if (null != businessObject.getBusinessBankDetails().getAccountNumber())
				{
					businessObject.getBusinessBankDetails().getAccountNumber()
							.setValue(businessFormBean.getAccountNumber());
				}

				if (null == businessObject.getBusinessBankDetails().getAccountNumber())
				{
					businessObject.getBusinessBankDetails()
							.setAccountNumber(new AccountNumber(businessFormBean.getAccountNumber()));
				}

			}
			else
			{
				businessObject
						.setBusinessBankDetails(new BusinessBankDetails(new Sortcode(businessFormBean.getSortcode()),
								new AccountNumber(businessFormBean.getAccountNumber())));
			}
		}

		if (!ControllerUtils.isNullOrEmptyString(businessFormBean.getBusinessPSC()))
		{
			List<PersonWithSignificantControl> pscList = new ArrayList<PersonWithSignificantControl>();
			for (String pscName : businessFormBean.getBusinessPSC().split(","))
			{
				pscList.add(new PersonWithSignificantControl(pscName.trim()));
			}

			if (null != businessObject.getBusinessPSC())
			{
				businessObject.getBusinessPSC().setPersonWithSignificantControl(pscList);
			}
			else
			{
				businessObject.setBusinessPSC(new BusinessPSC(pscList));
			}
		}

		if (!ControllerUtils.isNullOrEmptyString(businessFormBean.getBusinessSIC()))
		{
			List<String> sicCodeList = new ArrayList<String>();
			for (String sicCode : businessFormBean.getBusinessSIC().split(","))
			{
				sicCodeList.add(sicCode.trim());
			}

			if (null != businessObject.getBusinessSIC())
			{
				businessObject.getBusinessSIC().setSicCodes(sicCodeList);
			}
			else
			{
				businessObject.setBusinessSIC(new BusinessSIC(sicCodeList));
			}
		}
	}
}
