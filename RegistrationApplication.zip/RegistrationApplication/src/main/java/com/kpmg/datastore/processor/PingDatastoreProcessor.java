/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.datastore.processor;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.naming.NameNotFoundException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.AttributeInUseException;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.InvalidAttributeValueException;
import javax.naming.directory.SearchResult;

import org.apache.directory.api.util.GeneralizedTime;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpmg.basic.registration.form.beans.DBIAccountFormBean;
import com.kpmg.basic.registration.form.beans.UserExistsResponseBean;
import com.kpmg.datastore.utils.LdapHelper;
import com.kpmg.datastore.utils.LdapInfo;
import com.kpmg.registration.beans.Business;
import com.kpmg.registration.beans.DelegatesLink;
import com.kpmg.registration.constants.RegistrationConstants;
import com.kpmg.registration.utils.ControllerUtils;
import com.kpmg.registration.utils.SecretStoreUtils;

public class PingDatastoreProcessor
{
	private LdapInfo ldapConnectionInfo;
	private LdapHelper ldapHelper;
	private final String baseDN;
	
	public PingDatastoreProcessor(char[] masterKey) throws IOException
	{
		SecretStoreUtils secretStore = new SecretStoreUtils(masterKey);
		ldapConnectionInfo = new LdapInfo(
				SecretStoreUtils.decodeInput(String.valueOf(secretStore.getSecrete(RegistrationConstants.LDAP_PRINCIPAL))),
				String.valueOf(secretStore.getSecrete(RegistrationConstants.LDAP_SECRET)),
				String.valueOf(secretStore.getSecrete(RegistrationConstants.LDAP_SERVER_URL)));
		ldapHelper = new LdapHelper(ldapConnectionInfo);
		baseDN = SecretStoreUtils.decodeInput(String.valueOf(secretStore.getSecrete(RegistrationConstants.BASE_DN)));
	}

	public void addEntryToPingDatastore(DBIAccountFormBean dbiAccountBean, String uniqueIdentifier) throws Exception
	{
		try
		{
			HashMap<String, String> attributesToBeAdded = new HashMap<String, String>();
			if (!ControllerUtils.isNullOrEmptyString(dbiAccountBean.getEmail())
					&& !ControllerUtils.isNullOrEmptyString(dbiAccountBean.getLastName())
					&& !ControllerUtils.isNullOrEmptyString(dbiAccountBean.getFirstName())
					&& !ControllerUtils.isNullOrEmptyString(dbiAccountBean.getPostalCode())
					&& !ControllerUtils.isNullOrEmptyString(dbiAccountBean.getAddress())
					&& !ControllerUtils.isNullOrEmptyString(dbiAccountBean.getPassword())
					&& !ControllerUtils.isNullOrEmptyString(dbiAccountBean.getDateOfBirth()))
			{
				// mandatory attributes
				attributesToBeAdded.put(RegistrationConstants.UID, dbiAccountBean.getEmail().toLowerCase());

				attributesToBeAdded.put(RegistrationConstants.CN,
						dbiAccountBean.getFirstName().toLowerCase() + " " + dbiAccountBean.getLastName().toLowerCase());
				attributesToBeAdded.put(RegistrationConstants.SN, dbiAccountBean.getLastName().toLowerCase());
				attributesToBeAdded.put(RegistrationConstants.MAIL, dbiAccountBean.getEmail().toLowerCase());
				attributesToBeAdded.put(RegistrationConstants.GIVEN_NAME, dbiAccountBean.getFirstName().toLowerCase());
				attributesToBeAdded.put(RegistrationConstants.POSTAL_ADDRESS,
						dbiAccountBean.getAddress().toLowerCase());
				attributesToBeAdded.put(RegistrationConstants.POSTAL_CODE,
						dbiAccountBean.getPostalCode().toLowerCase());
				attributesToBeAdded.put(RegistrationConstants.USER_PASSWORD,
						dbiAccountBean.getPassword().toLowerCase());
				attributesToBeAdded.put(RegistrationConstants.DATE_OF_BIRTH, dbiAccountBean.getDateOfBirth());

				if (!ControllerUtils.isNullOrEmptyString(dbiAccountBean.getDisplayName()))
				{
					attributesToBeAdded.put(RegistrationConstants.DISPLAY_NAME,
							dbiAccountBean.getDisplayName().toLowerCase());
				}
				if (!ControllerUtils.isNullOrEmptyString(dbiAccountBean.getMiddleName()))
				{
					attributesToBeAdded.put(RegistrationConstants.INITIALS,
							dbiAccountBean.getMiddleName().toLowerCase());
				}
				if (!ControllerUtils.isNullOrEmptyString(dbiAccountBean.getGender()))
				{
					attributesToBeAdded.put(RegistrationConstants.GENDER, dbiAccountBean.getGender().toLowerCase());
				}
				if (!ControllerUtils.isNullOrEmptyString(dbiAccountBean.getTitle()))
				{

					attributesToBeAdded.put(RegistrationConstants.TITLE, dbiAccountBean.getTitle().toLowerCase());
				}

				if (!ControllerUtils.isNullOrEmptyString(dbiAccountBean.getIdpSelection()))
				{

					attributesToBeAdded.put(RegistrationConstants.IDENTITY_PROVIDER, dbiAccountBean.getIdpSelection());
				}

				attributesToBeAdded.put(RegistrationConstants.UNIQUE_IDENTIFIER, uniqueIdentifier.toLowerCase());
				String userDN = getUserDN(dbiAccountBean.getEmail().toLowerCase());
				ldapHelper.addEntry(userDN, attributesToBeAdded);
			}
			else
			{
				throw new InvalidAttributeValueException("Required attribute missing.");
			}

		}
		catch (NamingException e)
		{
			System.err.println("Error while searching Ldap entry");
			throw e;
		}
		catch (Exception e)
		{
			System.err.println("Error while creating Ldap entry");
			throw e;
		}
	}

	public boolean isUserExistsInDirectory(String userid) throws NamingException
	{
		boolean isUserExist = false;
		String searchDn = getUserDN(userid);
		try
		{
			Attributes ldapAttributes = ldapHelper.searchEntry(searchDn, userid.toLowerCase());
			if (ldapAttributes != null)
			{
				isUserExist = true;
			}
		}
		catch (NameNotFoundException e)
		{
			isUserExist = false;
		}
		catch (NamingException e)
		{
			System.err.println("Error while searching Ldap entry");
			throw e;
		}
		return isUserExist;
	}

	public void updateBusinessToUserLdapEntry(Business businessObject, String userid) throws Exception
	{
		String searchDn = getUserDN(userid);
		ObjectMapper mapper = new ObjectMapper();

		try
		{
			Attribute attributeToBeAdded = new BasicAttribute(RegistrationConstants.BUSINESS, mapper.writeValueAsString(businessObject));
			Attributes ldapAttributes = ldapHelper.searchEntry(searchDn, userid.toLowerCase());
			if (ldapAttributes != null)
			{
				Attribute businessAttribute = ldapAttributes.get(RegistrationConstants.BUSINESS);

				if (null != businessAttribute && businessAttribute.size() != 0)
				{
					@SuppressWarnings("rawtypes")
					NamingEnumeration allAttributes = businessAttribute.getAll();
					ArrayList<Attribute> oldAtrributeEntries = new ArrayList<Attribute>();
					while (allAttributes.hasMore())
					{
						String attriuteJsonString = (String) allAttributes.next();
						Business businessFromLDAP = mapper.readValue(attriuteJsonString, Business.class);

						if (businessFromLDAP.getChBusinessId().getValue()
								.equals(businessObject.getChBusinessId().getValue()))
						{
							// replace existing entry
							oldAtrributeEntries.add(new BasicAttribute(RegistrationConstants.BUSINESS, attriuteJsonString));
						}
						else
						{
							attributeToBeAdded.add(attriuteJsonString);
						}
					}
					ldapHelper.removeEntry(searchDn, oldAtrributeEntries);
				}
				ArrayList<Attribute> attributesToUpdateList = new ArrayList<Attribute>();
				attributesToUpdateList.add(attributeToBeAdded);
				ldapHelper.modifyEntry(searchDn, attributesToUpdateList);
			}
		}
		catch (NamingException | IOException e)
		{

			System.err.println("Error while updating Ldap entry");
			throw e;
		}
	}

	public void modifyLdapEntryWithUniqueIdentifier(String attributeValue, String userid) throws NamingException
	{
		String searchDn = getUserDN(userid);

		try
		{
			Attributes ldapAttributes = ldapHelper.searchEntry(searchDn, userid.toLowerCase());
			if (ldapAttributes != null)
			{
				Attribute attribute = ldapAttributes.get(RegistrationConstants.UNIQUE_IDENTIFIER);
				attribute.add(attributeValue);
				ArrayList<Attribute> attributeList = new ArrayList<Attribute>();
				attributeList.add(attribute);
				ldapHelper.modifyEntry(searchDn, attributeList);
			}
		}
		catch (AttributeInUseException e)
		{
			System.err.println("Unique Identifier already exists for Ldap entry.");
			throw e;
		}
	}

	public UserExistsResponseBean isUserExists(DBIAccountFormBean dbiAccountBean, String uniqueIdentifier)
			throws ParseException, NamingException
	{
		UserExistsResponseBean userExists = new UserExistsResponseBean();
		try
		{
			SearchResult searchResult = ldapHelper.findUserIfExistsWithMatchingUniqueIdentitfier(
					baseDN, uniqueIdentifier.toLowerCase());
			Boolean matched = null;

			if (null != searchResult)
			{
				matched = true;
				Attributes ldapAttributes = searchResult.getAttributes();
				if (ldapAttributes != null)
				{
					@SuppressWarnings("rawtypes")
					NamingEnumeration allAttributes = ldapAttributes.getAll();

					while (allAttributes.hasMore())
					{
						Attribute attribute = (Attribute) allAttributes.next();
						if (attribute.getID().equalsIgnoreCase(RegistrationConstants.GIVEN_NAME))
						{							
							matched = matched
									&& dbiAccountBean.getFirstName().equalsIgnoreCase((String) attribute.get());							
							continue;
						}
						if (attribute.getID().equalsIgnoreCase(RegistrationConstants.SN))
						{
							matched = matched
									&& dbiAccountBean.getLastName().equalsIgnoreCase((String) attribute.get());
							continue;
						}
					}
					if (matched)
					{
						userExists.setUserDetailsNotMatch(false);
						userExists.setAlreadyExists(true);
					}
					else
					{
						userExists.setUserDetailsNotMatch(true);
						userExists.setAlreadyExists(true);
					}
				}

			}
			else
			{
				userExists.setNewUser(true);
			}
		}
		catch (NamingException e)
		{
			throw e;
		}
		catch (ParseException e)
		{
			System.err.println("Error while parsing date of birth.");
			throw e;

		}

		return userExists;
	}

	public boolean isUniqueIdentifierAlreadyExists(DBIAccountFormBean dbiAccountBean, String uniqueIdentifier)
			throws NamingException, ParseException

	{
		try
		{
			SearchResult searchResult = ldapHelper.findUserIfExistsWithMatchingUniqueIdentitfier(
					baseDN, uniqueIdentifier.toLowerCase(),
					dbiAccountBean.getLastName().toLowerCase(), dbiAccountBean.getDateOfBirth());

			if (null != searchResult)
			{
				return true;
			}
		}
		catch (NamingException e)
		{
			System.err.println("Error while searching Ldap entry");
		}
		catch (ParseException e)
		{
			System.err.println("Error while parsing date of birth.");
			throw e;
		}
		return false;
	}

	private String getUserDN(String userid)
	{
		return RegistrationConstants.UID_URL + userid.toLowerCase() + RegistrationConstants.COMMA_DELIMITER + baseDN;
	}

	/**
	 * Return list of businesses associated with user as owner as well as delegated
	 * 
	 * @param userid
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, Business> getUsersBusinesses(String userid) throws Exception
	{
		String searchDn = getUserDN(userid);
		ObjectMapper mapper = new ObjectMapper();
		HashMap<String, Business> businessMap = new HashMap<String, Business>();
		try
		{
			Attributes ldapAttributes = ldapHelper.searchEntry(searchDn, userid.toLowerCase());
			Attribute businessAttribute = ldapAttributes.get(RegistrationConstants.BUSINESS);

			if (null != businessAttribute && businessAttribute.size() != 0)
			{
				@SuppressWarnings("rawtypes")
				NamingEnumeration allAttributes = businessAttribute.getAll();

				while (allAttributes.hasMore())
				{
					String attriuteJsonString = (String) allAttributes.next();
					Business businessFromLDAP = mapper.readValue(attriuteJsonString, Business.class);
					if (null != businessFromLDAP)
					{
						businessMap.put(businessFromLDAP.getChBusinessId().getValue(), businessFromLDAP);

					}

				}
			}
		}
		catch (NamingException | IOException e)
		{
			throw e;
		}

		return businessMap;
	}

	/**
	 * Return list of businesses associated with user as delegate
	 * 
	 * @param userid
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, Business> getUsersDelegateBusinesses(String userid) throws Exception
	{
		String searchDn = getUserDN(userid);
		ObjectMapper mapper = new ObjectMapper();
		HashMap<String, Business> businessMap = new HashMap<String, Business>();
		try
		{
			Attributes ldapAttributes = ldapHelper.searchEntry(searchDn, userid.toLowerCase());
			Attribute businessAttribute = ldapAttributes.get(RegistrationConstants.BUSINESS);

			if (null != businessAttribute && businessAttribute.size() != 0)
			{
				@SuppressWarnings("rawtypes")
				NamingEnumeration allAttributes = businessAttribute.getAll();

				while (allAttributes.hasMore())
				{
					String attriuteJsonString = (String) allAttributes.next();
					Business businessFromLDAP = mapper.readValue(attriuteJsonString, Business.class);
					if (null != businessFromLDAP && businessFromLDAP.getIsDelegate())
					{
						businessMap.put(businessFromLDAP.getChBusinessId().getValue(), businessFromLDAP);
					}
				}
			}
		}
		catch (NamingException | IOException e)
		{
			throw e;
		}

		return businessMap;
	}

	/**
	 * Return list of businesses associated with user as delegate
	 * 
	 * @param userid
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, Business> getUsersOwnedBusinesses(String userid) throws Exception
	{
		String searchDn = getUserDN(userid);
		ObjectMapper mapper = new ObjectMapper();
		HashMap<String, Business> businessMap = new HashMap<String, Business>();
		try
		{
			Attributes ldapAttributes = ldapHelper.searchEntry(searchDn, userid.toLowerCase());
			Attribute businessAttribute = ldapAttributes.get(RegistrationConstants.BUSINESS);

			if (null != businessAttribute && businessAttribute.size() != 0)
			{
				@SuppressWarnings("rawtypes")
				NamingEnumeration allAttributes = businessAttribute.getAll();

				while (allAttributes.hasMore())
				{
					String attriuteJsonString = (String) allAttributes.next();
					Business businessFromLDAP = mapper.readValue(attriuteJsonString, Business.class);
					if (null != businessFromLDAP && businessFromLDAP.getIsOwner())
					{
						businessMap.put(businessFromLDAP.getChBusinessId().getValue(), businessFromLDAP);
					}
				}
			}
		}
		catch (NamingException | IOException e)
		{
			throw e;
		}

		return businessMap;
	}

	public boolean isUserExists(String firstName, String lastName, String emailAddress)
			throws ParseException, NamingException
	{
		try
		{
			SearchResult searchResult = ldapHelper.findUserIfExists(baseDN,
					firstName.toLowerCase(), lastName.toLowerCase(), emailAddress.toLowerCase());

			if (null != searchResult)
			{
				return true;
			}
		}
		catch (NamingException e)
		{
			throw e;
		}
		catch (ParseException e)
		{
			System.err.println("Error while parsing date of birth.");
			throw e;

		}

		return false;
	}

	/**
	 * Add Delegate Link to datastore
	 * 
	 * @param delegateLink
	 * @param userid
	 * @throws Exception
	 */
	public void addBusinessDelegate(DelegatesLink delegateLink, String userid) throws Exception
	{
		String searchDn = getUserDN(userid);
		ObjectMapper mapper = new ObjectMapper();
		boolean isAlreadyExists = false;
		try
		{
			Attribute attributeToBeAdded = new BasicAttribute(RegistrationConstants.DELEGATES, mapper.writeValueAsString(delegateLink));
			Attributes ldapAttributes = ldapHelper.searchEntry(searchDn, userid.toLowerCase());
			if (ldapAttributes != null)
			{
				Attribute delegatesAttribute = ldapAttributes.get(RegistrationConstants.DELEGATES);

				if (null != delegatesAttribute && delegatesAttribute.size() != 0)
				{
					@SuppressWarnings("rawtypes")
					NamingEnumeration allAttributes = delegatesAttribute.getAll();

					while (allAttributes.hasMore())
					{
						String attriuteJsonString = (String) allAttributes.next();
						DelegatesLink businessDelegate = mapper.readValue(attriuteJsonString, DelegatesLink.class);

						if (businessDelegate.equals(delegateLink))
						{
							// skip as entry already exists
							isAlreadyExists = true;

						}
						else
						{
							attributeToBeAdded.add(attriuteJsonString);
						}
					}

				}
				if (!isAlreadyExists)
				{
					ArrayList<Attribute> attributesToUpdateList = new ArrayList<Attribute>();
					attributesToUpdateList.add(attributeToBeAdded);
					ldapHelper.modifyEntry(searchDn, attributesToUpdateList);
				}

			}
		}
		catch (NamingException | IOException e)
		{

			System.err.println("Error while updating Ldap entry");
			throw e;
		}
	}

	public DBIAccountFormBean getAcountDetails(String userid) throws Exception
	{
		String searchDn = getUserDN(userid);
		DBIAccountFormBean accountBean = null;
		try
		{

			Attributes ldapAttributes = ldapHelper.searchEntry(searchDn, userid.toLowerCase());
			if (ldapAttributes != null)
			{
				@SuppressWarnings("rawtypes")
				NamingEnumeration allAttributes = ldapAttributes.getAll();
				accountBean = new DBIAccountFormBean();
				while (allAttributes.hasMore())
				{
					Attribute attribute = (Attribute) allAttributes.next();
					if (attribute.getID().equalsIgnoreCase(RegistrationConstants.GIVEN_NAME))
					{
						accountBean.setFirstName(((String) attribute.get()).toUpperCase());
						continue;
					}
					if (attribute.getID().equalsIgnoreCase(RegistrationConstants.SN))
					{
						accountBean.setLastName(((String) attribute.get()).toUpperCase());
						continue;
					}

					if (attribute.getID().equalsIgnoreCase(RegistrationConstants.DATE_OF_BIRTH))
					{
						GeneralizedTime gt = new GeneralizedTime((String) attribute.get());
						Date dateOfBirth = gt.getCalendar().getTime();
						String dateOfBirthStr = new SimpleDateFormat(RegistrationConstants.BUSINESS_DOB_FORMAT).format(dateOfBirth);
						accountBean.setDateOfBirth(dateOfBirthStr);
						continue;
					}

					if (attribute.getID().equalsIgnoreCase(RegistrationConstants.DISPLAY_NAME))
					{
						accountBean.setDisplayName(((String) attribute.get()).toUpperCase());
						continue;
					}

					if (attribute.getID().equalsIgnoreCase(RegistrationConstants.MAIL))
					{
						accountBean.setEmail((String) attribute.get());
						continue;
					}

					if (attribute.getID().equalsIgnoreCase(RegistrationConstants.POSTAL_ADDRESS))
					{
						accountBean.setAddress(((String) attribute.get()).toUpperCase());
						continue;
					}

					if (attribute.getID().equalsIgnoreCase(RegistrationConstants.POSTAL_CODE))
					{
						accountBean.setPostalCode(((String) attribute.get()).toUpperCase());
						continue;
					}

					if (attribute.getID().equalsIgnoreCase(RegistrationConstants.GENDER))
					{
						accountBean.setGender(((String) attribute.get()).toUpperCase());
						continue;
					}
					if (attribute.getID().equalsIgnoreCase(RegistrationConstants.INITIALS))
					{
						accountBean.setMiddleName(((String) attribute.get()).toUpperCase());
						continue;
					}
				}
			}
		}
		catch (NamingException | ParseException e)
		{

			System.err.println("Error while searching ldap entry");
			throw e;
		}
		return accountBean;
	}

	public void removeDelegateLink(String userid, DelegatesLink delegateLink) throws Exception
	{

		String searchDn = getUserDN(userid);
		ObjectMapper mapper = new ObjectMapper();

		try
		{
			Attributes ldapAttributes = ldapHelper.searchEntry(searchDn, userid.toLowerCase());
			if (ldapAttributes != null)
			{
				Attribute delegatesAttribute = ldapAttributes.get(RegistrationConstants.DELEGATES);

				if (null != delegatesAttribute && delegatesAttribute.size() != 0)
				{
					@SuppressWarnings("rawtypes")
					NamingEnumeration allAttributes = delegatesAttribute.getAll();
					ArrayList<Attribute> removeAtrributeEntries = new ArrayList<Attribute>();
					while (allAttributes.hasMore())
					{
						String attriuteJsonString = (String) allAttributes.next();
						DelegatesLink delegateFromLDAP = mapper.readValue(attriuteJsonString, DelegatesLink.class);

						if (delegateFromLDAP.equals(delegateLink))
						{
							removeAtrributeEntries.add(new BasicAttribute(RegistrationConstants.DELEGATES, attriuteJsonString));
							removeBusinessFromUser(delegateLink.getChBusinessId(), delegateLink.getUid().toLowerCase());
							break;
						}
					}
					ldapHelper.removeEntry(searchDn, removeAtrributeEntries);

				}
			}
		}
		catch (NamingException | IOException e)
		{

			System.err.println("Error while updating Ldap entry");
			throw e;
		}
	}

	public List<DelegatesLink> getDelegatesOfBusiness(String userid, String businessId) throws Exception
	{

		String searchDn = getUserDN(userid);
		ObjectMapper mapper = new ObjectMapper();
		List<DelegatesLink> delegatesList = new ArrayList<DelegatesLink>();
		try
		{
			Attributes ldapAttributes = ldapHelper.searchEntry(searchDn, userid.toLowerCase());
			if (ldapAttributes != null)
			{
				Attribute delegatesAttribute = ldapAttributes.get(RegistrationConstants.DELEGATES);

				if (null != delegatesAttribute && delegatesAttribute.size() != 0)
				{
					@SuppressWarnings("rawtypes")
					NamingEnumeration allAttributes = delegatesAttribute.getAll();

					while (allAttributes.hasMore())
					{
						String attriuteJsonString = (String) allAttributes.next();
						DelegatesLink delegateFromLDAP = mapper.readValue(attriuteJsonString, DelegatesLink.class);

						if (delegateFromLDAP.getChBusinessId().equals(businessId))
						{
							delegatesList.add(delegateFromLDAP);
						}
					}
				}
			}
		}
		catch (NamingException | IOException e)
		{

			System.err.println("Error while updating Ldap entry");
			throw e;
		}
		return delegatesList;
	}

	/**
	 * @param businessId
	 * @param userid
	 * @throws Exception
	 */
	public void removeBusinessFromUser(String businessId, String userid) throws Exception
	{
		String searchDn = getUserDN(userid);
		ObjectMapper mapper = new ObjectMapper();

		try
		{
			Attributes ldapAttributes = ldapHelper.searchEntry(searchDn, userid.toLowerCase());
			if (ldapAttributes != null)
			{
				Attribute businessAttribute = ldapAttributes.get(RegistrationConstants.BUSINESS);

				if (null != businessAttribute && businessAttribute.size() != 0)
				{
					@SuppressWarnings("rawtypes")
					NamingEnumeration allAttributes = businessAttribute.getAll();
					ArrayList<Attribute> removeBusinessEntry = new ArrayList<Attribute>();
					while (allAttributes.hasMore())
					{
						String attriuteJsonString = (String) allAttributes.next();
						Business businessFromLDAP = mapper.readValue(attriuteJsonString, Business.class);

						if (businessFromLDAP.getChBusinessId().getValue().equals(businessId))
						{
							// replace existing entry
							removeBusinessEntry.add(new BasicAttribute(RegistrationConstants.BUSINESS, attriuteJsonString));
							break;
						}

					}
					ldapHelper.removeEntry(searchDn, removeBusinessEntry);
				}
			}
		}
		catch (NamingException | IOException e)
		{

			System.err.println("Error while updating Ldap entry");
			throw e;
		}
	}
}
