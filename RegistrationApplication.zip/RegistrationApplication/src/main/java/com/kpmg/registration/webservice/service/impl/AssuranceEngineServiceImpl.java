/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.registration.webservice.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpmg.registration.beans.Business;
import com.kpmg.registration.beans.Company;
import com.kpmg.registration.beans.CompanyOwnerResponse;
import com.kpmg.registration.beans.PersonWithInsolvencyNoticeResponse;
import com.kpmg.registration.constants.RegistrationConstants;
import com.kpmg.registration.utils.ControllerUtils;
import com.kpmg.registration.utils.SecretStoreUtils;
import com.kpmg.registration.webservice.service.AssuranceEngineService;

public class AssuranceEngineServiceImpl implements AssuranceEngineService
{

	private Client client;
	private WebTarget target;
	private Properties resourcesProperties;
	private String assuranceEngineBaseWSUrl;
	private String masterKey;

	public AssuranceEngineServiceImpl(String masterKey) throws IOException
	{
		resourcesProperties = new Properties();
		InputStream inStream = getClass().getClassLoader().getResourceAsStream(RegistrationConstants.RESOURCES_PROPERTIES);
		resourcesProperties.load(inStream);
		this.masterKey = masterKey;
		if (!resourcesProperties.isEmpty())
		{
			assuranceEngineBaseWSUrl = resourcesProperties
					.getProperty(RegistrationConstants.ASSURANCE_ENGINE_RS_BASE_URL);
		}
		client = ClientBuilder.newClient();
	}

	protected void setTarget(String targetAPICall, Map<String, String> queryParams)
	{
		target = client.target(assuranceEngineBaseWSUrl + targetAPICall);
		for (Map.Entry<String, String> queryParam : queryParams.entrySet())
		{
			target.queryParam(queryParam.getKey(), queryParam.getValue());
		}
	}

	public Response get(String uri, Map<String, Object> params) throws IOException
	{
		Response response = null;
		SecretStoreUtils secretStore = new SecretStoreUtils(this.masterKey.toCharArray());
		char[] ae_clientId = secretStore.getSecrete(RegistrationConstants.AE_CLIENT_ID);

		UriBuilder uriBuilder = UriBuilder.fromPath(assuranceEngineBaseWSUrl + uri);
		uriBuilder.queryParam(RegistrationConstants.AE_CLIENT_ID_PARAM, String.valueOf(ae_clientId));
		Arrays.fill(ae_clientId, Character.MIN_VALUE);

		for (String key : params.keySet())
		{
			uriBuilder.queryParam(key, params.get(key));
		}
		char[] token = secretStore.getSecrete(RegistrationConstants.AE_AUTHORISATION_TOKEN);
		response = this.client.target(uriBuilder).request()
				.header(HttpHeaders.AUTHORIZATION, RegistrationConstants.BEARER + String.valueOf(token)).get();
		Arrays.fill(token, Character.MIN_VALUE);
		return response;
	}

	public Response post(String uri, Object jsonFormattedObject) throws IOException
	{
		Response response = null;
		SecretStoreUtils secretStore = new SecretStoreUtils(this.masterKey.toCharArray());
		char[] ae_clientId = secretStore.getSecrete(RegistrationConstants.AE_CLIENT_ID);

		UriBuilder uriBuilder = UriBuilder.fromPath(assuranceEngineBaseWSUrl + uri);
		uriBuilder.queryParam(RegistrationConstants.AE_CLIENT_ID_PARAM, String.valueOf(ae_clientId));
		Arrays.fill(ae_clientId, Character.MIN_VALUE);

		char[] token = secretStore.getSecrete(RegistrationConstants.AE_AUTHORISATION_TOKEN);
		response = this.client.target(uriBuilder).request()
				.header(HttpHeaders.AUTHORIZATION, RegistrationConstants.BEARER + String.valueOf(token))
				.post(Entity.entity(jsonFormattedObject, MediaType.APPLICATION_JSON));
		Arrays.fill(token, Character.MIN_VALUE);
		return response;
	}

	@Override
	public List<Company> searchByCompanyName(String searchCompanyName) throws Exception
	{
		List<Company> listOfCompanies = new ArrayList<Company>();
		String companyHouseSearchByName = resourcesProperties
				.getProperty(RegistrationConstants.ASSURANCE_ENGINE_SEARCH_BY_COMPANY_NAME);
		Map<String, Object> params = new HashMap<String, Object>();
		params.put(RegistrationConstants.SEARCH_STRING, searchCompanyName);

		Response restResponse = get(companyHouseSearchByName, params);

		if (restResponse.getStatus() == 200)
		{
			String searchResultJsonString = restResponse.readEntity(String.class);
			try
			{
				listOfCompanies = new ObjectMapper().readValue(searchResultJsonString,
						new TypeReference<ArrayList<Company>>()
						{
						});
			}
			catch (Exception e)
			{
				throw e;
			}
		}
		return listOfCompanies;
	}

	@Override
	public Business verifyBusinessInformation(Business businessInformation) throws IOException
	{
		String verifyBusinessUriStr = resourcesProperties
				.getProperty(RegistrationConstants.ASSURANCE_ENGINE_VERIFY_BUSINESS_ATTRIBUTES);
		Response restResponse = post(verifyBusinessUriStr, businessInformation);
		if (restResponse.getStatus() == 200)
		{
			Business verifiedBusinessObj = restResponse.readEntity(Business.class);
			return verifiedBusinessObj;
		}
		return null;
	}

	@Override
	public CompanyOwnerResponse isBusinessOwner(String companyNumber, String companyName, String firstname,
			String middlename, String lastname, String postcode) throws IOException
	{
		CompanyOwnerResponse serviceResponse = null;
		String isBusinessOwnerUriStr = resourcesProperties
				.getProperty(RegistrationConstants.ASSURANCE_ENGINE_IS_BUSINESS_OWNER);
		Map<String, Object> params = new HashMap<String, Object>();

		params.put(RegistrationConstants.COMPANY_NUMBER, companyNumber);
		params.put(RegistrationConstants.COMPANY_NAME, companyName);
		params.put(RegistrationConstants.FIRST_NAME, firstname);
		if (ControllerUtils.isNullOrEmptyString(middlename))
		{
			middlename = "";
		}
		params.put(RegistrationConstants.MIDDLE_NAME, middlename);
		params.put(RegistrationConstants.LAST_NAME, lastname);
		params.put(RegistrationConstants.POST_CODE, postcode);

//		target = client.target(uriBuilder);
		Response restResponse = get(isBusinessOwnerUriStr, params);
		if (restResponse.getStatus() == 200)
		{
			serviceResponse = restResponse.readEntity(CompanyOwnerResponse.class);
		}
		return serviceResponse;
	}

	@Override
	public PersonWithInsolvencyNoticeResponse isPersonWithInsolvencyNotices(String companyNumber, String companyName,
			String firstname, String middlename, String lastname, String postcode) throws IOException
	{
		PersonWithInsolvencyNoticeResponse serviceResponse = null;
		String isBusinessOwnerUriStr = resourcesProperties
				.getProperty(RegistrationConstants.ASSURANCE_ENGINE_IS_PERSON_WITH_INSOLVENCY_NOTICE);
		Map<String, Object> params = new HashMap<String, Object>();

		params.put(RegistrationConstants.COMPANY_NUMBER, companyNumber);
		params.put(RegistrationConstants.COMPANY_NAME, companyName);
		params.put(RegistrationConstants.FIRST_NAME, firstname);
		if (ControllerUtils.isNullOrEmptyString(middlename))
		{
			middlename = "";
		}
		params.put(RegistrationConstants.MIDDLE_NAME, middlename);
		params.put(RegistrationConstants.LAST_NAME, lastname);
		params.put(RegistrationConstants.POST_CODE, postcode);

		Response restResponse = get(isBusinessOwnerUriStr, params);
		if (restResponse.getStatus() == 200)
		{
			serviceResponse = restResponse.readEntity(PersonWithInsolvencyNoticeResponse.class);
		}
		return serviceResponse;
	}

}
