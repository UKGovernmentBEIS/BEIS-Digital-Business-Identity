/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.registration.utils;

import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.Feature;
import javax.ws.rs.core.Response;

import org.apache.directory.api.util.DateUtils;
import org.apache.directory.api.util.GeneralizedTime;
import org.glassfish.jersey.client.oauth2.OAuth2ClientSupport;
import org.springframework.ui.Model;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.kpmg.basic.registration.form.beans.DBIAccountFormBean;
import com.kpmg.basic.registration.form.beans.UserExistsResponseBean;
import com.kpmg.datastore.processor.PingDatastoreProcessor;
import com.kpmg.registration.constants.RegistrationConstants;

public class ControllerUtils
{

	/**
	 * Sends a redirect if the user needs to login.
	 *
	 * @param request
	 *            the request object.
	 * @param response
	 *            the response object.
	 * @throws Exception 
	 */
	public static void redirectIfLoginRequired(final HttpServletRequest request, final HttpServletResponse response, final String masterKey)
			throws Exception
	{
		String redirectUrl = RegistrationConstants.ERROR_PAGE;
		String loginOption = (String) request.getSession().getAttribute(RegistrationConstants.LOGIN_OPTION);
		if (isLoginRequired(request, masterKey) || request.getSession().getAttribute(RegistrationConstants.NAVIGATION_OPTION) == null)
		{
			
				if(RegistrationConstants.VERIFYLOGIN.equals(loginOption)) 
				{
					redirectUrl = createRedirectUrl(request, masterKey);
				}
				else if(RegistrationConstants.DBILOGIN.equals(loginOption)) 
				{
					redirectUrl = createRedirectUrlToDBIAccount(request, masterKey);
				}
				else 
				{
					redirectUrl = createRedirectUrlToDBIAccount(request, masterKey);
				}
			
			response.sendRedirect(redirectUrl);
		}
	}

	/**
	 * Creates the redirect URL from configuration values.
	 *
	 * @param request
	 *            the request object.
	 * @return the redirect URL to be used to initiate a login with Ping Federate.
	 * @throws IOException 
	 */
	public static String createRedirectUrl(final HttpServletRequest request, final String masterKey) throws IOException
	{

		final String authorizationEndpoint = RegistrationConstants.AUTHORIZATION_ENDPOINT;		
		SecretStoreUtils secretUtil = new SecretStoreUtils(masterKey.toCharArray());
		
		final String clientId = String.valueOf(secretUtil.getSecrete(RegistrationConstants.CLIENT_ID));

		final String adapterId = RegistrationConstants.ADAPTER_ID;

		final String scopes = RegistrationConstants.SCOPES.replace(" ", RegistrationConstants.PERCENT_TWENTY);

		final String redirectUri = RegistrationConstants.REDIRECT_LOGIN_URI;
		final String queryString = request.getQueryString();
		final String requestUrl = request.getRequestURL().toString();
		final URL url = new URL(requestUrl);

		final String state = url.getPath() + (queryString == null ? "" : RegistrationConstants.QUESTION_MARK_DELIMITER + queryString);

		final String redirectUrl = String.format(
				"%s?response_type=code&client_id=%s&pfidpadapterid=%s&scope=%s&redirect_uri=%s&state=%s",
				authorizationEndpoint, clientId, adapterId, scopes, redirectUri, state);

		return redirectUrl;
	}

	/**
	 * Creates the redirect URL from configuration values.
	 *
	 * @param request
	 *            the request object.
	 * @return the redirect URL to be used to initiate a login with Ping Federate.
	 * @throws IOException 
	 */
	public static String createRedirectUrlToDBIAccount(final HttpServletRequest request, final String masterKey) throws IOException
	{

		final String authorizationEndpoint = RegistrationConstants.AUTHORIZATION_ENDPOINT;		
		SecretStoreUtils secretUtil = new SecretStoreUtils(masterKey.toCharArray());
		final String clientId = String.valueOf(secretUtil.getSecrete(RegistrationConstants.CLIENT_ID));

		final String adapterId = RegistrationConstants.ADAPTER_ID;

		final String scopes = RegistrationConstants.SCOPES.replace(" ", RegistrationConstants.PERCENT_TWENTY);

		final String redirectUri = RegistrationConstants.REDIRECT_LOGIN_URI;
		final String queryString = request.getQueryString();
		final String requestUrl = request.getRequestURL().toString();
		final URL url = new URL(requestUrl);

		final String state = url.getPath() + (queryString == null ? "" : RegistrationConstants.QUESTION_MARK_DELIMITER + queryString);

		final String redirectUrl = String.format(
				"%s?response_type=code&client_id=%s&pfidpadapterid=%s&scope=%s&redirect_uri=%s&state=%s&isExists=%s",
				authorizationEndpoint, clientId, adapterId, scopes, redirectUri, state, true);

			
		return redirectUrl;
	}

	/**
	 * Determines if a user needs to login.
	 *
	 * @param request
	 *            the request object.
	 * @return returns a boolean indicating that the user needs to login.
	 * @throws Exception 
	 */
	private static boolean isLoginRequired(final HttpServletRequest request, final String masterKey) throws Exception
	{
		// If the access token cannot be found in the session then we need to login
		final DecodedJWT idToken = (DecodedJWT) request.getSession().getAttribute(RegistrationConstants.ID_TOKEN);
		return idToken == null || !new TokenValidator(masterKey.toCharArray()).isIdTokenValid(idToken.getToken());
	}

	public static String formatDate(String dateOfBirth) throws ParseException
	{
		
		try
		{
			Date date = new SimpleDateFormat(RegistrationConstants.YYYY_MM_DD_HH_MMSS).parse(dateOfBirth);
			dateOfBirth = new SimpleDateFormat(RegistrationConstants.BUSINESS_DOB_FORMAT).format(date);
		}
		catch (ParseException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
		return dateOfBirth;
	}

	public static Date getDate(String dateOfBirth) throws ParseException
	{
		String datePattern = com.kpmg.registration.utils.DateUtils.determineDateFormat(dateOfBirth);
		Date date = null;
		try
		{
			if (!isNullOrEmptyString(datePattern))
			{
				date = new SimpleDateFormat(datePattern).parse(dateOfBirth);
			}
			else
			{
				GeneralizedTime gt = new GeneralizedTime(dateOfBirth);
				date = gt.getCalendar().getTime();
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(date);
				calendar.add(Calendar.HOUR_OF_DAY, 1);
				date = calendar.getTime();
			}
		}
		catch (ParseException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
		return date;
	}

	/**
	 * Returns DBI Account Form object with data from ID Token
	 * 
	 * @param accessToken
	 * @param idToken
	 * @return
	 * @throws ParseException
	 */
	public static DBIAccountFormBean getDBIAccountBean(final DecodedJWT idToken) throws ParseException
	{

		DBIAccountFormBean dbiAccountForm = null;
		if (idToken != null)
		{
			dbiAccountForm = new DBIAccountFormBean();
			String gender = idToken.getClaim(RegistrationConstants.GENDER).asString();
			if (!isNullOrEmptyString(gender))
			{

				if (RegistrationConstants.GENDER_MALE.equalsIgnoreCase(gender))
				{
					dbiAccountForm.setTitle(RegistrationConstants.MR);					
				}
				else
				{
					dbiAccountForm.setTitle(RegistrationConstants.MS);					
				}
				dbiAccountForm.setGender(gender);

			}

			String displayName = idToken.getClaim(RegistrationConstants.NAME).asString();
			if (!isNullOrEmptyString(displayName))
			{
				dbiAccountForm.setDisplayName(displayName.toUpperCase());				
			}

			Date dateOfBirth = getDate(idToken.getClaim(RegistrationConstants.BIRTH_DATE).asString());

			if (null != dateOfBirth)
			{
				String generalizedDateString = getGeneralizedTime(dateOfBirth);
				dbiAccountForm.setDateOfBirth(generalizedDateString);
			}

			String address = idToken.getClaim(RegistrationConstants.ADDRESS).asString();
			if (!isNullOrEmptyString(address))
			{
				String postalCode = idToken.getClaim(RegistrationConstants.POSTCODE).asString();
				if (!isNullOrEmptyString(postalCode))
				{
					address = address + " " + postalCode;
					dbiAccountForm.setPostalCode(postalCode);					
				}
				dbiAccountForm.setAddress(address.toUpperCase());				
			}

			String email = idToken.getClaim(RegistrationConstants.SUBJECT).asString();
			if (!isNullOrEmptyString(email))
			{
				dbiAccountForm.setEmail(email);				
			}

			String firstName = idToken.getClaim(RegistrationConstants.GIVENNAME).asString();
			if (!isNullOrEmptyString(firstName))
			{
				dbiAccountForm.setFirstName(firstName.toUpperCase());				
			}

			String lastName = idToken.getClaim(RegistrationConstants.FAMILY_NAME).asString();
			if (!isNullOrEmptyString(lastName))
			{
				dbiAccountForm.setLastName(lastName.toUpperCase());				
			}
		}
		else
		{
			System.out.println("Null ID token");
		}
		return dbiAccountForm;

	}

	public static String getEmailAddressOfUser(final DecodedJWT idToken)
	{
		String email = "";
		if (idToken != null)
		{
			email = idToken.getClaim(RegistrationConstants.SUBJECT).asString();
		}
		return email;
	}

	/**
	 * Set Model to attributes from ID_TOKEN
	 * 
	 * @param accessToken
	 * @param idToken
	 * @param model
	 * @return
	 * @throws ParseException
	 */
	public static void getUserDetailsAsModel(final DecodedJWT idToken, final Model model) throws ParseException
	{

		if (idToken != null)
		{
			String gender = idToken.getClaim(RegistrationConstants.GENDER).asString();
			if (!isNullOrEmptyString(gender))
			{
				model.addAttribute(RegistrationConstants.GENDER, gender.toUpperCase());

				if (RegistrationConstants.GENDER_MALE.equals(gender))
				{
					model.addAttribute(RegistrationConstants.TITLE, RegistrationConstants.MR);
				}
				else
				{
					model.addAttribute(RegistrationConstants.TITLE, RegistrationConstants.MS);
				}
			}

			Date dateOfBirth = getDate(idToken.getClaim(RegistrationConstants.BIRTH_DATE).asString());

			if (null != dateOfBirth)
			{
				model.addAttribute(RegistrationConstants.DATE_OF_BIRTH, getGeneralizedTime(dateOfBirth));
			}

			String address = idToken.getClaim(RegistrationConstants.ADDRESS).asString();
			if (!isNullOrEmptyString(address))
			{
				String postalCode = idToken.getClaim(RegistrationConstants.POSTCODE).asString();
				if (!isNullOrEmptyString(postalCode))
				{
					address = address + " " + postalCode;
					model.addAttribute(RegistrationConstants.POSTCODE, postalCode);
				}
				model.addAttribute(RegistrationConstants.ADDRESS, address.toUpperCase());
			}

			String firstName = idToken.getClaim(RegistrationConstants.GIVENNAME).asString();
			if (!isNullOrEmptyString(firstName))
			{
				model.addAttribute(RegistrationConstants.FIRST_NAME, firstName.toUpperCase());
			}

			String lastName = idToken.getClaim(RegistrationConstants.FAMILY_NAME).asString();

			if (!isNullOrEmptyString(lastName))
			{
				model.addAttribute(RegistrationConstants.LAST_NAME, lastName.toUpperCase());
			}

			if (!isNullOrEmptyString(firstName) && !isNullOrEmptyString(lastName))
			{
				model.addAttribute(RegistrationConstants.DISPLAY_NAME, (firstName + " " + lastName).toUpperCase());
			}

			String email = idToken.getClaim(RegistrationConstants.SUBJECT).asString();

			if (!isNullOrEmptyString(email))
			{
				model.addAttribute(RegistrationConstants.EMAIL, email);
			}
		}
		else
		{
			System.err.println("Null ID token");
		}
	}

	public static boolean isNullOrEmptyString(String key)
	{
		if (key == null || key.isEmpty() || key.equals(" "))
		{
			return true;
		}
		return false;
	}

	public static String getGeneralizedTime(Date date)
	{
		return DateUtils.getGeneralizedTime(date);
	}

	public static String getUserInfo(final DecodedJWT accessToken) throws IOException
	{

		final String userinfoEndpoint = RegistrationConstants.USERINFO_ENDPOINT;

		Feature feature = OAuth2ClientSupport.feature(accessToken.getToken());
		Client client = ClientBuilder.newClient();
		client.register(feature);

		Response restResponse = client.target(userinfoEndpoint).request().get();

		if (restResponse.getStatus() == 401)
		{
			return RegistrationConstants.UNAUTHORISED;
		}
		else
		{
			String jsonResponse = restResponse.readEntity(String.class);
			return jsonResponse;
		}
	}

	
	public static UserExistsResponseBean checkIfUserExists(String uniqueIdentifier,
			DBIAccountFormBean dbiAccountFormBean, PingDatastoreProcessor datastoreProcessor) throws ParseException, NamingException
	{
		UserExistsResponseBean userExists = datastoreProcessor.isUserExists(dbiAccountFormBean, uniqueIdentifier);
		return userExists;
	}
	
	public static void invalidateSession(final HttpServletRequest request) 
	{
		request.getSession().invalidate();
		request.getSession(false);
	}
}
