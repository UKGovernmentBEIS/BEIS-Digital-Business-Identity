/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.registration.beans;

import java.util.List;

public class UserInfoResponseBean
{
	String sub;
	List<Business> business;
	List<DelegatesLink> delegates;
	
	public String getSub()
	{
		return sub;
	}
	public void setSub(String sub)
	{
		this.sub = sub;
	}
	public List<Business> getBusiness()
	{
		return business;
	}
	public void setBusiness(List<Business> business)
	{
		this.business = business;
	}
	public List<DelegatesLink> getDelegates()
	{
		return delegates;
	}
	public void setDelegates(List<DelegatesLink> delegates)
	{
		this.delegates = delegates;
	}
	
	
}
