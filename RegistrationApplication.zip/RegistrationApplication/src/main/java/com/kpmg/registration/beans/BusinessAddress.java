/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.registration.beans;

public class BusinessAddress
{
	private String locality;
	private String premise;
	private String addressLine1;
	private String postcode;
	private String verifiedDate;
	private String verificationSource;

	public BusinessAddress()
	{
		// TODO Auto-generated constructor stub
	}

	public BusinessAddress(String locality, String premise, String addressLine1, String postcode)
	{
		super();
		this.locality = locality;
		this.premise = premise;
		this.addressLine1 = addressLine1;
		this.postcode = postcode;
	}

	public String getLocality()
	{
		return locality;
	}

	public void setLocality(String locality)
	{
		this.locality = locality;
	}

	public String getPremise()
	{
		return premise;
	}

	public void setPremise(String premise)
	{
		this.premise = premise;
	}

	public String getAddressLine1()
	{
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1)
	{
		this.addressLine1 = addressLine1;
	}

	public String getPostcode()
	{
		return postcode;
	}

	public void setPostcode(String postcode)
	{
		this.postcode = postcode;
	}

	public String getVerifiedDate()
	{
		return verifiedDate;
	}

	public void setVerifiedDate(String verifiedDate)
	{
		this.verifiedDate = verifiedDate;
	}

	public String getVerificationSource()
	{
		return verificationSource;
	}

	public void setVerificationSource(String verificationSource)
	{
		this.verificationSource = verificationSource;
	}
}
