/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.registration.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpmg.datastore.processor.PingDatastoreProcessor;
import com.kpmg.registration.beans.Business;
import com.kpmg.registration.beans.DelegatesLink;
import com.kpmg.registration.constants.RegistrationConstants;

public class BusinessUtils
{

	public static HashMap<String, Business> getBusinessOwnedByUser(final DecodedJWT accessToken) throws IOException
	{
		HashMap<String, Business> ownedBusinessMap = new HashMap<String, Business>();
		String userinfoResponse = ControllerUtils.getUserInfo(accessToken);
		try
		{
			ObjectMapper mapper = new ObjectMapper();
			List<Business> businessList = new ArrayList<Business>();

			if (isJsonArray(userinfoResponse, RegistrationConstants.BUSINESS))
			{
				JSONArray jsonArray =  (JSONArray) new JSONObject(userinfoResponse).get(RegistrationConstants.BUSINESS);
				for(int i=0; i<jsonArray.length();i++) 
				{
					businessList.add(mapper.readValue((String)jsonArray.get(i), Business.class));
				}
			}
			else
			{
				String businessStr = (String) new JSONObject(userinfoResponse).get(RegistrationConstants.BUSINESS);
				businessList.add(mapper.readValue(businessStr, Business.class));
			}
			
			for (Business business : businessList)
			{
				if (business.getIsOwner())
				{
					ownedBusinessMap.put(business.getChBusinessId().getValue(), business);
				}
			}
			
			
		}
		catch (JSONException e)
		{
			System.err.println("No businesses for user.");
		}
		return ownedBusinessMap;
	}

	public static HashMap<String, Business> getBusinessDelegatedByUser(final DecodedJWT accessToken) throws IOException
	{
		HashMap<String, Business> delegatedBusinessMap = new HashMap<String, Business>();
		String userinfoResponse = ControllerUtils.getUserInfo(accessToken);
		try
		{
			

			ObjectMapper mapper = new ObjectMapper();
			List<Business> businessList = new ArrayList<Business>();
			if (isJsonArray(userinfoResponse, RegistrationConstants.BUSINESS))
			{
				JSONArray jsonArray =  (JSONArray) new JSONObject(userinfoResponse).get(RegistrationConstants.BUSINESS);
				for(int i=0; i<jsonArray.length();i++) 
				{
					businessList.add(mapper.readValue((String)jsonArray.get(i), Business.class));
				}
			}
			else
			{
				String businessStr = (String) new JSONObject(userinfoResponse).get(RegistrationConstants.BUSINESS);
				businessList.add(mapper.readValue(businessStr, Business.class));
			}
			
			for (Business business : businessList)
			{
				if (business.getIsDelegate())
				{
					delegatedBusinessMap.put(business.getChBusinessId().getValue(), business);
				}
			}
		}
		catch (JSONException e)
		{
			System.err.println("No businesses for user.");
		}

		return delegatedBusinessMap;
	}

	private static boolean isJsonArray(String jsonString, String attribute)
	{
		boolean responseIsArray = true;
		JSONObject jsonObj = new JSONObject(jsonString);
		Object parsedObject = jsonObj.get(attribute);

		if (parsedObject != null && !(parsedObject instanceof JSONArray))
		{
			String parsedJsonStr = (String) parsedObject;

			if (!parsedJsonStr.trim().startsWith("["))
			{
				responseIsArray = false;
			}
		}
		return responseIsArray;
	}
	
	/**
	 * Return list of delegate UID of user's business
	 * 
	 * @param accessToken
	 * @param businessId
	 * @return
	 * @throws IOException
	 */
	public static List<String> getBusinessDelegates(final DecodedJWT accessToken, String businessId) throws IOException
	{
		List<String> delegatesList = new ArrayList<String>();
		String userinfoResponse = ControllerUtils.getUserInfo(accessToken);		
		try
		{
			
			
			ObjectMapper mapper = new ObjectMapper();
			List<DelegatesLink> delegatesLinkList = new ArrayList<DelegatesLink>();

			if (isJsonArray(userinfoResponse, RegistrationConstants.DELEGATES))
			{
				JSONArray jsonArray =  (JSONArray) new JSONObject(userinfoResponse).get(RegistrationConstants.DELEGATES);
				for(int i=0; i<jsonArray.length();i++) 
				{
					delegatesLinkList.add(mapper.readValue((String)jsonArray.get(i), DelegatesLink.class));
				}
			}
			else
			{
				String delegatesStr = (String) new JSONObject(userinfoResponse).get(RegistrationConstants.DELEGATES);
				delegatesLinkList.add(mapper.readValue(delegatesStr, DelegatesLink.class));
			}
			
			for (DelegatesLink delegateLink : delegatesLinkList)
			{
				if (delegateLink.getChBusinessId().equalsIgnoreCase(businessId))
				{
					delegatesList.add(delegateLink.getUid());
				}
			}
		}
		catch (JSONException e)
		{
			System.err.println("No delegates for user.");
		}
		return delegatesList;
	}
	
	/**
	 * Return list of delegate UID of user's business
	 * 
	 * @param accessToken
	 * @param businessId
	 * @return
	 * @throws IOException
	 */
	public static List<DelegatesLink> getBusinessDelegatesLink(final DecodedJWT accessToken, String businessId) throws IOException
	{
		List<DelegatesLink> businessDelegatesList = new ArrayList<DelegatesLink>();
		String userinfoResponse = ControllerUtils.getUserInfo(accessToken);		
		try
		{
			
			
			ObjectMapper mapper = new ObjectMapper();
			List<DelegatesLink> delegatesLinkList = new ArrayList<DelegatesLink>();

			if (isJsonArray(userinfoResponse, RegistrationConstants.DELEGATES))
			{
				JSONArray jsonArray =  (JSONArray) new JSONObject(userinfoResponse).get(RegistrationConstants.DELEGATES);
				for(int i=0; i<jsonArray.length();i++) 
				{
					delegatesLinkList.add(mapper.readValue((String)jsonArray.get(i), DelegatesLink.class));
				}
			}
			else
			{
				String delegatesStr = (String) new JSONObject(userinfoResponse).get(RegistrationConstants.DELEGATES);
				delegatesLinkList.add(mapper.readValue(delegatesStr, DelegatesLink.class));
			}
			
			for (DelegatesLink delegateLink : delegatesLinkList)
			{
				if (delegateLink.getChBusinessId().equalsIgnoreCase(businessId))
				{
					businessDelegatesList.add(delegateLink);
				}
			}
		}
		catch (JSONException e)
		{
			System.err.println("No delegates for user.");
		}
		return businessDelegatesList;
	}
	
	public static HashMap<String, Business> getBusinessOwnedByUsedId(final String email, PingDatastoreProcessor datastoreProcessor) throws IOException
	{
		HashMap<String, Business> ownedBusinessMap = new HashMap<String, Business>();		
		try
		{
			ownedBusinessMap = datastoreProcessor.getUsersOwnedBusinesses(email);
		}
		catch (Exception e)
		{
			System.err.println("Error occured while getting user owned businesses.");
		}
		return ownedBusinessMap;
	}
	
	public static HashMap<String, Business> getDelegateBusinessByUsedId(final String email, PingDatastoreProcessor datastoreProcessor) throws IOException
	{
		HashMap<String, Business> delegateBusinessMap = new HashMap<String, Business>();		
		try
		{
			delegateBusinessMap = datastoreProcessor.getUsersDelegateBusinesses(email);
		}
		catch (Exception e)
		{
			System.err.println("Error occured while getting user owned businesses.");
		}
		return delegateBusinessMap;
	}
	
}
