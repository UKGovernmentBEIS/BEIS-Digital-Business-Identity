/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.registration.webservice.processor;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.thymeleaf.util.StringUtils;

import com.kpmg.basic.registration.form.beans.SearchCompanyBean;
import com.kpmg.registration.beans.Business;
import com.kpmg.registration.beans.Company;
import com.kpmg.registration.beans.CompanyOwnerResponse;
import com.kpmg.registration.beans.PersonWithInsolvencyNoticeResponse;
import com.kpmg.registration.utils.ControllerUtils;
import com.kpmg.registration.webservice.service.impl.ServiceController;

public class WebserviceProcessor
{
	public static HashMap<String, Company> searchAndFilterCompanies(SearchCompanyBean searchCompanyBean, String masterKey)
			throws Exception
	{
		HashMap<String, Company> filteredCompanyMap = new HashMap<String, Company>();

		try
		{
			if (null != searchCompanyBean)
			{
				List<Company> companiesSearchResultList = ServiceController.getAssuranceEngineService(masterKey)
						.searchByCompanyName(searchCompanyBean.getCompanyNameToSearch());

				// filter list by address
				for (Company company : companiesSearchResultList)
				{
					if (company.getCompanyName().toLowerCase()
							.contains(searchCompanyBean.getCompanyNameToSearch().toLowerCase()))
					{
						boolean matched = true;

						if (!StringUtils.isEmptyOrWhitespace(searchCompanyBean.getPremise())
								&& !StringUtils.isEmptyOrWhitespace(company.getPremise()))
						{
							matched = matched && company.getPremise().equalsIgnoreCase(searchCompanyBean.getPremise());

						}

						if (matched && !StringUtils.isEmptyOrWhitespace(searchCompanyBean.getLocality())
								&& !StringUtils.isEmptyOrWhitespace(company.getLocality()))
						{
							matched = matched
									&& company.getLocality().equalsIgnoreCase(searchCompanyBean.getLocality());
						}

						if (matched && !StringUtils.isEmptyOrWhitespace(searchCompanyBean.getAddressLine1())
								&& !StringUtils.isEmptyOrWhitespace(company.getAddressLine1()))
						{
							matched = matched
									&& company.getAddressLine1().equalsIgnoreCase(searchCompanyBean.getAddressLine1());

						}

						if (matched && !StringUtils.isEmptyOrWhitespace(searchCompanyBean.getAddressLine2())
								&& !StringUtils.isEmptyOrWhitespace(company.getAddressLine2()))
						{
							matched = matched
									&& company.getAddressLine2().equalsIgnoreCase(searchCompanyBean.getAddressLine2());
						}

						if (matched && !StringUtils.isEmptyOrWhitespace(searchCompanyBean.getPostCode())
								&& !StringUtils.isEmptyOrWhitespace(company.getPostCode()))
						{
							matched = matched
									&& company.getPostCode().equalsIgnoreCase(searchCompanyBean.getPostCode());
						}

						if (matched)
						{
							filteredCompanyMap.put(company.getChCompanyId(), company);
						}
					}
				}
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}

		return filteredCompanyMap;
	}

	public static Company searchCompanyByName(String searchCompanyByName, String masterKey) throws Exception
	{
		Company result = null;
		try
		{
			if (!ControllerUtils.isNullOrEmptyString(searchCompanyByName))
			{
				List<Company> companiesSearchResultList = ServiceController.getAssuranceEngineService(masterKey)
						.searchByCompanyName(searchCompanyByName);

				// filter list by address
				for (Company company : companiesSearchResultList)
				{
					if (company.getCompanyName().equalsIgnoreCase(searchCompanyByName))
					{
						result = company;
						break;
					}
				}
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}

		return result;
	}

	public static Business verifyBusinessInformation(Business businessInformation, String masterKey) throws Exception
	{

		try
		{
			Business responseResult = ServiceController.getAssuranceEngineService(masterKey)
					.verifyBusinessInformation(businessInformation);

			if (null != responseResult)
			{
				return responseResult;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		return null;
	}

	public static CompanyOwnerResponse isBusinessOwner(String companyNumber, String companyName, String firstname,
			String middlename, String lastname, String postcode, String masterKey) throws Exception
	{
		CompanyOwnerResponse serviceResponse = null;
		try
		{
			serviceResponse = ServiceController.getAssuranceEngineService(masterKey).isBusinessOwner(companyNumber, companyName,
					firstname, middlename, lastname, postcode);

		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		return serviceResponse;
	}

	public static PersonWithInsolvencyNoticeResponse isPersonWithInsolvencyNotice(String companyNumber,
			String companyName, String firstname, String middlename, String lastname, String postcode, String masterKey) throws Exception
	{
		PersonWithInsolvencyNoticeResponse serviceResponse = null;
		try
		{
			serviceResponse = ServiceController.getAssuranceEngineService(masterKey).isPersonWithInsolvencyNotices(companyNumber,
					companyName, firstname, middlename, lastname, postcode);

		}
		catch (IOException e)
		{
			e.printStackTrace();
			throw e;
		}
		return serviceResponse;
	}
}
