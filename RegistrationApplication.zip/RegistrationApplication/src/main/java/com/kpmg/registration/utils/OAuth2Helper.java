/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.registration.utils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import com.kpmg.registration.constants.RegistrationConstants;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * A class to help exchange the authentication code for a set of tokens.
 */
public class OAuth2Helper
{
	private static final MediaType X_WWW_FORM_URLENCODED = MediaType.parse(RegistrationConstants.APPLICATION_X_WWW_FORM_URLENCODED);
	private static final MediaType JSON = MediaType.parse(RegistrationConstants.APPLICATION_JSON);
	private String tokenUrl;

	/**
	 * Constructor.
	 *
	 * @param tokenUrl
	 *            the token URL for Ping Federate.
	 */
	public OAuth2Helper(final String tokenUrl)
	{
		this.tokenUrl = tokenUrl;
	}

	/**
	 * Returns the token URL.
	 *
	 * @return the token URL.
	 */
	public String getTokenUrl()
	{
		return tokenUrl;
	}

	/**
	 * Swaps the authentication code for an OpenID Connect token.
	 *
	 * @param clientId
	 *            the client ID.
	 * @param clientSecret
	 *            the client secret.
	 * @param redirectUri
	 *            the redirect URI of the client.
	 * @param scope
	 *            the list of scopes requested.
	 * @param authorizationCode
	 *            the authentication code returned by the server.
	 * @return returns a string of the entire set of tokens.
	 * @throws IOException
	 *             Signals that an I/O exception of some sort has occurred.
	 */
	public String swapAuthenticationCode(final String clientId, final char[] clientSecret, final String redirectUri,
			final String scope, final String authorizationCode) throws IOException
	{

		String token = null;

		final String basicAuthString = clientId + ":" + String.valueOf(clientSecret);
		final String basicAuth = Base64.getEncoder().encodeToString(basicAuthString.getBytes(StandardCharsets.UTF_8));
		final RequestBody body = RequestBody.create(X_WWW_FORM_URLENCODED,
				String.format("grant_type=authorization_code&code=%s&redirect_uri=%s&scope=%s", authorizationCode,
						redirectUri, scope));

		// Don't ever do this in production because it allows any certificate!
		final OkHttpClient client = OkHttpHelper.getUnsafeOkHttpClient();

		final Request request = new Request.Builder().url(tokenUrl).post(body)
				.addHeader(RegistrationConstants.AUTHORIZATION, RegistrationConstants.BASIC + basicAuth)
				.addHeader(RegistrationConstants.CONTENT_TYPE, RegistrationConstants.APPLICATION_X_WWW_FORM_URLENCODED).build();

		final Response response = client.newCall(request).execute();

		if (response.isSuccessful())
		{
			token = response.body().string();
		}

		return token;
	}

	public void singleLogout(final String clientId, final char[] clientSecret, final String sessionId) throws IOException
	{

		final String basicAuthString = clientId + ":" + String.valueOf(clientSecret);
		final String basicAuth = Base64.getEncoder().encodeToString(basicAuthString.getBytes(StandardCharsets.UTF_8));
		final String json = "{\"id\":\"%s\"}";
        final RequestBody body = RequestBody.create(JSON, String.format(json, sessionId));
		
        // Don't ever do this in production because it allows any certificate!
		final OkHttpClient client = OkHttpHelper.getUnsafeOkHttpClient();

		final Request request = new Request.Builder().url(tokenUrl).post(body)
				.addHeader(RegistrationConstants.AUTHORIZATION, RegistrationConstants.BASIC + basicAuth)
				.addHeader(RegistrationConstants.X_XSRF_HEADER, RegistrationConstants.PING_FEDERATE)
				.addHeader(RegistrationConstants.CONTENT_TYPE, RegistrationConstants.APPLICATION_JSON).build();
	
		final Response response = client.newCall(request).execute();
		
		if (response.isSuccessful())
		{
			System.out.println("logout successful!!");
		}

	}
	
	public String checkAccessTokenValidity(final String accessToken, String clientId, char[] clientSecret) throws IOException
	{
		String responseString = null;
		final String basicAuthString = clientId + ":" + String.valueOf(clientSecret);
		final String basicAuth = Base64.getEncoder().encodeToString(basicAuthString.getBytes(StandardCharsets.UTF_8));
		final RequestBody body = RequestBody.create(X_WWW_FORM_URLENCODED,
				String.format("token=%s&token_type_hint=access_token", accessToken));
		final OkHttpClient client = OkHttpHelper.getUnsafeOkHttpClient();

		final Request request = new Request.Builder().url(tokenUrl).post(body)
				.addHeader(RegistrationConstants.AUTHORIZATION, RegistrationConstants.BASIC + basicAuth)
				.addHeader(RegistrationConstants.CONTENT_TYPE, RegistrationConstants.APPLICATION_X_WWW_FORM_URLENCODED).build();

		final Response response = client.newCall(request).execute();
		if (response.isSuccessful())
		{
			responseString = response.body().string();
		}
		return responseString;
	}
}
