/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.registration.beans;

public class DelegatesLink
{
	String chBusinessId;
	
	String uid;
	
	public DelegatesLink()
	{
		
	}
	public DelegatesLink(String chBusinessId, String uid)
	{
		super();
		this.chBusinessId = chBusinessId;
		this.uid = uid;
	}
	public String getChBusinessId()
	{
		return chBusinessId;
	}
	public void setChBusinessId(String chBusinessId)
	{
		this.chBusinessId = chBusinessId;
	}
	public String getUid()
	{
		return uid;
	}
	public void setUid(String uid)
	{
		this.uid = uid;
	}
	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((chBusinessId == null) ? 0 : chBusinessId.hashCode());
		result = prime * result + ((uid == null) ? 0 : uid.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DelegatesLink other = (DelegatesLink) obj;
		if (chBusinessId == null)
		{
			if (other.chBusinessId != null)
				return false;
		}
		else if (!chBusinessId.equals(other.chBusinessId))
			return false;
		if (uid == null)
		{
			if (other.uid != null)
				return false;
		}
		else if (!uid.equals(other.uid))
			return false;
		return true;
	}
	
	
	
}
