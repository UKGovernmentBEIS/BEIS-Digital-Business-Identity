/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.registration.constants;

public interface RegistrationConstants
{
	public static final String COMMA_DELIMITER = ",";
	public static final String AUTHORIZATION_ENDPOINT = "https://<FEDERATION_SERVER_HOSTNAME>:<PORT>/as/authorization.oauth2";
	public static final String TOKEN_ENDPOINT = "https://<FEDERATION_SERVER_HOSTNAME>:<PORT>/as/token.oauth2";
	
	public static final String CLIENT_ID = "client.id";
	public static final String CLIENT_SECRET = "client.secret";
	
	public static final String ADAPTER_ID = "PingDirAuthAdapter";
	public static final String REDIRECT_LOGIN_URI = "http://<HOSTNAME>:<PORT>/authentication/login";
	public static final String SCOPES = "openid profile";
	public static final String USERINFO_ENDPOINT = "https://<FEDERATION_SERVER_HOSTNAME>:<PORT>/idp/userinfo.openid";
	public static final String REVOKE_SESSION_ENDPOINT = "https://<FEDERATION_SERVER_HOSTNAME>:<PORT>/pf-ws/rest/sessionMgmt/revokedSris";
	public static final String PF_ISSUER_URL = "https://<FEDERATION_SERVER_HOSTNAME>:<PORT>";
	public static final String PF_JWKS_URL = "https://<FEDERATION_SERVER_HOSTNAME>:<PORT>/pf/JWKS";
	public static final String PF_INTROSPECT_URL = "https://<FEDERATION_SERVER_HOSTNAME>:<PORT>/as/introspect.oauth2";
	public static final String PF_TOKEN_VALIDATION_ACTIVE = "active";
	
	public static final String UNAUTHORISED = "UNAUTHORISED";
	public static final String GENDER_MALE = "Male";
	public static final String GENDER_FEMALE = "Female";
	
	public static final String BUSINESS_OWNER = "owner";
	public static final String BUSINESS_DELEGATE = "delegate";
	
	public static final String BUSINESS_USERROLE = "userRole";
	public static final String USERROLE_OWNER_KEY ="isOwner";
	public static final String USERROLE_DELEGATE_KEY ="isDelegate";
	
	public static final String BUSINESS_CHID_KEY = "chBusinessId";
	public static final String BUSINESS_NAME_KEY = "businessName";
	public static final String BUSINESS_POSTCODE_KEY = "businessPostCode";
	public static final String BUSINESS_CRN_KEY = "businessCRN";
	public static final String BUSINESS_UTR_KEY = "businessUTR";
	public static final String BUSINESS_DUNN_KEY = "businessDUNN";
	public static final String BUSINESS_VAT_KEY = "businessVAT";
	public static final String BUSINESS_PAYE_KEY = "businessPAYE";
	public static final String BUSINESS_SIC_KEY = "businessSIC";
	public static final String BUSINESS_EMPLOYEES_KEY = "noOfEmployees";
	public static final String BUSINESS_TURNOVER_KEY = "businessTurnOver";
	
	public static final String GENERIC_VALUE_KEY = "value";
	public static final String GENERIC_VERIFIEDDATE_KEY = "verifiedDate";
	public static final String GENERIC_VERIFICATIONSOURCE_KEY = "verificationSource";
	
	public static final String BUSINESS_BANK_KEY = "businessBankDetails";
	public static final String BUSINESS_BANK_SC_KEY = "sortcode";
	public static final String BUSINESS_BANK_AC_KEY = "accountNumber";
	
	public static final String BUSINESS_PSC_KEY = "businessPSC";
	public static final String BUSINESS_PSC_PERSONS_KEY = "personWithSignificantControl";
	public static final String BUSINESS_PSC_NAME_KEY = "name";
	public static final String BUSINESS_PSC_ID_KEY = "pscId";
	
	
	public static final String BUSINESS_ADDRESS_KEY = "businessAddress";
	public static final String BUSINESS_LOCALITY_KEY = "locality";
	public static final String BUSINESS_PREMISE_KEY = "premise";
	public static final String BUSINESS_ADDRESSLINE1_KEY = "addressLine1";
	public static final String BUSINESS_ADDRESS_POSTCODE_KEY = "postcode";
	
	// OIDC 
	public static final String OIDC_ACCESS_TOKEN = "access_token";
	public static final String OIDC_ID_TOKEN = "id_token";
	public static final String OIDC_REFRESH_TOKEN = "refresh_token";
	public static final String OIDC_AUTHCODE = "authcode";
	
	
	//Authetication Controller Constants
	public static final String LOGIN_OPTION = "loginOption";
	
	public static final String PROPKEY_CLIENT_SECRET = "client.secret";
	public static final String STATE="state";
	public static final String CODE="code";
	public static final String MASTER_KEY="masterKey";
	public static final String SESSION_REVOKE_ID="pi.sri";
	
	public static final String AE_CLIENT_ID_PARAM = "client_id";
	public static final String BASE_DN="ldap.base.dn";
	public static final String LDAP_PRINCIPAL ="ldap.principal";
	public static final String LDAP_SECRET = "ldap.secret";
	public static final String LDAP_SERVER_URL = "ldap.server.url";
	
	public static final String BUSINESS_DOB_FORMAT = "dd MMM yyyy";
	
	//LDAP Constants
	public static final String UNIQUE_IDENTIFIER = "uniqueIdentifier";
	public static final String UID = "uid";
	public static final String CN = "cn";
	public static final String SN = "sn";
	public static final String MAIL = "mail";
	public static final String GIVEN_NAME = "givenName";
	public static final String POSTAL_ADDRESS = "postalAddress";
	public static final String POSTAL_CODE = "postalCode";
	public static final String USER_PASSWORD = "userPassword";
	public static final String DATE_OF_BIRTH = "dateOfBirth";
	public static final String DISPLAY_NAME = "displayName";
	public static final String INITIALS = "initials";
	public static final String GENDER = "gender";
	public static final String TITLE = "title";
	public static final String IDENTITY_PROVIDER = "identityprovider";
	
	//ID TOKEN Constants
	public static final String NAME = "name";
	public static final String BIRTH_DATE= "birthdate";
	public static final String ADDRESS= "address";
	public static final String POSTCODE ="postal_code";
	public static final String GIVENNAME ="given_name";
	public static final String MIDDLENAME ="middle_name";
	public static final String FIRST_NAME= "firstName";
	public static final String LAST_NAME= "lastName";
	public static final String FAMILY_NAME = "family_name";
	public static final String EMAIL = "email";
	public static final String SUBJECT = "sub";
	public static final String DBI_VALIDATED = "dbiValidated";

	public static final String CREDENTIALS_PROPERTIES = "credentials.properties";
	
	
	public static final String HOME_PAGE = "home";
	public static final String ERROR_PAGE= "error";
	public static final String DBI_PROFILE_BEAN="dbiAccountBean";
	public static final String DBI_PROFILE_FORM_BEAN="dbiAccountFormBean";
	public static final String LOGOUT_PAGE="logout";
	public static final String REDIRECT_TO= "redirect:";
	
	//AuthenticationController Constants
	public static final String MODEL_BUSINESSES_OF_USER ="businessesOfUser";
	public static final String MODEL_DATE_OF_BIRTH = "dateOfBirth";
	public static final String SESSION_OWNED_BUSINESS="ownedBusiness";
	public static final String SESSION_OWNED_BUSINESS_SIZE="ownedBusinessSize";
	public static final String SESSION_DELEGATE_BUSINESS_SIZE="delegateBusinessSize";
	public static final String SESSIONTIMEOUT_PAGE="sessiontimeout";
	public static final String NAVIGATION_OPTION="usenav";
	public static final String PERCENT_TWENTY="%20";
	public static final String DBILOGIN_PAGE="dbilogin";
	public static final String USER_NOT_EXISTS="userNotExists";
	public static final String USER_EXISTS="userExists";
	public static final String EXISTING_DBILOGIN = "/existing/dbilogin";
	public static final String AUTHENTICATED_SESSIONTIMEOUT = "/authenticated/sessiontimeout";
	public static final String AUTHENTICATED_LOGOUT = "/authenticated/logout";
	
	public static final String ACCESS_TOKEN_TEXT = "accessTokenText";
	public static final String AUTHENTICATION_LOGIN = "/authentication/login";
	public static final String AUTHENTICATED_DBILOGIN = "/authenticated/dbilogin";
	public static final String LOGIN = "login";
	public static final String AUTHENTICATED_HOME = "/authenticated/home";
	
	//DBIAccountController Constants
	public static final String MODEL_ACCOUNT_BEAN="accountBean";
	public static final String REGISTER_CREATEACCOUNT = "/register/createaccount";
	public static final String PERSONAL_DATASTORE_ADDINFO_AJAX_BUSINESSINFOSUBMISSION = "/personal/datastore/addinfo/ajax/businessinfosubmission";
	public static final String DBIACCOUNT_VIEWACCOUNT = "/dbiaccount/viewaccount";
	public static final String CREATEDBIACCOUNT = "/createdbiaccount";
	public static final String VALIDATIONAPPROVAL = "validationapproval";
	public static final String BUSINESS_OBJECT = "businessObject";
	public static final String DBIACCOUNT = "dbiaccount";
	public static final String CREATEACCOUNT = "createaccount";
	public static final String PERSONAL_DATASTORE_AJAX_UNLINK_DELEGATE = "/personal/datastore/ajax/unlink/delegate";
	public static final String EMAIL_DELEGATE = "emailDelegate";
	public static final String BUSINESS_ID = "businessId";
	public static final String PERSONAL_DATASTORE_UNLINK_DELEGATE = "/personal/datastore/unlink/delegate";
	public static final String PERSONAL_DATASTORE_MANAGEUSERS_AJAX_POPULATE_BUSINESS_DELEGATES = "/personal/datastore/manageusers/ajax/populateBusinessDelegates";
	public static final String PERSONAL_DATASTORE_VERIFY_UPDATEBUSINFO = "/personal/datastore/verify/updatebusinfo";
	public static final String UPDATEBUSINESS = "updatebusiness";
	public static final String HOME = "home";
	public static final String ID = "id";
	public static final String PERSONAL_DATASTORE_UPDATEBUSINESS = "/personal/datastore/updatebusiness";
	public static final String VERIFYBUSINESSES = "verifybusinesses";
	public static final String PERSONAL_DATASTORE_VERIFY_AJAX_BUSINESS_INFO = "/personal/datastore/verify/ajax/businessInfo";
	public static final String PERSONAL_DATASTORE_VERIFYBUSINESS = "/personal/datastore/verifybusiness";
	public static final String PERSONAL_DATASTORE_MANAGEUSERS_AJAX_ADD_BUSINESS_TO_USER = "/personal/datastore/manageusers/ajax/addBusinessToUser";
	
	public static final String MANAGEUSERS = "manageusers";
	public static final String UNLINK_DELEGATE_FORM_BEAN = "unlinkDelegateFormBean";
	public static final String PERSONAL_DATASTORE_MANAGEUSERS = "/personal/datastore/manageusers";
	public static final String PERSONAL_DATASTORE_VALIDATIONAPPROVAL = "/personal/datastore/validationapproval";
	public static final String PERSONAL_DATASTORE_ADDINFO_VERIFYBUSINESS = "/personal/datastore/addinfo/verifybusiness";
	public static final String VERIFYRESULT = "verifyresult";
	public static final String PERSONAL_DATASTORE_ADDINFO_AJAX_SEARCH_AND_SELECT_BUSINESS = "/personal/datastore/addinfo/ajax/searchAndSelectBusiness";
	public static final String PERSONAL_DATASTORE_ADDINFO_AJAX_SELECT_BUSINESS = "/personal/datastore/addinfo/ajax/selectBusiness";
	public static final String APPLICATION_JSON = "application/json";
	public static final String FILTERE_COMPANIES_MAP = "filtereCompaniesMap";
	public static final String PERSONAL_DATASTORE_ADDINFO_AJAX_SEARCH_BUSINESS = "/personal/datastore/addinfo/ajax/searchBusiness";
	public static final String ADDINFORMATION = "addinformation";
	public static final String BUSINESS_INFO_FORM_BEAN = "businessInfoFormBean";
	public static final String SEARCH_COMPANY_BEAN = "searchCompanyBean";
	public static final String PERSONAL_DATASTORE_ADDINFO = "/personal/datastore/addinfo";
	public static final String SETUPPERSONALDATASTORE = "setuppersonaldatastore";
	public static final String SETUP_PERSONAL_DATASTORE = "/setup/personal/datastore";
	
	
	public static final String USERINFO = "userinfo";
	public static final String USER_INFORMATION = "userInformation";
	
	public static final String TOKENS_USERINFO = "/tokens/userinfo";
	public static final String ACCESS_TOKEN = "accessToken";
	public static final String PATH_LOGIN = "/login";
	public static final String STARTREGISTRATION = "startregistration";
	public static final String REGISTER_NAVIGATE_IDPDETAILS = "/register/navigate/idpdetails";
	public static final String IDPOPTIONS = "idpoptions";
	public static final String IDENTITY_PROVIDER_SELECT_BEAN = "identityProviderSelectBean";
	public static final String GENERIC = "generic";
	public static final String SELECTIDP = "/selectidp";
	public static final String INDEX = "index";
	
	//PersonalDatastoreProcessor	
	public static final String DELEGATES = "delegates";
	public static final String UID_URL = "uid=";
	public static final String BUSINESS = "business";
	
	//LdapHelper
	public static final String BEIS_PERSON = "beisPerson";
	public static final String INET_ORG_PERSON = "inetOrgPerson";
	public static final String ORGANIZATIONAL_PERSON = "organizationalPerson";
	public static final String PERSON = "person";
	public static final String TOP = "top";
	public static final String OBJECT_CLASS = "objectClass";
	public static final String SIMPLE = "simple";
	public static final String LDAP_CTX_FACTORY = "com.sun.jndi.ldap.LdapCtxFactory";
	


	public static final String MS = "Ms.";
	public static final String MR = "Mr.";
	public static final String YYYY_MM_DD_HH_MMSS = "yyyyMMddHHmmss";
	public static final String ID_TOKEN = "id_token";
	public static final String QUESTION_MARK_DELIMITER = "?";
	public static final String DBILOGIN = "dbilogin";
	public static final String VERIFYLOGIN = "verifylogin";
	
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String BASIC = "Basic ";
	public static final String AUTHORIZATION = "Authorization";
	public static final String APPLICATION_X_WWW_FORM_URLENCODED = "application/x-www-form-urlencoded";
	public static final String PING_FEDERATE = "PingFederate";
	public static final String X_XSRF_HEADER = "X-XSRF-HEADER";
	public static final String SSL = "SSL";
	
	

	public static final String ASSURANCE_ENGINE_IS_PERSON_WITH_INSOLVENCY_NOTICE = "assurance.engine.isPersonWithInsolvencyNotice";
	public static final String POST_CODE = "postCode";
	public static final String MIDDLE_NAME = "middleName";
	public static final String COMPANY_NAME = "companyName";
	public static final String COMPANY_NUMBER = "companyNumber";
	public static final String ASSURANCE_ENGINE_IS_BUSINESS_OWNER = "assurance.engine.isBusinessOwner";
	public static final String BEARER = "Bearer ";
	public static final String ASSURANCE_ENGINE_VERIFY_BUSINESS_ATTRIBUTES = "assurance.engine.verifyBusinessAttributes";
	public static final String SEARCH_STRING = "searchString";
	public static final String ASSURANCE_ENGINE_SEARCH_BY_COMPANY_NAME = "assurance.engine.searchByCompanyName";
	public static final String AE_AUTHORISATION_TOKEN = "ae.authorisation.token";
	public static final String AE_CLIENT_ID = "ae.client.id";
	public static final String ASSURANCE_ENGINE_RS_BASE_URL = "assurance.engine.rs.base.url";
	public static final String RESOURCES_PROPERTIES = "resources.properties";
}
