/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.registration.beans;

import java.util.List;

public class Company {
	private String companyName;
	private String chCompanyId;
	private String companyDirector;
	private Double turnover;
	private Long noOfEmployees;
	private String chCompanyLink;
	private String premise;
	private String locality;
	private String addressLine1;
	private String addressLine2;
	private String postCode;
	private List<PersonWithSignificantControl> personWithSignificantControl;
	private boolean hasCharges;
	private boolean registeredOfficeIsInDispute;
	private String companyStatus;
	private String companyType;
	private List<String> sicCodes;
	private String businessUTR;
	private String businessDUNN;
	private String businessVAT;
	private String businessPAYE;
	
	private String sortcode;
	private String accountNumber;

	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getChCompanyId() {
		return chCompanyId;
	}
	public void setChCompanyId(String chCompanyId) {
		this.chCompanyId = chCompanyId;
	}
	public String getChCompanyLink() {
		return chCompanyLink;
	}
	public void setChCompanyLink(String chCompanyLink) {
		this.chCompanyLink = chCompanyLink;
	}
	public String getCompanyDirector() {
		return companyDirector;
	}
	public void setCompanyDirector(String companyDirector) {
		this.companyDirector = companyDirector;
	}
	public Double getTurnover() {
		return turnover;
	}
	public void setTurnover(double turnover) {
		this.turnover = turnover;
	}
	public Long getNoOfEmployees() {
		return noOfEmployees;
	}
	public void setNoOfEmployees(long noOfEmployees) {
		this.noOfEmployees = noOfEmployees;
	}
	public String getPremise() {
		return premise;
	}
	public void setPremise(String premise) {
		this.premise = premise;
	}
	public String getLocality() {
		return locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}	
	
	public List<PersonWithSignificantControl> getPersonWithSignificantControl() {
		return personWithSignificantControl;
	}
	public void setPersonWithSignificantControl(List<PersonWithSignificantControl> personWithSignificantControl) {
		this.personWithSignificantControl = personWithSignificantControl;
	}
	
	public boolean isHasCharges() {
		return hasCharges;
	}
	public void setHasCharges(boolean hasCharges) {
		this.hasCharges = hasCharges;
	}
	public boolean isRegisteredOfficeIsInDispute() {
		return registeredOfficeIsInDispute;
	}
	public void setRegisteredOfficeIsInDispute(boolean registeredOfficeIsInDispute) {
		this.registeredOfficeIsInDispute = registeredOfficeIsInDispute;
	}
	public String getCompanyStatus() {
		return companyStatus;
	}
	public void setCompanyStatus(String companyStatus) {
		this.companyStatus = companyStatus;
	}	
	public String getCompanyType() {
		return companyType;
	}
	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}

	public List<String> getSicCodes() {
		return sicCodes;
	}
	public void setSicCodes(List<String> sicCodes) {
		this.sicCodes = sicCodes;
	}
	public String getBusinessUTR()
	{
		return businessUTR;
	}
	public void setBusinessUTR(String businessUTR)
	{
		this.businessUTR = businessUTR;
	}
	public String getBusinessDUNN()
	{
		return businessDUNN;
	}
	public void setBusinessDUNN(String businessDUNN)
	{
		this.businessDUNN = businessDUNN;
	}
	public String getBusinessVAT()
	{
		return businessVAT;
	}
	public void setBusinessVAT(String businessVAT)
	{
		this.businessVAT = businessVAT;
	}
	public String getBusinessPAYE()
	{
		return businessPAYE;
	}
	public void setBusinessPAYE(String businessPAYE)
	{
		this.businessPAYE = businessPAYE;
	}
	public String getSortcode()
	{
		return sortcode;
	}
	public void setSortcode(String sortcode)
	{
		this.sortcode = sortcode;
	}
	public String getAccountNumber()
	{
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber)
	{
		this.accountNumber = accountNumber;
	}			
}
