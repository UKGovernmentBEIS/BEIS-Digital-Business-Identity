/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.registration.webservice.service;

import java.util.List;

import com.kpmg.registration.beans.Business;
import com.kpmg.registration.beans.Company;
import com.kpmg.registration.beans.CompanyOwnerResponse;
import com.kpmg.registration.beans.PersonWithInsolvencyNoticeResponse;

public interface AssuranceEngineService
{

	List<Company> searchByCompanyName(String companyName) throws Exception;

	Business verifyBusinessInformation(Business businessInformation) throws Exception;

	CompanyOwnerResponse isBusinessOwner(String companyNumber, String companyName, String firstname, String middlename,
			String lastname, String postcode) throws Exception;

	PersonWithInsolvencyNoticeResponse isPersonWithInsolvencyNotices(String companyNumber, String companyName, String firstname, String middlename,
			String lastname, String postcode) throws Exception;

}
