/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.basic.registration.controller;

import java.io.IOException;
import java.text.ParseException;

import javax.naming.NamingException;
import javax.security.sasl.AuthenticationException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.kpmg.basic.registration.form.beans.BusinessInformationFormBean;
import com.kpmg.basic.registration.form.beans.DBIAccountFormBean;
import com.kpmg.basic.registration.form.beans.UserExistsResponseBean;
import com.kpmg.datastore.processor.PingDatastoreProcessor;
import com.kpmg.datastore.utils.BusinessObject;
import com.kpmg.registration.beans.Business;
import com.kpmg.registration.constants.RegistrationConstants;
import com.kpmg.registration.utils.ControllerUtils;
import com.kpmg.registration.utils.TokenValidator;
import com.nimbusds.jwt.proc.BadJWTException;

@Controller
@SpringBootApplication
@Component
public class DBIAccountController 
{
	private String masterKeyArgs;

	@Autowired
	public DBIAccountController(ApplicationArguments args) throws AuthenticationException
	{
		boolean isMasterKey = args.containsOption(RegistrationConstants.MASTER_KEY);

		if (isMasterKey)
		{
			masterKeyArgs = args.getOptionValues(RegistrationConstants.MASTER_KEY).get(0);
		}
		else
		{
			throw new AuthenticationException(
					"Authetication failed due to missing master key. Please provide correct master key.");
		}

	}

	/**
	 * @purpose Redirect to createaccount.html
	 * @param request
	 * @param response
	 * @param dbiAccountFormBean
	 * @param result
	 * @param model
	 * @return
	 */
	@RequestMapping(value = RegistrationConstants.CREATEDBIACCOUNT)
	private String createAccount(final HttpServletRequest request, final HttpServletResponse response,
			@Valid @ModelAttribute(RegistrationConstants.DBI_PROFILE_FORM_BEAN) DBIAccountFormBean dbiAccountFormBean, BindingResult result,
			final Model model)
	{
		try
		{

			ControllerUtils.redirectIfLoginRequired(request, response,masterKeyArgs);
			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null && validator.isAccessTokenValid(accessToken.getToken()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					dbiAccountFormBean = (DBIAccountFormBean) request.getSession().getAttribute(RegistrationConstants.DBI_PROFILE_BEAN);
					model.addAttribute(RegistrationConstants.DBI_PROFILE_FORM_BEAN, dbiAccountFormBean);
				}
				else
				{
					ControllerUtils.invalidateSession(request);
					return RegistrationConstants.SESSIONTIMEOUT_PAGE;
				}
			}
			
		}
		catch (BadJWTException e)
		{
			ControllerUtils.invalidateSession(request);
			return RegistrationConstants.SESSIONTIMEOUT_PAGE;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
			return RegistrationConstants.ERROR_PAGE;
		}
		return RegistrationConstants.CREATEACCOUNT;
	}

	/**
	 * @purpose Get account details from front end and create DBI account in datastore
	 * @since January 26, 2020
	 * @param request
	 * @param response
	 * @param dbiAccountFormBean
	 * @param result
	 * @param model
	 * @return
	 * @throws IOException
	 * @throws ParseException
	 * @throws NamingException
	 */
	@RequestMapping(value = RegistrationConstants.REGISTER_CREATEACCOUNT)
	private String postAccountDetails(final HttpServletRequest request, final HttpServletResponse response,
			@Valid @ModelAttribute(RegistrationConstants.DBI_PROFILE_FORM_BEAN) DBIAccountFormBean dbiAccountFormBean, BindingResult result,
			final Model model)
	{
		try
		{

			ControllerUtils.redirectIfLoginRequired(request, response,masterKeyArgs);

			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null)
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					ControllerUtils.getUserDetailsAsModel(idToken, model);

					String uniqueIdentifier = idToken.getClaim(RegistrationConstants.SUBJECT).asString();
					
					PingDatastoreProcessor datastoreProcessor = new PingDatastoreProcessor(masterKeyArgs.toCharArray());
					
					UserExistsResponseBean userExists = null;
					if (!ControllerUtils.isNullOrEmptyString(uniqueIdentifier))
					{
						userExists = datastoreProcessor.isUserExists(dbiAccountFormBean, uniqueIdentifier);

						if (null != userExists && userExists.isNewUser())
						{
							request.getSession().setAttribute(RegistrationConstants.USER_NOT_EXISTS, false);
							request.getSession().setAttribute(RegistrationConstants.USER_EXISTS, true);
							String identityProvider = (String) request.getSession().getAttribute(RegistrationConstants.NAVIGATION_OPTION);
							dbiAccountFormBean.setIdpSelection(identityProvider);
							datastoreProcessor.addEntryToPingDatastore(dbiAccountFormBean, uniqueIdentifier);
						}
						else
						{
							if (null != userExists && userExists.isAlreadyExists()
									&& !userExists.isUserDetailsNotMatch())
							{
								request.getSession().setAttribute(RegistrationConstants.USER_EXISTS, true);
								request.getSession().setAttribute(RegistrationConstants.USER_NOT_EXISTS, false);
							}
							else if (null != userExists && userExists.isAlreadyExists()
									&& userExists.isUserDetailsNotMatch())
							{
								model.addAttribute(RegistrationConstants.ERROR_PAGE,
										"Invalid user. User details are not matching with registered user.");
								return RegistrationConstants.ERROR_PAGE;
							}
						}
					}
				}
				else
				{
					ControllerUtils.invalidateSession(request);
					return RegistrationConstants.SESSIONTIMEOUT_PAGE;
				}
			}
			
		}
		catch (BadJWTException e)
		{
			ControllerUtils.invalidateSession(request);
			return RegistrationConstants.SESSIONTIMEOUT_PAGE;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
			return RegistrationConstants.ERROR_PAGE;
		}

		return RegistrationConstants.REDIRECT_TO+"/authenticated/home?login=" + request.getSession().getAttribute("loginOption");
	}

	@RequestMapping(value = RegistrationConstants.DBIACCOUNT_VIEWACCOUNT)
	private String viewDBIAccount(final HttpServletRequest request, final HttpServletResponse response,
			final Model model)
	{
		try
		{
			ControllerUtils.redirectIfLoginRequired(request, response,masterKeyArgs);
			String uniqueIdentifier = "";
			
			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null)
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					if (request.getSession().getAttribute(RegistrationConstants.NAVIGATION_OPTION) == null)
					{
						request.getSession().setAttribute(RegistrationConstants.NAVIGATION_OPTION,
								idToken.getClaim(RegistrationConstants.IDENTITY_PROVIDER).asString());
					}

					uniqueIdentifier = idToken.getClaim(RegistrationConstants.SUBJECT).asString();

					PingDatastoreProcessor datastoreProcessor = new PingDatastoreProcessor(masterKeyArgs.toCharArray());
									
					if (!ControllerUtils.isNullOrEmptyString(uniqueIdentifier))
					{
						DBIAccountFormBean accountBean = datastoreProcessor.getAcountDetails(uniqueIdentifier);
						model.addAttribute(RegistrationConstants.MODEL_ACCOUNT_BEAN, accountBean);
					}
				}
				else
				{
					ControllerUtils.invalidateSession(request);
					return RegistrationConstants.SESSIONTIMEOUT_PAGE;
				}
			}
			else
			{
				return RegistrationConstants.HOME_PAGE;
			}			
		}
		catch (BadJWTException e)
		{
			ControllerUtils.invalidateSession(request);
			return RegistrationConstants.SESSIONTIMEOUT_PAGE;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
			return RegistrationConstants.ERROR_PAGE;
		}

		return RegistrationConstants.DBIACCOUNT;
	}

	/**
	 * @purpose confirm and submit business details to add
	 * @since February 1, 2020
	 * @param request
	 * @param response
	 * @param premise
	 * @param addressLine1
	 * @param locality
	 * @param postalCode
	 * @param crn
	 * @param utr
	 * @param dunnsNo
	 * @param vat
	 * @param paye
	 * @param sortCode
	 * @param accountNumber
	 * @param pscNames
	 * @param sicCodes
	 * @param noOfEmployees
	 * @param turnover
	 * @param model
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = RegistrationConstants.PERSONAL_DATASTORE_ADDINFO_AJAX_BUSINESSINFOSUBMISSION)
	public String submitBusinessInformation(final HttpServletRequest request, final HttpServletResponse response,
			String premise, String addressLine1, String locality, String postalCode, String crn, String utr,
			String dunnsNo, String vat, String paye, String sortCode, String accountNumber, String pscNames,
			String sicCodes, String noOfEmployees, String turnover, final Model model)
	{
		String returnResult = RegistrationConstants.ERROR_PAGE;
		try
		{

			ControllerUtils.redirectIfLoginRequired(request, response,masterKeyArgs);

			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null)
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					Business businessObject = (Business) request.getSession().getAttribute(RegistrationConstants.BUSINESS_OBJECT);
					BusinessInformationFormBean businessInfoFormBean = new BusinessInformationFormBean(
							businessObject.getBusinessName().getValue(), businessObject.getChBusinessId().getValue(),
							premise, locality, addressLine1, null, postalCode, true, false, crn, utr, dunnsNo, vat,
							paye, sicCodes, sortCode, accountNumber, pscNames, noOfEmployees, turnover);

					BusinessObject businessObjectSetter = new BusinessObject();

					// set existing business object
					businessObjectSetter.setBusinessObject(businessObject);
					// set remaining fields to business object from business info form bean
					businessObjectSetter.setBusinessAttributes(businessInfoFormBean);

					businessObject = businessObjectSetter.getBusinessObject();

					request.getSession().setAttribute(RegistrationConstants.BUSINESS_OBJECT, businessObject);
					model.addAttribute(RegistrationConstants.BUSINESS_OBJECT, businessObject);
					returnResult = RegistrationConstants.VALIDATIONAPPROVAL;
				}
				else
				{
					ControllerUtils.invalidateSession(request);
					return RegistrationConstants.SESSIONTIMEOUT_PAGE;
				}
			}
			
		}
		catch (BadJWTException e)
		{
			ControllerUtils.invalidateSession(request);
			return RegistrationConstants.SESSIONTIMEOUT_PAGE;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
			returnResult = RegistrationConstants.ERROR_PAGE;
		}
		return returnResult;
	}
}
