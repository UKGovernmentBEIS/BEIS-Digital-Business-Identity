/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.basic.registration.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.security.sasl.AuthenticationException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpmg.basic.registration.form.beans.BusinessInformationFormBean;
import com.kpmg.basic.registration.form.beans.DBIAccountFormBean;
import com.kpmg.basic.registration.form.beans.SearchCompanyBean;
import com.kpmg.basic.registration.form.beans.UnlinkDelegateFormBean;
import com.kpmg.datastore.processor.PingDatastoreProcessor;
import com.kpmg.datastore.utils.BusinessObject;
import com.kpmg.registration.beans.Business;
import com.kpmg.registration.beans.Company;
import com.kpmg.registration.beans.CompanyOwnerResponse;
import com.kpmg.registration.beans.DelegatesLink;
import com.kpmg.registration.beans.PersonWithInsolvencyNoticeResponse;
import com.kpmg.registration.constants.RegistrationConstants;
import com.kpmg.registration.utils.BusinessUtils;
import com.kpmg.registration.utils.ControllerUtils;
import com.kpmg.registration.utils.TokenValidator;
import com.kpmg.registration.webservice.processor.WebserviceProcessor;
import com.nimbusds.jwt.proc.BadJWTException;

@Controller
@SpringBootApplication
@Component
public class PersonalDatastoreController
{

	
	private String masterKeyArgs;

	@Autowired
	public PersonalDatastoreController(ApplicationArguments args) throws AuthenticationException
	{
		boolean isMasterKey = args.containsOption(RegistrationConstants.MASTER_KEY);

		if (isMasterKey)
		{
			masterKeyArgs = args.getOptionValues(RegistrationConstants.MASTER_KEY).get(0);
		}
		else
		{
			throw new AuthenticationException(
					"Authetication failed due to missing master key. Please provide correct master key.");
		}

	}

	/**
	 * @purpose redirect to setuppersonaldatstore.html
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = RegistrationConstants.SETUP_PERSONAL_DATASTORE)
	private String setupPersonalDatastore(final HttpServletRequest request, final HttpServletResponse response,
			final Model model)
	{
		String resultString = RegistrationConstants.ERROR_PAGE;
		try
		{

			ControllerUtils.redirectIfLoginRequired(request, response, masterKeyArgs);

			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null && validator.isAccessTokenValid(accessToken.getToken()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					ControllerUtils.getUserDetailsAsModel(idToken, model);

					HashMap<String, Business> ownedBusinessMap = BusinessUtils.getBusinessOwnedByUser(accessToken);

					if (!ownedBusinessMap.isEmpty())
					{
						model.addAttribute(RegistrationConstants.MODEL_BUSINESSES_OF_USER, ownedBusinessMap.values());
						request.getSession().setAttribute(RegistrationConstants.SESSION_OWNED_BUSINESS, ownedBusinessMap);
					}
					resultString = RegistrationConstants.SETUPPERSONALDATASTORE;
				}
				else
				{
					ControllerUtils.invalidateSession(request);
					return RegistrationConstants.SESSIONTIMEOUT_PAGE;
				}
			}
		}
		catch (BadJWTException e)
		{
			ControllerUtils.invalidateSession(request);
			return RegistrationConstants.SESSIONTIMEOUT_PAGE;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
			resultString = RegistrationConstants.ERROR_PAGE;
		}
		return resultString;
	}

	/**
	 * @purpose redirect to addinformation.html
	 * @param request
	 * @param response
	 * @param searchCompanyBean
	 * @param result
	 * @param model
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = RegistrationConstants.PERSONAL_DATASTORE_ADDINFO)
	private String addInformation(final HttpServletRequest request, final HttpServletResponse response,
			@Valid @ModelAttribute(RegistrationConstants.SEARCH_COMPANY_BEAN) SearchCompanyBean searchCompanyBean, BindingResult result,
			final Model model)
	{
		String resultString = RegistrationConstants.ERROR_PAGE;
		try
		{

			ControllerUtils.redirectIfLoginRequired(request, response, masterKeyArgs);
			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null && validator.isAccessTokenValid(accessToken.getToken()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					ControllerUtils.getUserDetailsAsModel(idToken, model);
					model.addAttribute(RegistrationConstants.BUSINESS_INFO_FORM_BEAN, new BusinessInformationFormBean());
					resultString = RegistrationConstants.ADDINFORMATION;
				}
				else
				{
					ControllerUtils.invalidateSession(request);
					return RegistrationConstants.SESSIONTIMEOUT_PAGE;
				}
			}

		}
		catch (BadJWTException e)
		{
			ControllerUtils.invalidateSession(request);
			return RegistrationConstants.SESSIONTIMEOUT_PAGE;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
			resultString = RegistrationConstants.ERROR_PAGE;
		}
		return resultString;

	}

	/**
	 * @purpose search business matching with input criteria from ajax call
	 * @since January 27, 2020
	 * @param request
	 * @param response
	 * @param companyNameToSearch
	 * @param premise
	 * @param addressLine1
	 * @param addressLine2
	 * @param locality
	 * @param postalCode
	 * @param model
	 * @throws IOException
	 */

	@RequestMapping(value = RegistrationConstants.PERSONAL_DATASTORE_ADDINFO_AJAX_SEARCH_BUSINESS)
	public void searchBusinessWithBusinessNameFromAjax(final HttpServletRequest request,
			final HttpServletResponse response, String companyNameToSearch, String premise, String addressLine1,
			String addressLine2, String locality, String postalCode, final Model model)
	{

		try
		{

			ControllerUtils.redirectIfLoginRequired(request, response, masterKeyArgs);
			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null && validator.isAccessTokenValid(accessToken.getToken()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					SearchCompanyBean searchCompanyBean = new SearchCompanyBean();
					searchCompanyBean.setCompanyNameToSearch(companyNameToSearch);
					searchCompanyBean.setPremise(premise);
					searchCompanyBean.setAddressLine1(addressLine1);
					searchCompanyBean.setAddressLine2(addressLine2);
					searchCompanyBean.setLocality(locality);
					searchCompanyBean.setPostCode(postalCode);

					HashMap<String, Company> filtereCompaniesMap = WebserviceProcessor
							.searchAndFilterCompanies(searchCompanyBean,masterKeyArgs);
					if (!filtereCompaniesMap.isEmpty())
					{
						request.getSession().setAttribute(RegistrationConstants.FILTERE_COMPANIES_MAP, filtereCompaniesMap);
						response.setContentType(RegistrationConstants.APPLICATION_JSON);
						OutputStream outputStream = response.getOutputStream();
						ObjectMapper mapper = new ObjectMapper();
						String jsonResult = mapper.writeValueAsString(filtereCompaniesMap.values());
						outputStream.write(jsonResult.getBytes());
						outputStream.flush();
					}
					else
					{
						response.setStatus(HttpServletResponse.SC_NOT_FOUND);
						response.getWriter().write("No businesses found with matching criteria.");
						response.flushBuffer();
					}
				}
			}
		}
		catch (BadJWTException e)
		{

			try
			{
				ControllerUtils.invalidateSession(request);
				response.setStatus(HttpServletResponse.SC_REQUEST_TIMEOUT);
				response.getWriter().write("Session is expired. Please re-login to continue.");
				response.flushBuffer();
			}
			catch (IOException e1)
			{
				e1.printStackTrace();
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
		}

	}

	/**
	 * @purpose Retrive details of selected business
	 * @param request
	 * @param response
	 * @param selectedCompanyId
	 * @param model
	 * @throws IOException
	 */
	@RequestMapping(value = RegistrationConstants.PERSONAL_DATASTORE_ADDINFO_AJAX_SELECT_BUSINESS)
	public void selectBusiness(final HttpServletRequest request, final HttpServletResponse response,
			String selectedCompanyId, final Model model)
	{
		try
		{

			ControllerUtils.redirectIfLoginRequired(request, response, masterKeyArgs);

			@SuppressWarnings("unchecked")
			Company selectedCompany = ((HashMap<String, Company>) request.getSession()
					.getAttribute(RegistrationConstants.FILTERE_COMPANIES_MAP)).get(selectedCompanyId);
			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null && validator.isAccessTokenValid(accessToken.getToken()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					HashMap<String, Business> ownedBusinessMap = BusinessUtils.getBusinessOwnedByUser(accessToken);
					if (ownedBusinessMap.containsKey(selectedCompanyId))
					{
						response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
						response.getWriter()
								.write("This business is already assigned to you. Please check the selection.");
						response.flushBuffer();
					}
					else
					{
						String firstname = idToken.getClaim(RegistrationConstants.GIVENNAME).asString();

						String lastname = idToken.getClaim(RegistrationConstants.FAMILY_NAME).asString();

						PingDatastoreProcessor datastoreProcessor = new PingDatastoreProcessor(
								masterKeyArgs.toCharArray());

						DBIAccountFormBean dbiAccount = datastoreProcessor
								.getAcountDetails(idToken.getClaim(RegistrationConstants.SUBJECT).asString());
						String middlename = dbiAccount.getMiddleName();
						String postcode = dbiAccount.getPostalCode();

						if (!ControllerUtils.isNullOrEmptyString(firstname)
								&& !ControllerUtils.isNullOrEmptyString(lastname))
						{
							// Add check if user is owner of business
							CompanyOwnerResponse companyOwnerResponse = WebserviceProcessor.isBusinessOwner(
									selectedCompanyId, selectedCompany.getCompanyName(), firstname, middlename,
									lastname, postcode, masterKeyArgs);

							if (null != companyOwnerResponse)
							{
								if (companyOwnerResponse.isOwner())
								{
									if (companyOwnerResponse.isNaturalDisqualified())
									{
										response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
										response.getWriter().write("You are disqualified for this selection.");
										response.flushBuffer();
									}
									else
									{
										request.getSession().removeAttribute(RegistrationConstants.FILTERE_COMPANIES_MAP);

										BusinessInformationFormBean businessInfoFormBean = new BusinessInformationFormBean();
										businessInfoFormBean.convertCompanyToFormBean(selectedCompany);
										BusinessObject businessObjectSetter = new BusinessObject();
										businessObjectSetter.setBusinessAttributes(businessInfoFormBean);
										Business business = businessObjectSetter.getBusinessObject();
										request.getSession().setAttribute(RegistrationConstants.BUSINESS_OBJECT, business);

										response.setContentType(RegistrationConstants.APPLICATION_JSON);
										OutputStream outputStream = response.getOutputStream();
										ObjectMapper mapper = new ObjectMapper();
										String jsonResult = mapper.writeValueAsString(businessInfoFormBean);
										outputStream.write(jsonResult.getBytes());
										outputStream.flush();
									}
								}
								else
								{
									response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
									response.getWriter().write("Director only are permissible to add this business.");
									response.flushBuffer();
								}
							}
							else
							{
								response.setStatus(HttpServletResponse.SC_PRECONDITION_FAILED);
								response.getWriter().write("Error with selection. Please retry.");
								response.flushBuffer();
							}
						}
						else
						{
							response.setStatus(HttpServletResponse.SC_PRECONDITION_FAILED);
							response.getWriter().write("Required information like firstname and lastname is missing.");
							response.flushBuffer();
						}
					}
				}
				else
				{
					ControllerUtils.invalidateSession(request);
					response.setStatus(HttpServletResponse.SC_REQUEST_TIMEOUT);
					response.getWriter().write("Token is invalid or exipred.");
					response.flushBuffer();
				}
			}

		}
		catch (BadJWTException e)
		{

			try
			{
				ControllerUtils.invalidateSession(request);
				response.setStatus(HttpServletResponse.SC_REQUEST_TIMEOUT);
				response.getWriter().write("Session is expired. Please re-login to continue.");
				response.flushBuffer();
			}
			catch (IOException e1)
			{
				e1.printStackTrace();
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
		}
	}

	/**
	 * @purpose Retrive details of selected business
	 * @param request
	 * @param response
	 * @param selectedCompanyId
	 * @param model
	 * @throws IOException
	 */
	@RequestMapping(value = RegistrationConstants.PERSONAL_DATASTORE_ADDINFO_AJAX_SEARCH_AND_SELECT_BUSINESS)
	public void searchAndSelectBusiness(final HttpServletRequest request, final HttpServletResponse response,
			String companyNameToSearch, final Model model)
	{
		try
		{

			ControllerUtils.redirectIfLoginRequired(request, response, masterKeyArgs);

			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null && validator.isAccessTokenValid(accessToken.getToken()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					Company selectedCompany = WebserviceProcessor.searchCompanyByName(companyNameToSearch, masterKeyArgs);
					if (null == selectedCompany)
					{
						response.setStatus(HttpServletResponse.SC_NOT_FOUND);
						response.getWriter().write("No results found with company name " + companyNameToSearch
								+ ". Please check the name or use advanced search option.");
						response.flushBuffer();
					}
					else
					{
						HashMap<String, Business> ownedBusinessMap = BusinessUtils.getBusinessOwnedByUser(accessToken);
						if (ownedBusinessMap.containsKey(selectedCompany.getChCompanyId()))
						{
							response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
							response.getWriter()
									.write("This business is already assigned to you. Please check the selection.");
							response.flushBuffer();
						}
						else
						{
							String firstname = idToken.getClaim(RegistrationConstants.GIVENNAME).asString();

							String lastname = idToken.getClaim(RegistrationConstants.FAMILY_NAME).asString();

							char[] masterKey = masterKeyArgs.toCharArray();
							PingDatastoreProcessor datastoreProcessor = new PingDatastoreProcessor(
									masterKeyArgs.toCharArray());
							Arrays.fill(masterKey, Character.MIN_VALUE);

							DBIAccountFormBean dbiAccount = datastoreProcessor
									.getAcountDetails(idToken.getClaim(RegistrationConstants.SUBJECT).asString());
							String middlename = dbiAccount.getMiddleName();
							String postcode = dbiAccount.getPostalCode();

							if (!ControllerUtils.isNullOrEmptyString(firstname)
									&& !ControllerUtils.isNullOrEmptyString(lastname))
							{
								// Add check if user is owner of business
								CompanyOwnerResponse companyOwnerResponse = WebserviceProcessor.isBusinessOwner(
										selectedCompany.getChCompanyId(), selectedCompany.getCompanyName(), firstname,
										middlename, lastname, postcode, masterKeyArgs);

								if (null != companyOwnerResponse)
								{
									if (companyOwnerResponse.isOwner())
									{
										if (companyOwnerResponse.isNaturalDisqualified())
										{
											response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
											response.getWriter().write("You are disqualified for this selection.");
											response.flushBuffer();
										}
										else
										{
											request.getSession().removeAttribute(RegistrationConstants.FILTERE_COMPANIES_MAP);

											BusinessInformationFormBean businessInfoFormBean = new BusinessInformationFormBean();
											businessInfoFormBean.convertCompanyToFormBean(selectedCompany);
											BusinessObject businessObjectSetter = new BusinessObject();
											businessObjectSetter.setBusinessAttributes(businessInfoFormBean);
											Business business = businessObjectSetter.getBusinessObject();
											request.getSession().setAttribute(RegistrationConstants.BUSINESS_OBJECT, business);

											response.setContentType(RegistrationConstants.APPLICATION_JSON);
											OutputStream outputStream = response.getOutputStream();
											ObjectMapper mapper = new ObjectMapper();
											String jsonResult = mapper.writeValueAsString(businessInfoFormBean);
											outputStream.write(jsonResult.getBytes());
											outputStream.flush();
										}
									}
									else
									{
										response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
										response.getWriter().write("Director only are permissible to add this business.");
										response.flushBuffer();
									}
								}
								else
								{
									response.setStatus(HttpServletResponse.SC_PRECONDITION_FAILED);
									response.getWriter().write("Error with selection. Please retry.");
									response.flushBuffer();
								}
							}
							else
							{
								response.setStatus(HttpServletResponse.SC_PRECONDITION_FAILED);
								response.getWriter()
										.write("Required information like firstname and lastname is missing.");
								response.flushBuffer();
							}
						}
					}
				}
				else
				{
					ControllerUtils.invalidateSession(request);
					response.setStatus(HttpServletResponse.SC_REQUEST_TIMEOUT);
					response.getWriter().write("Token is invalid or exipred.");
					response.flushBuffer();
				}
			}
		}
		catch (BadJWTException e)
		{

			try
			{
				ControllerUtils.invalidateSession(request);
				response.setStatus(HttpServletResponse.SC_REQUEST_TIMEOUT);
				response.getWriter().write("Session is expired. Please re-login to continue.");
				response.flushBuffer();
			}
			catch (IOException e1)
			{
				e1.printStackTrace();
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
		}
	}

	/**
	 * @purpose Verify business details with assurance engine.
	 * @since February 01, 2020
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = RegistrationConstants.PERSONAL_DATASTORE_ADDINFO_VERIFYBUSINESS)
	public String verifyBusinessInformation(final HttpServletRequest request, final HttpServletResponse response,
			final Model model)
	{
		String resultString = "";
		try
		{

			ControllerUtils.redirectIfLoginRequired(request, response, masterKeyArgs);

			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null && validator.isAccessTokenValid(accessToken.getToken()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					Business businessObject = (Business) request.getSession().getAttribute(RegistrationConstants.BUSINESS_OBJECT);
					businessObject = WebserviceProcessor.verifyBusinessInformation(businessObject,masterKeyArgs);

					char[] masterKey = masterKeyArgs.toCharArray();
					PingDatastoreProcessor datastoreProcessor = new PingDatastoreProcessor(masterKeyArgs.toCharArray());
					Arrays.fill(masterKey, Character.MIN_VALUE);

					datastoreProcessor.updateBusinessToUserLdapEntry(businessObject,
							idToken.getClaim(RegistrationConstants.SUBJECT).asString());
					updateBusinessToDelegates(accessToken, businessObject, datastoreProcessor, model);
					model.addAttribute(RegistrationConstants.BUSINESS_OBJECT, businessObject);
					
					resultString = RegistrationConstants.VERIFYRESULT;
				}
				else
				{
					ControllerUtils.invalidateSession(request);
					return RegistrationConstants.SESSIONTIMEOUT_PAGE;
				}
			}

		}
		catch (BadJWTException e)
		{
			ControllerUtils.invalidateSession(request);
			return RegistrationConstants.SESSIONTIMEOUT_PAGE;

		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
			resultString = RegistrationConstants.ERROR_PAGE;
		}
		return resultString;
	}

	/**
	 * Redirect to validationapproval.html
	 * 
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = RegistrationConstants.PERSONAL_DATASTORE_VALIDATIONAPPROVAL)
	public String getVerificationApproval(final HttpServletRequest request, final HttpServletResponse response,
			final Model model)
	{
		try
		{

			ControllerUtils.redirectIfLoginRequired(request, response, masterKeyArgs);
			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null && validator.isAccessTokenValid(accessToken.getToken()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					Business businessObject = (Business) request.getSession().getAttribute(RegistrationConstants.BUSINESS_OBJECT);
					model.addAttribute(RegistrationConstants.BUSINESS_OBJECT, businessObject);
				}
				else
				{
					ControllerUtils.invalidateSession(request);
					return RegistrationConstants.SESSIONTIMEOUT_PAGE;
				}
			}

		}
		catch (BadJWTException e)
		{
			ControllerUtils.invalidateSession(request);
			return RegistrationConstants.SESSIONTIMEOUT_PAGE;

		}

		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
			return RegistrationConstants.ERROR_PAGE;
		}
		return RegistrationConstants.VALIDATIONAPPROVAL;
	}

	/**
	 * Populate businesses of owner to add delegated users
	 * 
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = RegistrationConstants.PERSONAL_DATASTORE_MANAGEUSERS)
	public String getBusinessesOfUser(final HttpServletRequest request, final HttpServletResponse response,
			final Model model)
	{
		String resultString = "";
		try
		{

			ControllerUtils.redirectIfLoginRequired(request, response, masterKeyArgs);
			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null && validator.isAccessTokenValid(accessToken.getToken()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					HashMap<String, Business> ownedBusinessMap = BusinessUtils.getBusinessOwnedByUser(accessToken);

					if (!ownedBusinessMap.isEmpty())
					{
						model.addAttribute(RegistrationConstants.MODEL_BUSINESSES_OF_USER, ownedBusinessMap.values());
						model.addAttribute(RegistrationConstants.UNLINK_DELEGATE_FORM_BEAN, new UnlinkDelegateFormBean());
						request.getSession().setAttribute(RegistrationConstants.SESSION_OWNED_BUSINESS, ownedBusinessMap);
					}
				}
				else
				{
					ControllerUtils.invalidateSession(request);
					return RegistrationConstants.SESSIONTIMEOUT_PAGE;
				}
			}

			resultString = RegistrationConstants.MANAGEUSERS;
		}
		catch (BadJWTException e)
		{
			ControllerUtils.invalidateSession(request);
			return RegistrationConstants.SESSIONTIMEOUT_PAGE;

		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
			resultString =RegistrationConstants.ERROR_PAGE;
		}
		return resultString;
	}

	/**
	 * Add business to delegated user to datastore
	 * 
	 * @param request
	 * @param response
	 * @param selectedCompanyId
	 * @param firstName
	 * @param lastName
	 * @param emailAddress
	 * @param model
	 * @throws IOException
	 */

	@RequestMapping(value = RegistrationConstants.PERSONAL_DATASTORE_MANAGEUSERS_AJAX_ADD_BUSINESS_TO_USER)
	public void addBusinessToUser(final HttpServletRequest request, final HttpServletResponse response,
			String selectedCompanyId, String firstName, String lastName, String emailAddress, final Model model)
			throws IOException
	{

		try
		{

			ControllerUtils.redirectIfLoginRequired(request, response, masterKeyArgs);
			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null && validator.isAccessTokenValid(accessToken.getToken()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					String businessOwnerEmail = ControllerUtils.getEmailAddressOfUser(idToken);

					PingDatastoreProcessor datastoreProcessor = new PingDatastoreProcessor(masterKeyArgs.toCharArray());

					boolean isUserExists = datastoreProcessor.isUserExists(firstName, lastName, emailAddress);

					if (isUserExists)
					{
						// check if user is owner of business
						if (BusinessUtils.getBusinessOwnedByUsedId(emailAddress, datastoreProcessor)
								.containsKey(selectedCompanyId))
						{
							response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
							response.getWriter().write(
									"Unable to add user as a business delegate. User already added as a owner of this business.");
						}
						else
						{
							@SuppressWarnings("unchecked")
							Business deletegateToBusiness = ((HashMap<String, Business>) request.getSession()
									.getAttribute(RegistrationConstants.SESSION_OWNED_BUSINESS)).get(selectedCompanyId);

							DBIAccountFormBean dbiAccount = datastoreProcessor.getAcountDetails(emailAddress);
							PersonWithInsolvencyNoticeResponse serviceResponse = WebserviceProcessor
									.isPersonWithInsolvencyNotice(deletegateToBusiness.getChBusinessId().getValue(),
											deletegateToBusiness.getBusinessName().getValue(),
											dbiAccount.getFirstName(), dbiAccount.getMiddleName(),
											dbiAccount.getLastName(), dbiAccount.getPostalCode(),
											masterKeyArgs);
							if (!serviceResponse.isHasInsolvencyNotices())
							{
								if (!serviceResponse.isDisqualified())
								{
									deletegateToBusiness.setIsDelegate(true);
									deletegateToBusiness.setIsOwner(false);
									if (!datastoreProcessor.getUsersDelegateBusinesses(emailAddress)
											.containsKey(selectedCompanyId))
									{
										datastoreProcessor.updateBusinessToUserLdapEntry(deletegateToBusiness,
												emailAddress.toLowerCase());
										if (!ControllerUtils.isNullOrEmptyString(businessOwnerEmail))
										{
											// add delegate to owner entry
											DelegatesLink delegateLink = new DelegatesLink(
													deletegateToBusiness.getChBusinessId().getValue(),
													emailAddress.toLowerCase());
											datastoreProcessor.addBusinessDelegate(delegateLink, businessOwnerEmail);
										}
										getDelegates(request, response, selectedCompanyId, model);
										response.setStatus(HttpServletResponse.SC_OK);
									}
									else
									{
										response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
										response.getWriter()
												.write("User is already added as a delegate for this business.");
									}
								}
								else
								{
									response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
									response.getWriter().write(
											"User is disqualified for this business as per the information from Companies House.");									
								}
							}
							else
							{
								response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
								response.getWriter().write(
										"Unable to add user as a business delegate. There are insolvency notices issued for user.");
							}
						}
					}
					else
					{
						response.setStatus(HttpServletResponse.SC_NOT_FOUND);
						response.getWriter().write(
								"Digitial Business Identity Profile does not exists with provided details! Please enter correct details of delegate user or Ask delegate user to register for Digital Business Identity.");
					}
				}
				else
				{
					ControllerUtils.invalidateSession(request);
					response.setStatus(HttpServletResponse.SC_REQUEST_TIMEOUT);
					response.getWriter().write("Session expired for this operation. Please login to the system");
				}
			}

			response.flushBuffer();
		}
		catch (BadJWTException e)
		{

			try
			{	
				ControllerUtils.invalidateSession(request);			
				response.setStatus(HttpServletResponse.SC_REQUEST_TIMEOUT);
				response.getWriter().write("Session is expired. Please re-login to continue.");
				response.flushBuffer();
			}
			catch (IOException e1)
			{
				e1.printStackTrace();
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			response.getWriter().write(e.getMessage());
			response.flushBuffer();
		}
	}

	/**
	 * @purpose Retrieve details of selected business
	 * @param request
	 * @param response
	 * @param selectedCompanyId
	 * @param model
	 * @throws IOException
	 */
	@RequestMapping(value = RegistrationConstants.PERSONAL_DATASTORE_VERIFY_AJAX_BUSINESS_INFO)
	public void selectBusinessForVerify(final HttpServletRequest request, final HttpServletResponse response,
			String selectedCompanyId, final Model model)
	{
		try
		{

			ControllerUtils.redirectIfLoginRequired(request, response, masterKeyArgs);

			@SuppressWarnings("unchecked")
			Business selectedCompany = ((HashMap<String, Business>) request.getSession().getAttribute(RegistrationConstants.SESSION_OWNED_BUSINESS))
					.get(selectedCompanyId);
			// convert to business info form bean
			BusinessInformationFormBean businessFormBean = new BusinessInformationFormBean();
			businessFormBean.convertToFormBean(selectedCompany);

			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null && validator.isAccessTokenValid(accessToken.getToken()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					request.getSession().setAttribute(RegistrationConstants.BUSINESS_OBJECT, selectedCompany);
					response.setContentType(RegistrationConstants.APPLICATION_JSON);
					OutputStream outputStream = response.getOutputStream();
					ObjectMapper mapper = new ObjectMapper();
					String jsonResult = mapper.writeValueAsString(businessFormBean);
					outputStream.write(jsonResult.getBytes());
					outputStream.flush();
				}
				else
				{
					ControllerUtils.invalidateSession(request);
					response.setStatus(HttpServletResponse.SC_REQUEST_TIMEOUT);
					response.getWriter().write("Token is invalid or exipred.");
					response.flushBuffer();
				}

			}
		}
		catch (BadJWTException e)
		{

			try
			{
				ControllerUtils.invalidateSession(request);
				response.setStatus(HttpServletResponse.SC_REQUEST_TIMEOUT);
				response.getWriter().write("Session is expired. Please re-login to continue.");
				response.flushBuffer();
			}
			catch (IOException e1)
			{
				e1.printStackTrace();
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
		}
	}

	/**
	 * Redirect to validationapproval.html
	 * 
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = RegistrationConstants.PERSONAL_DATASTORE_VERIFYBUSINESS)
	public String verifyUserBusinesses(final HttpServletRequest request, final HttpServletResponse response,
			final Model model)
	{
		try
		{

			ControllerUtils.redirectIfLoginRequired(request, response, masterKeyArgs);
			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null && validator.isAccessTokenValid(accessToken.getToken()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{					
					HashMap<String, Business> ownedBusinessMap = BusinessUtils.getBusinessOwnedByUser(accessToken);
					model.addAttribute(RegistrationConstants.MODEL_BUSINESSES_OF_USER, ownedBusinessMap.values());
					model.addAttribute(RegistrationConstants.BUSINESS_INFO_FORM_BEAN, new BusinessInformationFormBean());
				}
				else
				{
					ControllerUtils.invalidateSession(request);
					return RegistrationConstants.SESSIONTIMEOUT_PAGE;
				}
			}

		}
		catch (BadJWTException e)
		{
			ControllerUtils.invalidateSession(request);
			return RegistrationConstants.SESSIONTIMEOUT_PAGE;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
			return RegistrationConstants.ERROR_PAGE;
		}

		return RegistrationConstants.VERIFYBUSINESSES;
	}

	/**
	 * Redirect to validationapproval.html
	 * 
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = RegistrationConstants.PERSONAL_DATASTORE_UPDATEBUSINESS)
	public String updateUserBusinesses(final HttpServletRequest request, final HttpServletResponse response,
			@RequestParam(RegistrationConstants.ID) String selectedBusinessId, final Model model)
	{

		try
		{
			ControllerUtils.redirectIfLoginRequired(request, response, masterKeyArgs);
			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null && validator.isAccessTokenValid(accessToken.getToken()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					request.getSession().setAttribute(RegistrationConstants.NAVIGATION_OPTION,
							idToken.getClaim(RegistrationConstants.IDENTITY_PROVIDER).asString());
					HashMap<String, Business> ownedBusinessMap = BusinessUtils.getBusinessOwnedByUser(accessToken);
					Business businessToUpdate = ownedBusinessMap.get(selectedBusinessId);
					BusinessInformationFormBean formBean = new BusinessInformationFormBean();
					formBean.convertToFormBean(businessToUpdate);
					// convert business to business form bean
					request.getSession().setAttribute(RegistrationConstants.BUSINESS_OBJECT, businessToUpdate);
					model.addAttribute(RegistrationConstants.BUSINESS_INFO_FORM_BEAN, formBean);
				}
				else
				{
					ControllerUtils.invalidateSession(request);
					return RegistrationConstants.SESSIONTIMEOUT_PAGE;
				}
			}
			else
			{				
				return RegistrationConstants.HOME;
			}

		}
		catch (BadJWTException e)
		{
			ControllerUtils.invalidateSession(request);
			return RegistrationConstants.SESSIONTIMEOUT_PAGE;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
		}

		return RegistrationConstants.UPDATEBUSINESS;
	}

	/**
	 * Update verified business to delegate user into datastore
	 * 
	 * @param accessToken
	 * @param businessObject
	 * @param datastoreProcessor
	 */
	private void updateBusinessToDelegates(final DecodedJWT accessToken, Business businessObject,
			PingDatastoreProcessor datastoreProcessor, final Model model)
	{

		try
		{
			List<String> listOfDelegates = BusinessUtils.getBusinessDelegates(accessToken,
					businessObject.getChBusinessId().getValue());

			businessObject.setIsDelegate(true);
			businessObject.setIsOwner(false);

			for (String delegateUid : listOfDelegates)
			{
				datastoreProcessor.updateBusinessToUserLdapEntry(businessObject, delegateUid);
			}
		}
		catch (Exception e)
		{
			System.err.println("Error ocured while updating business to delegates.");
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
		}
	}

	/**
	 * @purpose redirect to addinformation.html
	 * @param request
	 * @param response
	 * @param searchCompanyBean
	 * @param result
	 * @param model
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = RegistrationConstants.PERSONAL_DATASTORE_VERIFY_UPDATEBUSINFO)
	private String verifyUpdatedInformation(final HttpServletRequest request, final HttpServletResponse response,
			@Valid @ModelAttribute(RegistrationConstants.BUSINESS_INFO_FORM_BEAN) BusinessInformationFormBean businessInfoFormBean,
			BindingResult result, final Model model)
	{
		String returnResult = RegistrationConstants.ERROR_PAGE;
		try
		{

			ControllerUtils.redirectIfLoginRequired(request, response, masterKeyArgs);
			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null && validator.isAccessTokenValid(accessToken.getToken()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					Business businessObject = (Business) request.getSession().getAttribute(RegistrationConstants.BUSINESS_OBJECT);
					BusinessObject businessObjectSetter = new BusinessObject();

					// set existing business object
					businessObjectSetter.setBusinessObject(businessObject);
					// set remaining fields to business object from business info form bean
					businessObjectSetter.setBusinessAttributes(businessInfoFormBean);

					businessObject = businessObjectSetter.getBusinessObject();
					businessObject.setIsOwner(true);
					businessObject.setIsDelegate(false);
					request.getSession().setAttribute(RegistrationConstants.BUSINESS_OBJECT, businessObject);
					model.addAttribute(RegistrationConstants.BUSINESS_OBJECT, businessObject);
					returnResult = RegistrationConstants.VALIDATIONAPPROVAL;
				}
				else
				{
					ControllerUtils.invalidateSession(request);
					return RegistrationConstants.SESSIONTIMEOUT_PAGE;
				}
			}

		}
		catch (BadJWTException e)
		{
			ControllerUtils.invalidateSession(request);
			return RegistrationConstants.SESSIONTIMEOUT_PAGE;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
		}
		return returnResult;
	}

	@RequestMapping(value = RegistrationConstants.PERSONAL_DATASTORE_MANAGEUSERS_AJAX_POPULATE_BUSINESS_DELEGATES)
	public void getDelegates(final HttpServletRequest request, final HttpServletResponse response, String businessId,
			final Model model) throws IOException
	{
		try
		{

			ControllerUtils.redirectIfLoginRequired(request, response, masterKeyArgs);
			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null && validator.isAccessTokenValid(accessToken.getToken()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					String businessOwnerEmail = ControllerUtils.getEmailAddressOfUser(idToken);

					PingDatastoreProcessor datastoreProcessor = new PingDatastoreProcessor(masterKeyArgs.toCharArray());

					List<DelegatesLink> delegatesList = datastoreProcessor.getDelegatesOfBusiness(businessOwnerEmail,
							businessId);
					if (!delegatesList.isEmpty())
					{

						List<DBIAccountFormBean> listOfDelegates = new ArrayList<DBIAccountFormBean>();
						for (DelegatesLink delegate : delegatesList)
						{
							listOfDelegates.add(datastoreProcessor.getAcountDetails(delegate.getUid()));
						}
						response.setContentType(RegistrationConstants.APPLICATION_JSON);
						OutputStream outputStream = response.getOutputStream();
						ObjectMapper mapper = new ObjectMapper();
						String jsonResult = mapper.writeValueAsString(listOfDelegates);
						outputStream.write(jsonResult.getBytes());
						outputStream.flush();
					}
					else
					{
						response.setStatus(HttpServletResponse.SC_OK);
					}
				}
				else
				{
					ControllerUtils.invalidateSession(request);
					response.setStatus(HttpServletResponse.SC_REQUEST_TIMEOUT);
					response.getWriter().write("Session expired for this operation. Please login to the system");
				}
			}

			response.flushBuffer();
		}
		catch (BadJWTException e)
		{

			try
			{
				ControllerUtils.invalidateSession(request);
				response.setStatus(HttpServletResponse.SC_REQUEST_TIMEOUT);
				response.getWriter().write("Session is expired. Please re-login to continue.");
				response.flushBuffer();
			}
			catch (IOException e1)
			{
				e1.printStackTrace();
			}
			

		}
		catch (Exception e)
		{
			e.printStackTrace();
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			response.getWriter().write(e.getMessage());
			response.flushBuffer();

		}
	}

	/**
	 * Redirect to validationapproval.html
	 * 
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = RegistrationConstants.PERSONAL_DATASTORE_UNLINK_DELEGATE, method = RequestMethod.POST)
	public String deleteDelegateForBusinesses(final HttpServletRequest request, final HttpServletResponse response,
			// @RequestParam("id") String selectedBusinessId, @RequestParam("emailDelegate") String delegateEmail, final
			// Model model)
			@RequestParam(RegistrationConstants.BUSINESS_ID) String businessId, @RequestParam(RegistrationConstants.EMAIL_DELEGATE) String emailDelegate,
			@RequestBody String postPayload, final Model model)
	{
		try
		{

			ControllerUtils.redirectIfLoginRequired(request, response, masterKeyArgs);
			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null && validator.isAccessTokenValid(accessToken.getToken()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					String businessOwnerEmail = ControllerUtils.getEmailAddressOfUser(idToken);

					PingDatastoreProcessor datastoreProcessor = new PingDatastoreProcessor(masterKeyArgs.toCharArray());

					datastoreProcessor.removeDelegateLink(businessOwnerEmail,
							new DelegatesLink(businessId, emailDelegate));
					@SuppressWarnings("unchecked")
					HashMap<String, Business> ownedBusinessMap = (HashMap<String, Business>) request.getSession()
							.getAttribute(RegistrationConstants.SESSION_OWNED_BUSINESS);

					if (null != ownedBusinessMap && !ownedBusinessMap.isEmpty())
					{
						model.addAttribute(RegistrationConstants.MODEL_BUSINESSES_OF_USER, ownedBusinessMap.values());
						model.addAttribute(RegistrationConstants.UNLINK_DELEGATE_FORM_BEAN, new UnlinkDelegateFormBean());
					}
				}
				else
				{
					ControllerUtils.invalidateSession(request);
					return RegistrationConstants.SESSIONTIMEOUT_PAGE;
				}
			}
		}
		catch (BadJWTException e)
		{
			ControllerUtils.invalidateSession(request);
			return RegistrationConstants.SESSIONTIMEOUT_PAGE;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
		}

		return RegistrationConstants.MANAGEUSERS;
	}

	/**
	 * Redirect to validationapproval.html
	 * 
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = RegistrationConstants.PERSONAL_DATASTORE_AJAX_UNLINK_DELEGATE)
	public void unlinkDelegateForBusinesses(final HttpServletRequest request, final HttpServletResponse response,
			String businessId, String emailDelegate, final Model model)
	{
		try
		{
			ControllerUtils.redirectIfLoginRequired(request, response, masterKeyArgs);
			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null && validator.isAccessTokenValid(accessToken.getToken()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					String businessOwnerEmail = ControllerUtils.getEmailAddressOfUser(idToken);
					PingDatastoreProcessor datastoreProcessor = new PingDatastoreProcessor(masterKeyArgs.toCharArray());
					datastoreProcessor.removeDelegateLink(businessOwnerEmail,
							new DelegatesLink(businessId, emailDelegate));
					@SuppressWarnings("unchecked")
					HashMap<String, Business> ownedBusinessMap = (HashMap<String, Business>) request.getSession()
							.getAttribute(RegistrationConstants.SESSION_OWNED_BUSINESS);

					if (null != ownedBusinessMap && !ownedBusinessMap.isEmpty())
					{
						model.addAttribute(RegistrationConstants.MODEL_BUSINESSES_OF_USER, ownedBusinessMap.values());
						model.addAttribute(RegistrationConstants.UNLINK_DELEGATE_FORM_BEAN, new UnlinkDelegateFormBean());
					}
					getDelegates(request, response, businessId, model);
				}				
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
		}

	}
}
