/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.basic.registration.controller;

import java.io.IOException;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;

import javax.naming.NamingException;
import javax.security.sasl.AuthenticationException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.directory.api.util.GeneralizedTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpmg.basic.registration.form.beans.DBIAccountFormBean;
import com.kpmg.basic.registration.form.beans.UserExistsResponseBean;
import com.kpmg.datastore.processor.PingDatastoreProcessor;
import com.kpmg.registration.beans.Business;
import com.kpmg.registration.constants.RegistrationConstants;
import com.kpmg.registration.utils.BusinessUtils;
import com.kpmg.registration.utils.ControllerUtils;
import com.kpmg.registration.utils.OAuth2Helper;
import com.kpmg.registration.utils.SecretStoreUtils;
import com.kpmg.registration.utils.TokenValidator;
import com.nimbusds.jwt.proc.BadJWTException;

@Controller
@SpringBootApplication
@Component
public class AuthenticationController
{

	private String masterKeyArgs;

	@Autowired
	public AuthenticationController(ApplicationArguments args) throws AuthenticationException
	{
		boolean isMasterKey = args.containsOption(RegistrationConstants.MASTER_KEY);

		if (isMasterKey)
		{
			masterKeyArgs = args.getOptionValues(RegistrationConstants.MASTER_KEY).get(0);
		}
		else
		{
			throw new AuthenticationException(
					"Authetication failed due to missing master key. Please provide correct master key.");
		}

	}

	@RequestMapping(value = RegistrationConstants.AUTHENTICATED_HOME)
	private String authenticateAndRedirectToHome(final HttpServletRequest request, final HttpServletResponse response,
			@RequestParam(name = RegistrationConstants.LOGIN) String loginOption, final Model model) throws IOException
	{

		String returnResult = RegistrationConstants.HOME_PAGE;
		try
		{
			if (!ControllerUtils.isNullOrEmptyString(loginOption))
			{
				request.getSession().setAttribute(RegistrationConstants.LOGIN_OPTION, loginOption);

			}

			ControllerUtils.redirectIfLoginRequired(request, response, masterKeyArgs);

			TokenValidator validator = new TokenValidator(masterKeyArgs.toCharArray());
			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null && validator.isAccessTokenValid(accessToken.getToken()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(RegistrationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{

					DBIAccountFormBean dbiAccountFormBean = (DBIAccountFormBean) request.getSession()
							.getAttribute(RegistrationConstants.DBI_PROFILE_BEAN);
					HashMap<String, Business> ownedBusinessMap = BusinessUtils.getBusinessOwnedByUser(accessToken);

					if (!ownedBusinessMap.isEmpty())
					{
						model.addAttribute(RegistrationConstants.MODEL_BUSINESSES_OF_USER, ownedBusinessMap.values());
						request.getSession().setAttribute(RegistrationConstants.SESSION_OWNED_BUSINESS, ownedBusinessMap);
					}
					request.getSession().setAttribute(RegistrationConstants.SESSION_OWNED_BUSINESS_SIZE, ownedBusinessMap.size());
					HashMap<String, Business> delegateBusinessMap = BusinessUtils
							.getBusinessDelegatedByUser(accessToken);
					request.getSession().setAttribute(RegistrationConstants.SESSION_DELEGATE_BUSINESS_SIZE, delegateBusinessMap.size());

					GeneralizedTime gt = new GeneralizedTime((String) dbiAccountFormBean.getDateOfBirth());
					Date dateOfBirth = gt.getCalendar().getTime();
					String dateOfBirthStr = new SimpleDateFormat(RegistrationConstants.BUSINESS_DOB_FORMAT).format(dateOfBirth);
					model.addAttribute(RegistrationConstants.MODEL_DATE_OF_BIRTH, dateOfBirthStr.toLowerCase());
				}
				else
				{
					ControllerUtils.invalidateSession(request);
					return RegistrationConstants.SESSIONTIMEOUT_PAGE;
				}
			}
		}
		catch (BadJWTException e)
		{
			ControllerUtils.invalidateSession(request);
			return RegistrationConstants.SESSIONTIMEOUT_PAGE;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
			return RegistrationConstants.ERROR_PAGE;
		}
		return returnResult;
	}

	@RequestMapping(value = RegistrationConstants.AUTHENTICATED_DBILOGIN)
	private String redirectToDBILogin(final HttpServletRequest request, final HttpServletResponse response,
			final Model model) throws IOException
	{
		return ControllerUtils.createRedirectUrlToDBIAccount(request, masterKeyArgs);
	}

	/**
	 * A page to receive the authentication code from the server.
	 *
	 * @param request
	 *            the request object.
	 * @return a string indicating which view to display.
	 * @throws IOException
	 *             Signals that an I/O exception of some sort has occurred.
	 * @throws ParseException
	 * @throws NamingException
	 */
	@RequestMapping(value = RegistrationConstants.AUTHENTICATION_LOGIN)
	private String login(final HttpServletRequest request, final HttpServletResponse response, final Model model)
			throws IOException, ParseException, NamingException
	{
		String redirectUrl = "/";

		SecretStoreUtils secretUtil = new SecretStoreUtils(masterKeyArgs.toCharArray());
		PingDatastoreProcessor datastoreProcessor = new PingDatastoreProcessor(masterKeyArgs.toCharArray());

		final String authCode = request.getParameter(RegistrationConstants.CODE);
		final String state = request.getParameter(RegistrationConstants.STATE);
		final OAuth2Helper oauth2Helper = new OAuth2Helper(RegistrationConstants.TOKEN_ENDPOINT);
		final String clientId = String.valueOf(secretUtil.getSecrete(RegistrationConstants.CLIENT_ID));
		final char[] clientSecret = secretUtil.getSecrete(RegistrationConstants.CLIENT_SECRET);
		final String redirectUri = RegistrationConstants.REDIRECT_LOGIN_URI;
		final String scopes = RegistrationConstants.SCOPES.replace(" ", RegistrationConstants.PERCENT_TWENTY);
		final String rawToken = oauth2Helper.swapAuthenticationCode(clientId, clientSecret, redirectUri, scopes,
				authCode);

		// Parse the token
		final ObjectMapper mapper = new ObjectMapper();
		final JsonNode token = mapper.readTree(rawToken);

		final JsonNode accessToken = token.get(RegistrationConstants.OIDC_ACCESS_TOKEN);
		final JsonNode idToken = token.get(RegistrationConstants.OIDC_ID_TOKEN);
		final JsonNode refreshToken = token.get(RegistrationConstants.OIDC_REFRESH_TOKEN);

		request.getSession().setAttribute(RegistrationConstants.ACCESS_TOKEN_TEXT, accessToken.textValue());

		final DecodedJWT accessJwt = JWT.decode(accessToken.asText());
		final DecodedJWT idJwt = JWT.decode(idToken.asText());

		request.getSession().setAttribute(RegistrationConstants.OIDC_AUTHCODE, authCode);
		request.getSession().setAttribute(RegistrationConstants.OIDC_ACCESS_TOKEN, accessJwt);
		request.getSession().setAttribute(RegistrationConstants.OIDC_ID_TOKEN, idJwt);
		request.getSession().setAttribute(RegistrationConstants.OIDC_REFRESH_TOKEN, refreshToken.textValue());
		DBIAccountFormBean dbiAccountFormBean = ControllerUtils.getDBIAccountBean(idJwt);
		request.getSession().setAttribute(RegistrationConstants.DBI_PROFILE_BEAN, dbiAccountFormBean);
		request.getSession().setAttribute(RegistrationConstants.NAME, dbiAccountFormBean.getDisplayName());
		if (request.getSession().getAttribute(RegistrationConstants.NAVIGATION_OPTION) == null)
		{
			if (null != idJwt.getClaim(RegistrationConstants.IDENTITY_PROVIDER)
					&& !idJwt.getClaim(RegistrationConstants.IDENTITY_PROVIDER).asString().equals(""))
			{
				request.getSession().setAttribute(RegistrationConstants.NAVIGATION_OPTION,
						idJwt.getClaim(RegistrationConstants.IDENTITY_PROVIDER).asString());
			}

		}

		String uniqueIdentifier = idJwt.getClaim(RegistrationConstants.SUBJECT).asString();
		if (!ControllerUtils.isNullOrEmptyString(uniqueIdentifier))
		{
			UserExistsResponseBean userExists = ControllerUtils.checkIfUserExists(uniqueIdentifier, dbiAccountFormBean,
					datastoreProcessor);

			if (null != userExists && userExists.isNewUser())
			{
				request.getSession().setAttribute(RegistrationConstants.USER_NOT_EXISTS, userExists.isNewUser());
			}
			else
			{
				if (null != userExists && userExists.isAlreadyExists() && !userExists.isUserDetailsNotMatch())
				{
					request.getSession().setAttribute(RegistrationConstants.USER_EXISTS, userExists.isAlreadyExists());
					if (accessJwt.getClaim(RegistrationConstants.DBI_VALIDATED).asString().equalsIgnoreCase("false"))
					{
						String sessionId = idJwt.getClaim(RegistrationConstants.SESSION_REVOKE_ID).asString();
						oauth2Helper.singleLogout(clientId, clientSecret, sessionId);
						request.getSession().invalidate();
						request.getSession(false);
						model.addAttribute(RegistrationConstants.ERROR_PAGE,
								"Digitial Business Identity profile exists matching with your details. Please login using your DBI Account.");
						return RegistrationConstants.DBILOGIN_PAGE;
					}
					if (null != idJwt.getClaim(RegistrationConstants.IDENTITY_PROVIDER)
							&& !idJwt.getClaim(RegistrationConstants.IDENTITY_PROVIDER).asString().equals(""))
					{
						request.getSession().setAttribute(RegistrationConstants.NAVIGATION_OPTION,
								idJwt.getClaim(RegistrationConstants.IDENTITY_PROVIDER).asString());
					}
				}
				else if (null != userExists && userExists.isAlreadyExists() && userExists.isUserDetailsNotMatch())
				{
					model.addAttribute(RegistrationConstants.ERROR_PAGE, "Invalid user. User details are not matching with registered user.");
					return RegistrationConstants.ERROR_PAGE;
				}
			}
		}
		Arrays.fill(clientSecret, Character.MIN_VALUE);
		if (!state.isEmpty())
		{
			redirectUrl = state;
		}

		return RegistrationConstants.REDIRECT_TO + redirectUrl;
	}

	/**
	 * A page to receive the authentication code from the server.
	 *
	 * @param request
	 *            the request object.
	 * @return a string indicating which view to display.
	 * @throws IOException
	 *             Signals that an I/O exception of some sort has occurred.
	 * @throws URISyntaxException
	 */
	@RequestMapping(value = RegistrationConstants.AUTHENTICATED_LOGOUT)
	private String logout(final HttpServletRequest request, final HttpServletResponse response, final Model model)
	{
		final DecodedJWT idToken = (DecodedJWT) request.getSession().getAttribute(RegistrationConstants.OIDC_ID_TOKEN);
		String sessionId = idToken.getClaim(RegistrationConstants.SESSION_REVOKE_ID).asString();
		final OAuth2Helper oauth2Helper = new OAuth2Helper(RegistrationConstants.REVOKE_SESSION_ENDPOINT);
		try
		{
			char[] masterKey = masterKeyArgs.toCharArray();
			SecretStoreUtils secretUtil = new SecretStoreUtils(masterKey);
			Arrays.fill(masterKey, Character.MIN_VALUE);
			final String clientId = String.valueOf(secretUtil.getSecrete(RegistrationConstants.CLIENT_ID));
			final char[] clientSecret = secretUtil.getSecrete(RegistrationConstants.CLIENT_SECRET);
			oauth2Helper.singleLogout(clientId, clientSecret, sessionId);
			Arrays.fill(clientSecret, Character.MIN_VALUE);
		}
		catch (IOException e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
			return RegistrationConstants.ERROR_PAGE;
		}

		ControllerUtils.invalidateSession(request);
		return RegistrationConstants.LOGOUT_PAGE;
	}

	@RequestMapping(value = RegistrationConstants.AUTHENTICATED_SESSIONTIMEOUT)
	private String sessionTimeout(final HttpServletRequest request, final HttpServletResponse response,
			final Model model)
	{
		final DecodedJWT idToken = (DecodedJWT) request.getSession().getAttribute(RegistrationConstants.OIDC_ID_TOKEN);
		String sessionId = idToken.getClaim(RegistrationConstants.SESSION_REVOKE_ID).asString();
		final OAuth2Helper oauth2Helper = new OAuth2Helper(RegistrationConstants.REVOKE_SESSION_ENDPOINT);
		try
		{
			char[] masterKey = masterKeyArgs.toCharArray();
			SecretStoreUtils secretUtil = new SecretStoreUtils(masterKey);
			Arrays.fill(masterKey, Character.MIN_VALUE);
			final String clientId = SecretStoreUtils
					.decodeInput(String.valueOf(secretUtil.getSecrete(RegistrationConstants.CLIENT_ID)));
			final char[] clientSecret = secretUtil.getSecrete(RegistrationConstants.CLIENT_SECRET);
			oauth2Helper.singleLogout(clientId, clientSecret, sessionId);
			Arrays.fill(clientSecret, Character.MIN_VALUE);
		}
		catch (IOException e)
		{
			e.printStackTrace();
			model.addAttribute(RegistrationConstants.ERROR_PAGE, e.getMessage());
			return RegistrationConstants.ERROR_PAGE;
		}

		ControllerUtils.invalidateSession(request);
		return RegistrationConstants.SESSIONTIMEOUT_PAGE;
	}

	@RequestMapping(value = RegistrationConstants.EXISTING_DBILOGIN)
	private String dbiLogin(final HttpServletRequest request, final HttpServletResponse response, final Model model)
	{
		return RegistrationConstants.DBILOGIN_PAGE;
	}
}
