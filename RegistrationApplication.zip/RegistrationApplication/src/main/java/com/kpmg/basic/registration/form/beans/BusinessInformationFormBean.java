/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.basic.registration.form.beans;

import java.util.ArrayList;
import java.util.List;

import com.kpmg.registration.beans.Business;
import com.kpmg.registration.beans.Company;
import com.kpmg.registration.beans.PersonWithSignificantControl;
import com.kpmg.registration.constants.RegistrationConstants;

public class BusinessInformationFormBean
{
	String businessName;
	String businessId;
	String premise;
	String locality;
	String addressLine1;
	String addressLine2;
	String postCode;
	String businessCRN;
	boolean isOwner;
	boolean isDelegate;
	String businessUTR;
	String businessDUNN;
	String businessVAT;
	String businessPAYE;
	String businessSIC;
	String sortcode;
	String accountNumber;
	String businessPSC;
	String noOfEmployees;
	String businessTurnOver;

	public BusinessInformationFormBean()
	{

	}

	public BusinessInformationFormBean(String businessName, String businessId, String premise, String locality,
			String addressLine1, String addressLine2, String postCode, boolean isOwner, boolean isDelegate,
			String businessCRN, String businessUTR, String businessDUNN, String businessVAT, String businessPAYE,
			String businessSIC, String sortcode, String accountNumber, String businessPSC, String noOfEmployees,
			String businessTurnOver)
	{
		super();
		this.businessName = businessName;
		this.businessId = businessId;
		this.premise = premise;
		this.locality = locality;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.postCode = postCode;
		this.isOwner = isOwner;
		this.isDelegate = isDelegate;
		this.businessUTR = businessUTR;
		this.businessDUNN = businessDUNN;
		this.businessVAT = businessVAT;
		this.businessPAYE = businessPAYE;
		this.businessSIC = businessSIC;
		this.sortcode = sortcode;
		this.accountNumber = accountNumber;
		this.businessPSC = businessPSC;
		this.noOfEmployees = noOfEmployees;
		this.businessTurnOver = businessTurnOver;
		this.businessCRN = businessCRN;
	}

	public String getBusinessName()
	{
		return businessName;
	}

	public void setBusinessName(String businessName)
	{
		this.businessName = businessName;
	}

	public String getBusinessId()
	{
		return businessId;
	}

	public void setBusinessId(String businessId)
	{
		this.businessId = businessId;
	}

	public String getPremise()
	{
		return premise;
	}

	public void setPremise(String premise)
	{
		this.premise = premise;
	}

	public String getLocality()
	{
		return locality;
	}

	public void setLocality(String locality)
	{
		this.locality = locality;
	}

	public String getAddressLine1()
	{
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1)
	{
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2()
	{
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2)
	{
		this.addressLine2 = addressLine2;
	}

	public String getPostCode()
	{
		return postCode;
	}

	public void setPostCode(String postCode)
	{
		this.postCode = postCode;
	}

	public boolean isOwner()
	{
		return isOwner;
	}

	public void setOwner(boolean isOwner)
	{
		this.isOwner = isOwner;
	}

	public String getBusinessCRN()
	{
		return businessCRN;
	}

	public void setBusinessCRN(String businessCRN)
	{
		this.businessCRN = businessCRN;
	}

	public boolean isDelegate()
	{
		return isDelegate;
	}

	public void setDelegate(boolean isDelegate)
	{
		this.isDelegate = isDelegate;
	}

	public String getBusinessUTR()
	{
		return businessUTR;
	}

	public void setBusinessUTR(String businessUTR)
	{
		this.businessUTR = businessUTR;
	}

	public String getBusinessDUNN()
	{
		return businessDUNN;
	}

	public void setBusinessDUNN(String businessDUNN)
	{
		this.businessDUNN = businessDUNN;
	}

	public String getBusinessVAT()
	{
		return businessVAT;
	}

	public void setBusinessVAT(String businessVAT)
	{
		this.businessVAT = businessVAT;
	}

	public String getBusinessPAYE()
	{
		return businessPAYE;
	}

	public void setBusinessPAYE(String businessPAYE)
	{
		this.businessPAYE = businessPAYE;
	}

	public String getBusinessSIC()
	{
		return businessSIC;
	}

	public void setBusinessSIC(String businessSIC)
	{
		this.businessSIC = businessSIC;
	}

	public String getSortcode()
	{
		return sortcode;
	}

	public void setSortcode(String sortcode)
	{
		this.sortcode = sortcode;
	}

	public String getAccountNumber()
	{
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber)
	{
		this.accountNumber = accountNumber;
	}

	public String getBusinessPSC()
	{
		return businessPSC;
	}

	public void setBusinessPSC(String businessPSC)
	{
		this.businessPSC = businessPSC;
	}

	public String getNoOfEmployees()
	{
		return noOfEmployees;
	}

	public void setNoOfEmployees(String noOfEmployees)
	{
		this.noOfEmployees = noOfEmployees;
	}

	public String getBusinessTurnOver()
	{
		return businessTurnOver;
	}

	public void setBusinessTurnOver(String businessTurnOver)
	{
		this.businessTurnOver = businessTurnOver;
	}

	public void convertToFormBean(Business businessObject)
	{

		this.businessName = businessObject.getBusinessName().getValue();
		this.businessId = businessObject.getChBusinessId().getValue();
		this.premise = businessObject.getBusinessAddress().getPremise();
		this.locality = businessObject.getBusinessAddress().getLocality();
		this.addressLine1 = businessObject.getBusinessAddress().getAddressLine1();
		this.addressLine2 = "";
		this.postCode = businessObject.getBusinessAddress().getPostcode();
		this.isOwner = businessObject.getIsOwner();
		this.isDelegate = businessObject.getIsDelegate();
		this.businessUTR = businessObject.getBusinessUTR().getValue();
		this.businessDUNN = businessObject.getBusinessDUNN().getValue();
		this.businessVAT = businessObject.getBusinessVAT().getValue();
		this.businessPAYE = businessObject.getBusinessPAYE().getValue();
		this.businessSIC = businessObject.getBusinessSIC().toString();
		this.sortcode = businessObject.getBusinessBankDetails().getSortcode().getValue();
		this.accountNumber = businessObject.getBusinessBankDetails().getAccountNumber().getValue();
		this.businessPSC = businessObject.getBusinessPSC().toString();
		this.noOfEmployees = businessObject.getNoOfEmployees().getValue();
		this.businessTurnOver = businessObject.getBusinessTurnOver().getValue();
		this.businessCRN = businessObject.getBusinessCRN().getValue();
	}

	public void convertCompanyToFormBean(Company company)
	{

		this.businessName = company.getCompanyName();
		this.businessId = company.getChCompanyId();
		this.premise = company.getPremise();
		this.locality = company.getLocality();
		this.addressLine1 = company.getAddressLine1();
		this.addressLine2 = "";
		this.postCode = company.getPostCode();
		this.businessSIC = String.join(RegistrationConstants.COMMA_DELIMITER, company.getSicCodes());
		List<String> pscNameList = new ArrayList<>();
		for (PersonWithSignificantControl psc : company.getPersonWithSignificantControl())
		{
			pscNameList.add(psc.getName());
		}
		this.businessPSC = String.join(RegistrationConstants.COMMA_DELIMITER, pscNameList);
		this.businessCRN = company.getChCompanyId();
		this.businessUTR = company.getBusinessUTR();
		this.businessDUNN = company.getBusinessDUNN();
		this.businessVAT = company.getBusinessVAT();
		this.businessPAYE = company.getBusinessPAYE();
		this.sortcode = company.getSortcode();
		this.accountNumber = company.getAccountNumber();
		if (company.getNoOfEmployees() != null && !(company.getNoOfEmployees()==0))
		{
			this.noOfEmployees = Long.toString(company.getNoOfEmployees());
		}
		if (company.getTurnover() != null && !(company.getTurnover()==0.0))
		{
			this.businessTurnOver = Double.toString(company.getTurnover());
		}
	}
}
