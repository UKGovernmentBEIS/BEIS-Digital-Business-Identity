/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.basic.registration.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.Feature;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.oauth2.OAuth2ClientSupport;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kpmg.basic.registration.form.beans.IdentityProviderSelectBean;
import com.kpmg.registration.constants.RegistrationConstants;


@Controller
@SpringBootApplication
@Component
public class RegistrationController
{
	/**
	 * Main method.
	 *
	 * @param args
	 *            command line arguments.
	 * @throws Exception
	 *             The class {@code Exception} and its subclasses are a form of {@code Throwable} that indicates
	 *             conditions that a reasonable application might want to catch.
	 */
	public static void main(String[] args) throws Exception
	{
		SpringApplication.run(RegistrationController.class, args);
	}

	/**
	 * Home page.
	 *
	 * @return a string indicating which view to display.
	 */
	@RequestMapping(value = "/")
	private String index(final HttpServletRequest request, final HttpServletResponse response, final Model model)
	{
		request.getSession().setAttribute(RegistrationConstants.NAVIGATION_OPTION, RegistrationConstants.GENERIC);
		return RegistrationConstants.INDEX;
	}

	@RequestMapping(value = RegistrationConstants.SELECTIDP)
	private String startRegistration(final HttpServletRequest request, final HttpServletResponse response,
			final Model model)
	{
		model.addAttribute(RegistrationConstants.IDENTITY_PROVIDER_SELECT_BEAN, new IdentityProviderSelectBean());
		request.getSession().setAttribute(RegistrationConstants.NAVIGATION_OPTION, RegistrationConstants.GENERIC);
		return RegistrationConstants.IDPOPTIONS;
	}

	@RequestMapping(value = RegistrationConstants.REGISTER_NAVIGATE_IDPDETAILS)
	private String loadRegistrationViaIDP(final HttpServletRequest request, final HttpServletResponse response,
			@Valid @ModelAttribute(RegistrationConstants.IDENTITY_PROVIDER_SELECT_BEAN) IdentityProviderSelectBean selectedIdpOption,
			final Model model)
	{
		String selectedIdp = selectedIdpOption.getSelectedIdpOption();
		request.getSession().setAttribute(RegistrationConstants.NAVIGATION_OPTION, selectedIdp);
		return RegistrationConstants.STARTREGISTRATION;
	}

	/**
	 * Login options page.
	 *
	 * @return a string indicating which view to display.
	 */
	@RequestMapping(value = RegistrationConstants.PATH_LOGIN)
	private String showLoginOptions()
	{
		return RegistrationConstants.LOGIN;
	}

	@RequestMapping(value = "/feature/comingsoon")
	private String comingSoon(final HttpServletRequest request, final HttpServletResponse response)
	{
		return "comingsoon";
	}

	/**
	 * A page to display userinfo received from the server.
	 *
	 * @param request
	 *            the request object.
	 * @return a string indicating which view to display.
	 * @throws IOException
	 *             Signals that an I/O exception of some sort has occurred.
	 */
	@RequestMapping(value = RegistrationConstants.TOKENS_USERINFO)
	private String getUserInfo(final HttpServletRequest request, final HttpServletResponse response, final Model model)
			throws IOException
	{
		final String userinfo_endpoint = RegistrationConstants.USERINFO_ENDPOINT;
		final String accessToken = (String) request.getSession().getAttribute(RegistrationConstants.ACCESS_TOKEN_TEXT);

		model.addAttribute(RegistrationConstants.ACCESS_TOKEN, accessToken);
		Feature feature = OAuth2ClientSupport.feature(accessToken);

		Client client = ClientBuilder.newClient();
		client.register(feature);

		Response restResponse = client.target(userinfo_endpoint).request().get();

		if (restResponse.getStatus() == 401)
		{
			return RegistrationConstants.LOGIN;
		}
		else
		{
			model.addAttribute(RegistrationConstants.USER_INFORMATION, restResponse.readEntity(String.class));
			return RegistrationConstants.USERINFO;
		}
	}
}
