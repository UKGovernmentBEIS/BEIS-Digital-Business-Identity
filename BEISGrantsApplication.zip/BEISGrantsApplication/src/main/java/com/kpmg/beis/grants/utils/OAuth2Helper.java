/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.beis.grants.utils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * A class to help exchange the authentication code for a set of tokens.
 */
public class OAuth2Helper {
    private static final MediaType X_WWW_FORM_URLENCODED = MediaType.parse("application/x-www-form-urlencoded");
    private static final MediaType JSON = MediaType.parse("application/json");
    private String tokenUrl;
    
    /**
     * Constructor.
     *
     * @param tokenUrl the token URL for Ping Federate.
     */
    public OAuth2Helper(final String tokenUrl) {
        this.tokenUrl = tokenUrl;
    }

    /**
     * Returns the token URL.
     *
     * @return the token URL.
     */
    public String getTokenUrl() {
        return tokenUrl;
    }

    /**
     * Swaps the authentication code for an OpenID Connect token.
     *
     * @param clientId                  the client ID.
     * @param clientSecret              the client secret.
     * @param redirectUri               the redirect URI of the client.
     * @param scope                     the list of scopes requested.
     * @param authorizationCode         the authentication code returned by the server.
     * @return                          returns a string of the entire set of tokens.
     * @throws IOException              Signals that an I/O exception of some sort has occurred.
     */
    public String swapAuthenticationCode(final String clientId, final String clientSecret, final String redirectUri,
                                         final String scope, final String authorizationCode)
            throws IOException {

        String token = null;

        final String basicAuthString = clientId + ":" + clientSecret;
        final String basicAuth = Base64.getEncoder().encodeToString(basicAuthString.getBytes(StandardCharsets.UTF_8));
        final RequestBody body = RequestBody.create(X_WWW_FORM_URLENCODED, String.format(
                "grant_type=authorization_code&code=%s&redirect_uri=%s&scope=%s",
                authorizationCode, redirectUri, scope));

        // Don't ever do this in production because it allows any certificate!
        final OkHttpClient client = OkHttpHelper.getUnsafeOkHttpClient();

        final Request request = new Request.Builder()
                .url(tokenUrl)
                .post(body)
                .addHeader("Authorization", "Basic " + basicAuth)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .build();

        final Response response = client.newCall(request).execute();

        if (response.isSuccessful()) {
            token = response.body().string();
        }
        response.close();
        return token;
    }
    
    public void logout(final String sessionId, final String clientId, final String clientSecret) throws IOException {
    	final String basicAuthString = clientId + ":" + clientSecret;
        final String basicAuth = Base64.getEncoder().encodeToString(basicAuthString.getBytes(StandardCharsets.UTF_8));
        final String json = "{\"id\":\"%s\"}";
        final RequestBody body = RequestBody.create(JSON, String.format(json, sessionId));
        final OkHttpClient client = OkHttpHelper.getUnsafeOkHttpClient();

        final Request request = new Request.Builder()
                .url(tokenUrl)
                .post(body)
                .addHeader("Authorization", "Basic " + basicAuth)
                .addHeader("Content-Type", "application/json")
                .addHeader("X-XSRF-HEADER", "PingFederate")
                .build();

        final Response response = client.newCall(request).execute();
        if (response.isSuccessful()) {
            System.out.println("User logged out successfully.");
        }
        response.close();
    }
    
    public String checkAccessTokenValidity(final String accessToken, final String encryptionPassword) throws IOException {
    	String responseString = null;
    	SecretStoreUtils secretUtil = new SecretStoreUtils(encryptionPassword.toCharArray());
    	final String basicAuthString = String.valueOf(secretUtil.getSecrete(ApplicationConstants.CLIENT_ID)) + ":" + String.valueOf(secretUtil.getSecrete(ApplicationConstants.CLIENT_SECRET));
        final String basicAuth = Base64.getEncoder().encodeToString(basicAuthString.getBytes(StandardCharsets.UTF_8));
        final RequestBody body = RequestBody.create(X_WWW_FORM_URLENCODED, String.format(
                "token=%s&token_type_hint=access_token", accessToken));
        final OkHttpClient client = OkHttpHelper.getUnsafeOkHttpClient();

        final Request request = new Request.Builder()
                .url(tokenUrl)
                .post(body)
                .addHeader("Authorization", "Basic " + basicAuth)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .build();

        final Response response = client.newCall(request).execute();
        if (response.isSuccessful()) {
        	responseString = response.body().string();
        }
        response.close();
        return responseString;
    }
}
