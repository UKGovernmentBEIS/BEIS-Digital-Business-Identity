/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.beis.grants.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.PropertyException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpmg.beis.grants.beans.SelectedBusinessBean;
import com.kpmg.beis.grants.utils.ApplicationConstants;
import com.kpmg.beis.grants.utils.ApplicationUtility;
import com.kpmg.beis.grants.utils.OAuth2Helper;
import com.kpmg.beis.grants.utils.SecretStoreUtils;
import com.kpmg.beis.grants.utils.TokenValidator;
import com.nimbusds.jwt.proc.BadJWTException;

@Controller
public class AuthenticationController
{
	@Value(ApplicationConstants.ENCRYPTION_PASSWORD)
	private String encryptionPassword;

	public String getEncryptionPassword()
	{
		return encryptionPassword;
	}

	public void setEncryptionPassword(String encryptionPassword)
	{
		this.encryptionPassword = encryptionPassword;
	}

	/**
	 * This method takes the user to home page where minimal biographic information extracted from the id_token are
	 * displayed.
	 *
	 * @param request
	 *            the request object.
	 * @param response
	 *            the response object.
	 * @param model
	 *            the model to be passed to the view.
	 * @return a string indicating which view to display.
	 */

	@RequestMapping(value = ApplicationConstants.PATH_AUTHENTICATED_HOME)
	private String showHomePage(final HttpServletRequest request, final HttpServletResponse response, final Model model)
			throws IOException
	{
		String returnView = ApplicationConstants.VIEW_ERROR;
		try
		{
			TokenValidator validator = new TokenValidator(this.getEncryptionPassword());
			ApplicationUtility.redirectIfLoginRequired(request, response, this.getEncryptionPassword());

			final DecodedJWT accessToken = (DecodedJWT) request.getSession()
					.getAttribute(ApplicationConstants.OIDC_ACCESS_TOKEN);
			if (accessToken != null
					&& validator.isAccessTokenValid(accessToken.getToken(), this.getEncryptionPassword()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(ApplicationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					String gender = idToken.getClaim(ApplicationConstants.CLAIM_GENDER).asString();
					if (!ApplicationUtility.isNullOrEmptyString(gender))
					{
						model.addAttribute(ApplicationConstants.CLAIM_GENDER, gender);
						if (ApplicationConstants.GENDER_MALE.equalsIgnoreCase(gender))
						{
							model.addAttribute(ApplicationConstants.MODEL_ATTR_TITLE, ApplicationConstants.TITLE_MR);
						}
						else
						{
							model.addAttribute(ApplicationConstants.MODEL_ATTR_TITLE, ApplicationConstants.TITLE_MS);
						}
					}

					String displayName = idToken.getClaim(ApplicationConstants.CLAIM_NAME).asString();
					if (!ApplicationUtility.isNullOrEmptyString(displayName))
					{
						model.addAttribute(ApplicationConstants.MODEL_ATTR_DISPLAY_NAME, displayName.toUpperCase());
					}

					String dateOfBirth = idToken.getClaim(ApplicationConstants.CLAIM_BIRTHDATE).asString();
					if (!ApplicationUtility.isNullOrEmptyString(dateOfBirth))
					{
						dateOfBirth = ApplicationUtility.formatDate(dateOfBirth);
						model.addAttribute(ApplicationConstants.MODEL_ATTR_DATE_OF_BIRTH, dateOfBirth.toUpperCase());
					}

					String address = idToken.getClaim(ApplicationConstants.CLAIM_ADDRESS).asString();
					if (!ApplicationUtility.isNullOrEmptyString(address))
					{
						String postalCode = idToken.getClaim(ApplicationConstants.CLAIM_POSTAL_CODE).asString();
						if (!ApplicationUtility.isNullOrEmptyString(postalCode))
						{
							address = address + ApplicationConstants.GENERIC_SPACE + postalCode;
						}
						model.addAttribute(ApplicationConstants.MODEL_ATTR_ADDRESS, address.toUpperCase());
					}

					String firstName = idToken.getClaim(ApplicationConstants.CLAIM_GIVEN_NAME).asString();
					if (!ApplicationUtility.isNullOrEmptyString(firstName))
					{
						model.addAttribute(ApplicationConstants.MODEL_ATTR_FIRST_NAME, firstName.toUpperCase());
					}

					model.addAttribute(ApplicationConstants.SELECTED_BUSINESS_BEAN, new SelectedBusinessBean());

					returnView = ApplicationConstants.VIEW_HOME;
				}
				else
				{
					ApplicationUtility.invalidateSession(request);
					return ApplicationConstants.SESSIONTIMEOUT;
				}
			}
		}
		catch (BadJWTException e)
		{
			ApplicationUtility.invalidateSession(request);
			return ApplicationConstants.SESSIONTIMEOUT;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(ApplicationConstants.VIEW_ERROR, e.getMessage());
		}
		return returnView;
	}

	/**
	 * This method is called when PingFederate sends a redirect after user login. An authentication code is returned by
	 * the Federation Hub. The authentication code is then sent back to the FH to get access_token and id_token. Once
	 * received all these codes are set in session for further use during user journey.
	 *
	 * @param request
	 *            the request object.
	 * @return a string indicating which view to display.
	 * @throws Exception
	 */
	@RequestMapping(value = ApplicationConstants.PATH_AUTHENTICATION_LOGIN)
	private String login(final HttpServletRequest request) throws Exception
	{

		SecretStoreUtils secretUtil = new SecretStoreUtils(encryptionPassword.toCharArray());
		final String clientId = String.valueOf(secretUtil.getSecrete(ApplicationConstants.CLIENT_ID));
		final char[] clientSecret = secretUtil.getSecrete(ApplicationConstants.CLIENT_SECRET);
		final String contextPath = request.getContextPath();
		final String authCode = request.getParameter(ApplicationConstants.REQ_PARAM_CODE);
		final String state = request.getParameter(ApplicationConstants.REQ_PARAM_STATE);
		final OAuth2Helper oauth2Helper = new OAuth2Helper(ApplicationConstants.TOKEN_ENDPOINT);
		String redirectUrl = ApplicationConstants.PATH_SLASH;

		/*
		 * String clientSecret = null;
		 * 
		 * clientSecret = ApplicationUtility.readEncryptedProperty(ApplicationConstants.CREDENTIALS_FILE_NAME,
		 * ApplicationConstants.PROPKEY_CLIENT_SECRET, this.getEncryptionPassword());
		 */

		final String redirectUri = ApplicationConstants.REDIRECT_URI;
		final String scopes = ApplicationConstants.SCOPES.replace(ApplicationConstants.GENERIC_SPACE,
				ApplicationConstants.ENCODED_SPACE);

		final String rawToken = oauth2Helper.swapAuthenticationCode(clientId, String.valueOf(clientSecret), redirectUri,
				scopes, authCode);

		// Parse the token
		final ObjectMapper mapper = new ObjectMapper();
		final JsonNode token = mapper.readTree(rawToken);

		final JsonNode accessToken = token.get(ApplicationConstants.OIDC_ACCESS_TOKEN);
		final JsonNode idToken = token.get(ApplicationConstants.OIDC_ID_TOKEN);
		final JsonNode refreshToken = token.get(ApplicationConstants.OIDC_REFRESH_TOKEN);

		String idTokenText = idToken.textValue();

		TokenValidator tokenValidator = new TokenValidator(this.getEncryptionPassword());

		boolean isIdTokenValid = tokenValidator.isIdTokenValid(idTokenText);
		if (isIdTokenValid)
		{
			final DecodedJWT accessJwt = JWT.decode(accessToken.asText());
			final DecodedJWT idJwt = JWT.decode(idToken.asText());

			boolean isAccessTokenValid = tokenValidator.isAccessTokenValid(accessJwt.getToken(),
					this.getEncryptionPassword());
			if (isAccessTokenValid)
			{
				request.getSession().setAttribute(ApplicationConstants.SESSION_ATTR_ACCESS_TOKEN_TEXT,
						accessToken.textValue());
				request.getSession().setAttribute(ApplicationConstants.SESSION_ATTR_REFRESH_TOKEN_TEXT,
						refreshToken.textValue());
				request.getSession().setAttribute(ApplicationConstants.OIDC_AUTHCODE, authCode);
				request.getSession().setAttribute(ApplicationConstants.OIDC_ACCESS_TOKEN, accessJwt);
				request.getSession().setAttribute(ApplicationConstants.OIDC_ID_TOKEN, idJwt);
				request.getSession().setAttribute(ApplicationConstants.OIDC_REFRESH_TOKEN, refreshToken.textValue());
				request.getSession().setAttribute(ApplicationConstants.CLAIM_NAME,
						idJwt.getClaim(ApplicationConstants.CLAIM_NAME).asString().toUpperCase());

				// FIXME removing context path from state to avoid appending it twice
				String newstate = null;
				if (!state.isEmpty())
				{
					if (state.contains(contextPath))
					{
						newstate = state.split(contextPath)[1];
						redirectUrl = newstate;
					}
					else
					{
						redirectUrl = state;
					}
				}
			}
			else
			{
				redirectUrl = ApplicationConstants.PATH_FEATURE_COMINGSOON;
			}

		}
		else
		{
			redirectUrl = ApplicationConstants.PATH_FEATURE_COMINGSOON;
		}

		return ApplicationConstants.REDIRECT + redirectUrl;
	}

	/**
	 * This method is called when user clicks on Logout button. A session id from FH is available in the id_token as
	 * claims. This session id is then sent to FH to be added in revoked SRI list via HTTP POST. On successful logout,
	 * user is sent to the index page.
	 *
	 * @return
	 * @throws IOException
	 * @throws PropertyException
	 */
	@RequestMapping(value = ApplicationConstants.PATH_AUTHENTICATION_LOGOUT)
	private String logout(final HttpServletRequest request, final HttpServletResponse response)
			throws IOException, PropertyException
	{
		final OAuth2Helper oauth2Helper = new OAuth2Helper(ApplicationConstants.SESSION_REVOCATON_URI);
		final DecodedJWT idToken = (DecodedJWT) request.getSession().getAttribute(ApplicationConstants.OIDC_ID_TOKEN);
		final String sessionId = idToken.getClaim(ApplicationConstants.CLAIM_SESSION_ID).asString();
		SecretStoreUtils secretUtil = new SecretStoreUtils(encryptionPassword.toCharArray());
		oauth2Helper.logout(sessionId, String.valueOf(secretUtil.getSecrete(ApplicationConstants.CLIENT_ID)),
				String.valueOf(secretUtil.getSecrete(ApplicationConstants.CLIENT_SECRET)));
		request.getSession().invalidate();
		request.getSession(false);
		return ApplicationConstants.VIEW_INDEX;
	}
}
