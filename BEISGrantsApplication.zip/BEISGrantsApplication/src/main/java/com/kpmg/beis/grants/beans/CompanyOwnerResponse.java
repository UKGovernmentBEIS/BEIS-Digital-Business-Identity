/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.beis.grants.beans;

public class CompanyOwnerResponse
{
	boolean isOwner;	
	boolean isNaturalDisqualified;
	boolean isCorporateDisqualified;
	boolean hasInsolvencyNotice;
	String linkToNotice;
	
	public CompanyOwnerResponse()
	{
		isOwner = false;
		isNaturalDisqualified = false;
		isCorporateDisqualified = false;
		hasInsolvencyNotice=false;
		linkToNotice = "";
	}
	
	public boolean isOwner()
	{
		return isOwner;
	}
	public void setOwner(boolean isOwner)
	{
		this.isOwner = isOwner;
	}
	public boolean isNaturalDisqualified()
	{
		return isNaturalDisqualified;
	}
	public void setNaturalDisqualified(boolean isNaturalDisqualified)
	{
		this.isNaturalDisqualified = isNaturalDisqualified;
	}
	public boolean isCorporateDisqualified()
	{
		return isCorporateDisqualified;
	}
	public void setCorporateDisqualified(boolean isCorporateDisqualified)
	{
		this.isCorporateDisqualified = isCorporateDisqualified;
	}

	public boolean isHasInsolvencyNotice()
	{
		return hasInsolvencyNotice;
	}

	public void setHasInsolvencyNotice(boolean hasInsolvencyNotice)
	{
		this.hasInsolvencyNotice = hasInsolvencyNotice;
	}

	public String getLinkToNotice()
	{
		return linkToNotice;
	}

	public void setLinkToNotice(String linkToNotice)
	{
		this.linkToNotice = linkToNotice;
	}
	
	
}
