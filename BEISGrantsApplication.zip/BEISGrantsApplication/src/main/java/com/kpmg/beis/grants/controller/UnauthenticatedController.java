/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.beis.grants.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.kpmg.beis.grants.utils.ApplicationConstants;
import com.kpmg.beis.grants.utils.ApplicationUtility;
import com.kpmg.beis.grants.utils.TokenValidator;
import com.nimbusds.jwt.proc.BadJWTException;

@Controller
public class UnauthenticatedController
{

	@Value(ApplicationConstants.ENCRYPTION_PASSWORD)
	private String encryptionPassword;

	public String getEncryptionPassword()
	{
		return encryptionPassword;
	}

	public void setEncryptionPassword(String encryptionPassword)
	{
		this.encryptionPassword = encryptionPassword;
	}

//	private static final Logger logger = LoggerFactory.getLogger(UnauthenticatedController.class);

	/**
	 * This is the first entry point to the application. To avoid having an authenticated user to navigate through
	 * starting pages, this method checks if there is a valid access_token available in session and sends the user to
	 * home page rather than the index page.
	 *
	 * @return a string indicating which view to display.
	 * @throws IOException
	 */
	@RequestMapping(value = ApplicationConstants.PATH_SLASH)
	private String index(final HttpServletRequest request, final HttpServletResponse response) throws IOException
	{
		String returnView = ApplicationConstants.VIEW_INDEX;
		try
		{
			HttpSession session = request.getSession();
			TokenValidator validator = new TokenValidator(this.getEncryptionPassword());

			if (session == null)
			{
				System.err.println("No active session found. Sending the user to index page.");
			}
			else
			{
				DecodedJWT accessToken = (DecodedJWT) session.getAttribute(ApplicationConstants.OIDC_ACCESS_TOKEN);
				if (accessToken == null)
				{
					System.err.println(
							"There is an active session but a valid access token in not found. Sending user to index page.");
				}
				else if (validator.isAccessTokenValid(accessToken.getToken(), this.getEncryptionPassword()))
				{
					final DecodedJWT idToken = (DecodedJWT) request.getSession()
							.getAttribute(ApplicationConstants.OIDC_ID_TOKEN);

					if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
					{								
						returnView = ApplicationConstants.REDIRECT + ApplicationConstants.PATH_AUTHENTICATED_HOME;
					}
					else
					{
						ApplicationUtility.invalidateSession(request);
						return ApplicationConstants.SESSIONTIMEOUT;
					}
				}
			}
		}
		catch (BadJWTException e)
		{
			ApplicationUtility.invalidateSession(request);
			return ApplicationConstants.SESSIONTIMEOUT;
		}
		catch (Exception e)
		{
			e.printStackTrace();			
			returnView = ApplicationConstants.VIEW_ERROR;
		}
		return returnView;
	}

	/**
	 * Simple controller method to take user from index page to login page.
	 *
	 * @return a string indicating which view to display.
	 */
	@RequestMapping(value = ApplicationConstants.PATH_LOGIN)
	private String showLoginOptions()
	{
		return ApplicationConstants.VIEW_LOGIN;
	}

	/**
	 * This is application wide used page to show an error screen. Instead of showing java exceptions on the screen this
	 * page will show work in progress kind of screen.
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = ApplicationConstants.PATH_FEATURE_COMINGSOON)
	private String comingSoon(final HttpServletRequest request, final HttpServletResponse response)
	{
		return ApplicationConstants.VIEW_ERROR;
	}

}
