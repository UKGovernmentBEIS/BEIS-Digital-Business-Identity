/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.beis.grants.utils;

import java.io.IOException;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.Feature;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.oauth2.OAuth2ClientSupport;

public class PingFederateUtility {
	
public static String getUserInfo(final String accessToken) throws IOException {
		
		final String userinfo_endpoint = ApplicationConstants.USERINFO_ENDPOINT;
		
		Feature feature = OAuth2ClientSupport.feature(accessToken);
		Client client = ClientBuilder.newClient();
		client.register(feature);
		
		Response restResponse = client.target(userinfo_endpoint).request().get();
			
		if(restResponse.getStatus() == 401) {
			return ApplicationConstants.UNAUTHORISED;
		} else {
			String jsonResponse = restResponse.readEntity(String.class);
			return jsonResponse;
		}
	}

}