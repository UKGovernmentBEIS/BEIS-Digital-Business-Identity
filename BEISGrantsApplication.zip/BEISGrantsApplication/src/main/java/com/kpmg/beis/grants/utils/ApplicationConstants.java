package com.kpmg.beis.grants.utils;

public interface ApplicationConstants {
	
	public static final String PBE_WITH_HMACSHA512_AND_AES_256 = "PBEWithHMACSHA512AndAES_256";
	public static final String CREDENTIALS_FILE_NAME = "credentials.properties";
	public static final String PROPKEY_CLIENT_SECRET = "client.secret";
	
	// Application Paths 
	public static final String PATH_AUTHENTICATION_LOGOUT = "/authentication/logout";
	public static final String PATH_AUTHENTICATED_HOME = "/authenticated/home";
	public static final String PATH_AUTHENTICATION_LOGIN = "/authentication/login";
	public static final String PATH_LOGIN = "/login";
	public static final String PATH_AUTHENTICATED_BUSINESS_OWNER = "/authenticated/business/owner";
	public static final String PATH_AUTHENTICATED_BUSINESS_DELEGATE = "/authenticated/business/delegate";
	public static final String PATH_FEATURE_COMINGSOON = "/feature/comingsoon";
	public static final String PATH_SLASH = "/";
	
	// OIDC 
	public static final String OIDC_ACCESS_TOKEN = "access_token";
	public static final String OIDC_ID_TOKEN = "id_token";
	public static final String OIDC_REFRESH_TOKEN = "refresh_token";
	public static final String OIDC_AUTHCODE = "authcode";
	
	public static final String CLAIM_GENDER = "gender";
	public static final String CLAIM_NAME = "name";
	public static final String CLAIM_BIRTHDATE = "birthdate";
	public static final String CLAIM_ADDRESS = "address";
	public static final String CLAIM_POSTAL_CODE = "postal_code";
	public static final String CLAIM_GIVEN_NAME = "given_name";
	public static final String CLAIM_SESSION_ID = "pi.sri";
	
	//Application Attributes
	public static final String MODEL_ATTR_TITLE = "title";
	public static final String MODEL_ATTR_DISPLAY_NAME = "displayName";
	public static final String MODEL_ATTR_DATE_OF_BIRTH = "dateOfBirth";
	public static final String MODEL_ATTR_ADDRESS = "address";
	public static final String MODEL_ATTR_FIRST_NAME = "firstName";
	public static final String MODEL_ATTR_WRAPPER_BEAN = "wrapperBean";
	public static final String MODEL_ATTR_USER_ROLE = "userRole";
	public static final String MODEL_ATTR_BUSINESSES = "businesses";
	
	public static final String SESSION_ATTR_ACCESS_TOKEN_TEXT = "accessTokenText";
	public static final String SESSION_ATTR_REFRESH_TOKEN_TEXT = "refreshTokenText";
	
	//Application Views
	public static final String VIEW_HOME = "home";
	public static final String VIEW_INDEX = "index";
	public static final String VIEW_ERROR = "error";
	public static final String VIEW_BUSINESS_HOME = "businessHome";
	public static final String VIEW_LOGIN = "login";
	
	//Attribute constant values
	public static final String TITLE_MR = "MR.";
	public static final String TITLE_MS = "MS.";
	public static final String ENCODED_SPACE = "%20";
	public static final String GENERIC_SPACE = " ";
	public static final String USER_ROLE_BUSINESS_OWNER = "Business Owner";
	public static final String USER_ROLE_DELEGATE = "Delegate";
	
	//Request Params
	public static final String REQ_PARAM_CODE = "code";
	public static final String REQ_PARAM_ERROR = "error";
	public static final String REQ_PARAM_ERROR_DESC = "error_description";
	public static final String REQ_PARAM_STATE = "state";
	
	public static final String PF_ISSUER_URL = "https://<FEDERATION_SERVER_HOSTNAME>:<PORT>";
	public static final String PF_JWKS_URL = "https://<FEDERATION_SERVER_HOSTNAME>:<PORT>/pf/JWKS";
	public static final String PF_INTROSPECT_URL = "https://<FEDERATION_SERVER_HOSTNAME>:<PORT>/as/introspect.oauth2";
	
	public static final String PF_TOKEN_VALIDATION_ACTIVE = "active";
	
	public static final String AUTHORIZATION_ENDPOINT = "https://<FEDERATION_SERVER_HOSTNAME>:<PORT>/as/authorization.oauth2";
	public static final String TOKEN_ENDPOINT = "https://<FEDERATION_SERVER_HOSTNAME>:<PORT>/as/token.oauth2";
	public static final String CLIENT_ID = "client.id";
	public static final String CLIENT_SECRET = "client.secret";
	public static final String ADAPTER_ID = "PingDirAuthAdapter";
	public static final String REDIRECT_URI = "http://<HOSTNAME>:<PORT>/BEISGrantsManagement/authentication/login";
	public static final String SCOPES = "openid profile";
	public static final String USERINFO_ENDPOINT = "https://<FEDERATION_SERVER_HOSTNAME>:<PORT>/idp/userinfo.openid";
	public static final String JWKS_URI = "https://<FEDERATION_SERVER_HOSTNAME>:<PORT>/pf/JWKS";
	public static final String LOGOUT_URI = "https://<FEDERATION_SERVER_HOSTNAME>:<PORT>/as/revoke_token.oauth2";
	public static final String SESSION_REVOCATON_URI = "https://<FEDERATION_SERVER_HOSTNAME>:<PORT>/pf-ws/rest/sessionMgmt/revokedSris";
	
	public static final String UNAUTHORISED = "UNAUTHORISED";
	public static final String GENDER_MALE = "Male";
	public static final String GENDER_FEMALE = "Female";
	
	public static final String BUSINESS_OWNER = "owner";
	public static final String BUSINESS_DELEGATE = "delegate";
	
	public static final String BUSINESS_USERROLE = "userRole";
	public static final String USERROLE_OWNER_KEY ="isOwner";
	public static final String USERROLE_DELEGATE_KEY ="isDelegate";
	
	public static final String BUSINESS_HASCHARGES_KEY = "hasCharges";
	public static final String BUSINESS_RODISPUTED_KEY = "registeredOfficeIsInDispute";
	public static final String BUSINESS_STATUS_KEY = "businessStatus";
	public static final String BUSINESS_HASINSOLVENCY_NOTICES_KEY = "hasInsolvencyNotices";
	public static final String BUSINESS_RISKSCORE_KEY = "riskScore";
	public static final String BUSINESS_CHID_KEY = "chBusinessId";
	public static final String BUSINESS_NAME_KEY = "businessName";
	public static final String BUSINESS_POSTCODE_KEY = "businessPostCode";
	public static final String BUSINESS_CRN_KEY = "businessCRN";
	public static final String BUSINESS_UTR_KEY = "businessUTR";
	public static final String BUSINESS_DUNN_KEY = "businessDUNN";
	public static final String BUSINESS_VAT_KEY = "businessVAT";
	public static final String BUSINESS_PAYE_KEY = "businessPAYE";
	public static final String BUSINESS_SIC_KEY = "businessSIC";
	public static final String BUSINESS_SIC_SICCODES_KEY = "sicCodes";
	public static final String BUSINESS_EMPLOYEES_KEY = "noOfEmployees";
	public static final String BUSINESS_TURNOVER_KEY = "businessTurnOver";
	
	public static final String GENERIC_VALUE_KEY = "value";
	public static final String GENERIC_VERIFIEDDATE_KEY = "verifiedDate";
	public static final String GENERIC_VERIFICATIONSOURCE_KEY = "verificationSource";
	
	public static final String BUSINESS_BANK_KEY = "businessBankDetails";
	public static final String BUSINESS_BANK_SC_KEY = "sortcode";
	public static final String BUSINESS_BANK_AC_KEY = "accountNumber";
	
	public static final String BUSINESS_PSC_KEY = "businessPSC";
	public static final String BUSINESS_PSC_PERSONS_KEY = "personWithSignificantControl";
	public static final String BUSINESS_PSC_NAME_KEY = "name";
	public static final String BUSINESS_PSC_FORENAME_KEY = "forename";
	public static final String BUSINESS_PSC_SURNAME_KEY = "surname";
	public static final String BUSINESS_PSC_TITLE_KEY = "title";
	public static final String BUSINESS_PSC_ID_KEY = "pscID";
	
	
	public static final String BUSINESS_ADDRESS_KEY = "businessAddress";
	public static final String BUSINESS_LOCALITY_KEY = "locality";
	public static final String BUSINESS_PREMISE_KEY = "premise";
	public static final String BUSINESS_ADDRESSLINE1_KEY = "addressLine1";
	public static final String BUSINESS_ADDRESS_POSTCODE_KEY = "postcode";
	
	public static final String REDIRECT = "redirect:";	
	public static final String SESSIONTIMEOUT = "sessiontimeout";
	public static final String SELECTED_BUSINESS_BEAN = "selectedBusinessBean";
	
	public static final String ENCRYPTION_PASSWORD = "${encryption.password}";

	public static final String BUSINESS_OBJECT = "businessObject";
	public static final String OWNER = "owner";
	public static final String REGEX_COLON = ":";
	public static final String AUTHENTICATED_BUSINESS_DETAILS = "/authenticated/business/details";
	public static final String DELEGATE_CONSENT = "delegateConsent";
	public static final String DELEGATE_BUSINESS_LIST = "delegateBusinessList";
	public static final String AUTHENTICATED_BUSINESS_DELEGATE_AJAX = "/authenticated/business/delegate/ajax";
	public static final String APPLICATION_JSON = "application/json";
	public static final String APPROVED = "approved";
	public static final String OWNER_CONSENT = "ownerConsent";
	public static final String OWNED_BUSINESS_LIST = "ownedBusinessList";
	public static final String AUTHENTICATED_BUSINESS_OWNER_AJAX = "/authenticated/business/owner/ajax";
	public static final String ERROR = "error";	
	
	

	public static final String YYYY_MM_DD_HH_MMSS = "yyyyMMddHHmmss";
	public static final String DD_MMM_YYYY = "dd MMM yyyy";
	public static final String BUSINESS = "business";
	public static final String QUESTION_MARK_DEL = "?";
    public static final String SSL = "SSL";
}
