/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.beis.grants.controller;

import org.springframework.stereotype.Controller;

@Controller
public class MiscellaneousController {
	
	/*@RequestMapping(value="/tokens/refresh")
    private String refresh(final HttpServletRequest request, final HttpServletResponse response, final Model model)
            throws IOException {
		ApplicationUtility.redirectIfLoginRequired(request, response);
        model.addAttribute("refresh_token", request.getSession().getAttribute("refresh_token"));
        return "refresh";
    }
	
	*//**
     * A page to display the ID token.
     *
     * @param request  the request object.
     * @param response the response object.
     * @param model    the model to be passed to the view.
     * @return         a string indicating which view to display.
     *//*
    @RequestMapping(value="/tokens/id")
    private String id(final HttpServletRequest request, final HttpServletResponse response, final Model model) throws IOException {
    	
    	ApplicationUtility.redirectIfLoginRequired(request, response);
        
    	final DecodedJWT idToken = (DecodedJWT) request.getSession().getAttribute("id_token");
        final String audience = idToken.getAudience().toString();
        final Date issuedAt = idToken.getIssuedAt();
        final String issuer = idToken.getIssuer();
        final String subject = idToken.getSubject();

        model.addAttribute("id_token", request.getSession().getAttribute("id_token"));
        model.addAttribute("audience", audience);
        model.addAttribute("issuedAt", issuedAt);
        model.addAttribute("issuer", issuer);
        model.addAttribute("subject", subject);

        return "id";
    }
    
    *//**
     * A page to display the access token.
     *
     * @param request  the request object.
     * @param response the response object.
     * @param model    the model to be passed to the view.
     * @return         a string indicating which view to display.
     *//*
    @RequestMapping(value="/tokens/access")
    private String access(final HttpServletRequest request, final HttpServletResponse response, final Model model)
            throws IOException {


    	ApplicationUtility.redirectIfLoginRequired(request, response);

        final DecodedJWT accessToken = (DecodedJWT) request.getSession().getAttribute("access_token");
        final Date expiresAt = accessToken.getExpiresAt();
        final String scopes = accessToken.getClaim("scope").asList(String.class).toString();
        final String clientId = accessToken.getClaim("client_id").asString();

        model.addAttribute("access_token", request.getSession().getAttribute("access_token"));
        model.addAttribute("expiresAt", expiresAt);
        model.addAttribute("subject", accessToken.getClaim("sub").asString());
        model.addAttribute("client_id", clientId);
        model.addAttribute("scopes", scopes.toString());

        return "access";
    }*/

}
