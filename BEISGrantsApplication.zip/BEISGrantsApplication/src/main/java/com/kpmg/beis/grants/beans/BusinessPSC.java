/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.beis.grants.beans;

import java.util.List;

public class BusinessPSC {
	private List<PersonWithSignificantControl> personWithSignificantControl = null;
	private String verifiedDate;
	private String verificationSource;

	
	public BusinessPSC()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public BusinessPSC(List<PersonWithSignificantControl> personWithSignificantControl)
	{
		super();
		this.personWithSignificantControl = personWithSignificantControl;
	}

	public List<PersonWithSignificantControl> getPersonWithSignificantControl() {
		return personWithSignificantControl;
	}

	public void setPersonWithSignificantControl(List<PersonWithSignificantControl> personWithSignificantControl) {
		this.personWithSignificantControl = personWithSignificantControl;
	}

	public String getVerifiedDate() {
		return verifiedDate;
	}

	public void setVerifiedDate(String verifiedDate) {
		this.verifiedDate = verifiedDate;
	}

	public String getVerificationSource() {
		return verificationSource;
	}

	public void setVerificationSource(String verificationSource) {
		this.verificationSource = verificationSource;
	}
	
	@Override
	public String toString()
	{
		String pscStr="";
		StringBuilder builder = new StringBuilder();
		for(PersonWithSignificantControl personSC : this.personWithSignificantControl) {
			builder.append(personSC.toString()).append(",");
		}
		pscStr = builder.toString();
		pscStr = pscStr.substring(0, pscStr.length()-1);
		return pscStr;
	}

}
