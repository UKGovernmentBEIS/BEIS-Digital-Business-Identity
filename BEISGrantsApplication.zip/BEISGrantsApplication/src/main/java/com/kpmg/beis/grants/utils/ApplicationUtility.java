/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.beis.grants.utils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.PropertyException;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.iv.RandomIvGenerator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpmg.beis.grants.beans.Business;

public class ApplicationUtility
{

	public static boolean isNullOrEmptyString(String key)
	{
		if (key == null || key.isEmpty() || key.equals(ApplicationConstants.GENERIC_SPACE))
		{
			return true;
		}
		return false;
	}

	public static void redirectIfLoginRequired(final HttpServletRequest request, final HttpServletResponse response,
			final String encryptionPassword) throws IOException, PropertyException
	{
		if (isLoginRequired(request, encryptionPassword))
		{
			// Redirect to our authorization endpoint to begin the login process
			final String redirectUrl = createRedirectUrl(request, encryptionPassword);
			response.sendRedirect(redirectUrl);
		}
	}

	/**
	 * Determines if a user needs to login.
	 *
	 * @param request
	 *            the request object.
	 * @return returns a boolean indicating that the user needs to login.
	 * @throws IOException
	 * @throws PropertyException
	 */
	public static boolean isLoginRequired(final HttpServletRequest request, final String encryptionPassword)
			throws IOException, PropertyException
	{
		// If the access token cannot be found in the session then we need to login
		TokenValidator validator = new TokenValidator(encryptionPassword);
		final DecodedJWT accessToken = (DecodedJWT) request.getSession()
				.getAttribute(ApplicationConstants.OIDC_ACCESS_TOKEN);
		return (accessToken == null || !validator.isAccessTokenValid(accessToken.getToken(), encryptionPassword));
	}

	/**
	 * Creates the redirect URL from configuration values.
	 *
	 * @param request
	 *            the request object.
	 * @return the redirect URL to be used to initiate a login with Ping Federate.
	 * @throws IOException
	 */
	public static String createRedirectUrl(final HttpServletRequest request, final String encryptionPassword)
			throws IOException
	{
		final String authorizationEndpoint = ApplicationConstants.AUTHORIZATION_ENDPOINT;
		SecretStoreUtils secretUtil = new SecretStoreUtils(encryptionPassword.toCharArray());
		final String clientId = String.valueOf(secretUtil.getSecrete(ApplicationConstants.CLIENT_ID));
		final String adapterId = ApplicationConstants.ADAPTER_ID;
		final String scopes = ApplicationConstants.SCOPES.replace(" ", ApplicationConstants.ENCODED_SPACE);
		final String redirectUri = ApplicationConstants.REDIRECT_URI;
		final String queryString = request.getQueryString();
		final String requestUrl = request.getRequestURL().toString();
		final URL url = new URL(requestUrl);

		final String state = url.getPath()
				+ (queryString == null ? "" : ApplicationConstants.QUESTION_MARK_DEL + queryString);

		final String redirectUrl = String.format(
				"%s?response_type=code&client_id=%s&pfidpadapterid=%s&scope=%s&redirect_uri=%s&state=%s",
				authorizationEndpoint, clientId, adapterId, scopes, redirectUri, state);

		return redirectUrl;
	}

	public static List<Business> getUserBusiness(String accessToken, String userRole) throws IOException
	{
		List<Business> businesses = new ArrayList<Business>();
		String userinfoResponse = PingFederateUtility.getUserInfo(accessToken);

		if (ApplicationConstants.UNAUTHORISED.equals(userinfoResponse))
		{
			System.err.println("User session is not valid. Should send redirect to login.");
		}
		else
		{
			try
			{
				ObjectMapper mapper = new ObjectMapper();
				List<Business> businessList = new ArrayList<Business>();

				if (isJsonArray(userinfoResponse, ApplicationConstants.BUSINESS))
				{
					JSONArray jsonArray = (JSONArray) new JSONObject(userinfoResponse)
							.get(ApplicationConstants.BUSINESS);
					for (int i = 0; i < jsonArray.length(); i++)
					{
						businessList.add(mapper.readValue((String) jsonArray.get(i), Business.class));
					}
				}
				else
				{
					String businessStr = (String) new JSONObject(userinfoResponse).get(ApplicationConstants.BUSINESS);
					businessList.add(mapper.readValue(businessStr, Business.class));
				}

				for (Business business : businessList)
				{
					if (business.getIsOwner() && ApplicationConstants.BUSINESS_OWNER.equals(userRole))
					{
						businesses.add(business);
						continue;
					}

					if (business.getIsDelegate() && ApplicationConstants.BUSINESS_DELEGATE.equals(userRole))
					{
						businesses.add(business);
					}
				}

			}
			catch (JSONException e)
			{
				System.err.println("No businesses for user.");
			}
		}
		return businesses;
	}

	public static String formatDate(String dateOfBirth)
	{
		String pattern = ApplicationConstants.DD_MMM_YYYY;
		try
		{
			Date date = new SimpleDateFormat(ApplicationConstants.YYYY_MM_DD_HH_MMSS).parse(dateOfBirth);
			dateOfBirth = new SimpleDateFormat(pattern).format(date);
		}
		catch (ParseException e)
		{
			e.printStackTrace();
		}
		return dateOfBirth;
	}

	public static String prettyPrintJsonString(JsonNode jsonNode)
	{
		try
		{
			ObjectMapper mapper = new ObjectMapper();
			Object json = mapper.readValue(jsonNode.toString(), Object.class);
			return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(json);
		}
		catch (Exception e)
		{
			return "Sorry, pretty print didn't work";
		}
	}

	public static String getOrNull(JSONObject jsonObj, String key)
	{
		return jsonObj.optString(key, null);
	}

	public static String readEncryptedProperty(String propertyFileName, String propertyKey, String encryptionPassword)
			throws IOException, PropertyException
	{
		String result = null;
		Properties props = new Properties();
		InputStream inStream = ApplicationUtility.class.getClassLoader().getResourceAsStream(propertyFileName);
		if (inStream != null)
		{
			props.load(inStream);
		}
		else
		{
			throw new FileNotFoundException("Property file :: '" + propertyFileName + "' not found in classpath.");
		}

		if (props.isEmpty())
		{
			throw new PropertyException("No properties are defined in '" + propertyFileName + "'");
		}
		else
		{
			String encryptedValue = props.getProperty(propertyKey);
			StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
			encryptor.setPassword(encryptionPassword);
			encryptor.setAlgorithm(ApplicationConstants.PBE_WITH_HMACSHA512_AND_AES_256);
			encryptor.setIvGenerator(new RandomIvGenerator());
			result = encryptor.decrypt(encryptedValue);
		}

		return result;
	}

	public static void invalidateSession(final HttpServletRequest request)
	{
		request.getSession().invalidate();
		request.getSession(false);
	}

	private static boolean isJsonArray(String jsonString, String attribute)
	{
		boolean responseIsArray = true;
		JSONObject jsonObj = new JSONObject(jsonString);
		Object parsedObject = jsonObj.get(attribute);

		if (parsedObject != null && !(parsedObject instanceof JSONArray))
		{
			String parsedJsonStr = (String) parsedObject;

			if (!parsedJsonStr.trim().startsWith("["))
			{
				responseIsArray = false;
			}
		}
		return responseIsArray;
	}

}
