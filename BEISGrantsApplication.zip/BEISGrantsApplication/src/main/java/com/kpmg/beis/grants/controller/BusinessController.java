/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.beis.grants.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpmg.beis.grants.beans.Business;
import com.kpmg.beis.grants.beans.SelectedBusinessBean;
import com.kpmg.beis.grants.beans.WrapperBean;
import com.kpmg.beis.grants.utils.ApplicationConstants;
import com.kpmg.beis.grants.utils.ApplicationUtility;
import com.kpmg.beis.grants.utils.TokenValidator;
import com.nimbusds.jwt.proc.BadJWTException;

@Controller
public class BusinessController
{

	@Value(ApplicationConstants.ENCRYPTION_PASSWORD)
	private String encryptionPassword;

	public String getEncryptionPassword()
	{
		return encryptionPassword;
	}

	public void setEncryptionPassword(String encryptionPassword)
	{
		this.encryptionPassword = encryptionPassword;
	}

	@RequestMapping(value = ApplicationConstants.PATH_AUTHENTICATED_BUSINESS_OWNER)
	private String showBusinessOwnerPage(final HttpServletRequest request, final HttpServletResponse response,
			final Model model) throws IOException
	{
		String returnView = ApplicationConstants.VIEW_ERROR;
		try
		{
			ApplicationUtility.redirectIfLoginRequired(request, response, this.getEncryptionPassword());
			TokenValidator validator = new TokenValidator(this.getEncryptionPassword());

			// fetch access_token from session
			final String accessToken = (String) request.getSession()
					.getAttribute(ApplicationConstants.SESSION_ATTR_ACCESS_TOKEN_TEXT);
			if (ApplicationUtility.isNullOrEmptyString(accessToken))
			{
				System.err.println("Access token could not be retrieved from session. Sending to error page.");
			}
			else if (accessToken != null && validator.isAccessTokenValid(accessToken, this.getEncryptionPassword()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(ApplicationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{

					List<Business> businesses = ApplicationUtility.getUserBusiness(accessToken,
							ApplicationConstants.BUSINESS_OWNER);
					WrapperBean wrapperBean = new WrapperBean();
					wrapperBean.setBusinessList(businesses);
					model.addAttribute(ApplicationConstants.MODEL_ATTR_WRAPPER_BEAN, wrapperBean);
					model.addAttribute(ApplicationConstants.MODEL_ATTR_USER_ROLE,
							ApplicationConstants.USER_ROLE_BUSINESS_OWNER);
					model.addAttribute(ApplicationConstants.MODEL_ATTR_BUSINESSES, businesses);
					returnView = ApplicationConstants.VIEW_BUSINESS_HOME;
				}
				else
				{
					ApplicationUtility.invalidateSession(request);
					return ApplicationConstants.SESSIONTIMEOUT;
				}
			}
		}
		catch (BadJWTException e)
		{
			ApplicationUtility.invalidateSession(request);
			return ApplicationConstants.SESSIONTIMEOUT;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(ApplicationConstants.VIEW_ERROR, e.getMessage());
			returnView = ApplicationConstants.VIEW_ERROR;
		}
		return returnView;
	}

	@RequestMapping(value = ApplicationConstants.AUTHENTICATED_BUSINESS_OWNER_AJAX)
	private void getOwnedBusinessList(final HttpServletRequest request, final HttpServletResponse response,
			final Model model) throws IOException
	{
		try
		{
			ApplicationUtility.redirectIfLoginRequired(request, response, this.getEncryptionPassword());
			TokenValidator validator = new TokenValidator(this.getEncryptionPassword());

			// fetch access_token from session
			final String accessToken = (String) request.getSession()
					.getAttribute(ApplicationConstants.SESSION_ATTR_ACCESS_TOKEN_TEXT);
			if (ApplicationUtility.isNullOrEmptyString(accessToken))
			{
				System.err.println("Access token could not be retrieved from session. Sending to error page.");
			}
			else if (validator.isAccessTokenValid(accessToken, this.getEncryptionPassword()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(ApplicationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					List<Business> businesses = ApplicationUtility.getUserBusiness(accessToken,
							ApplicationConstants.BUSINESS_OWNER);

					if (!businesses.isEmpty())
					{
						request.getSession().setAttribute(ApplicationConstants.OWNED_BUSINESS_LIST, businesses);
						request.getSession().setAttribute(ApplicationConstants.OWNER_CONSENT,
								ApplicationConstants.APPROVED);
						model.addAttribute(ApplicationConstants.OWNED_BUSINESS_LIST, businesses);
						response.setContentType(ApplicationConstants.APPLICATION_JSON);
						OutputStream outputStream = response.getOutputStream();
						ObjectMapper mapper = new ObjectMapper();
						String jsonResult = mapper.writeValueAsString(businesses);
						outputStream.write(jsonResult.getBytes());
						outputStream.flush();
					}
					else
					{
						response.setStatus(HttpServletResponse.SC_NOT_FOUND);
						response.getWriter().write("No businesses linked as owner.");
						request.getSession().setAttribute("noOwnerBusinessError", "No businesses linked as owner.");
						response.flushBuffer();
					}
				}
				else
				{
					ApplicationUtility.invalidateSession(request);
					response.setStatus(HttpServletResponse.SC_REQUEST_TIMEOUT);
					response.getWriter().write("Session is expired. Please re-login to continue.");
					response.flushBuffer();
				}
			}
		}
		catch (BadJWTException e)
		{

			try
			{
				ApplicationUtility.invalidateSession(request);
				response.setStatus(HttpServletResponse.SC_REQUEST_TIMEOUT);
				response.getWriter().write("Session is expired. Please re-login to continue.");
				response.flushBuffer();
			}
			catch (IOException e1)
			{
				e1.printStackTrace();
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(ApplicationConstants.VIEW_ERROR, e.getMessage());
		}

	}

	@RequestMapping(value = ApplicationConstants.AUTHENTICATED_BUSINESS_DELEGATE_AJAX)
	private void getDelegateBusinessList(final HttpServletRequest request, final HttpServletResponse response,
			final Model model) throws IOException
	{

		try
		{
			ApplicationUtility.redirectIfLoginRequired(request, response, this.getEncryptionPassword());
			TokenValidator validator = new TokenValidator(this.getEncryptionPassword());

			// fetch access_token from session
			final String accessToken = (String) request.getSession()
					.getAttribute(ApplicationConstants.SESSION_ATTR_ACCESS_TOKEN_TEXT);
			if (ApplicationUtility.isNullOrEmptyString(accessToken))
			{
				System.err.println("Access token could not be retrieved from session. Sending to error page.");
			}
			else if (validator.isAccessTokenValid(accessToken, this.getEncryptionPassword()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(ApplicationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					List<Business> businesses = ApplicationUtility.getUserBusiness(accessToken,
							ApplicationConstants.BUSINESS_DELEGATE);

					if (!businesses.isEmpty())
					{
						model.addAttribute(ApplicationConstants.DELEGATE_BUSINESS_LIST, businesses);
						request.getSession().setAttribute(ApplicationConstants.DELEGATE_BUSINESS_LIST, businesses);
						request.getSession().setAttribute(ApplicationConstants.DELEGATE_CONSENT,
								ApplicationConstants.APPROVED);
						response.setContentType(ApplicationConstants.APPLICATION_JSON);
						OutputStream outputStream = response.getOutputStream();
						ObjectMapper mapper = new ObjectMapper();
						String jsonResult = mapper.writeValueAsString(businesses);
						outputStream.write(jsonResult.getBytes());
						outputStream.flush();
					}
					else
					{
						response.setStatus(HttpServletResponse.SC_NOT_FOUND);
						response.getWriter().write("No businesses linked as delegate.");
						request.getSession().setAttribute("noDelegateBusinessError",
								"No businesses linked as delegate.");
						response.flushBuffer();
					}
				}
				else
				{
					ApplicationUtility.invalidateSession(request);
					response.setStatus(HttpServletResponse.SC_REQUEST_TIMEOUT);
					response.getWriter().write("Session is expired. Please re-login to continue.");
					response.flushBuffer();
				}
			}
		}
		catch (BadJWTException e)
		{

			try
			{
				ApplicationUtility.invalidateSession(request);
				response.setStatus(HttpServletResponse.SC_REQUEST_TIMEOUT);
				response.getWriter().write("Session is expired. Please re-login to continue.");
				response.flushBuffer();
			}
			catch (IOException e1)
			{
				e1.printStackTrace();
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(ApplicationConstants.VIEW_ERROR, e.getMessage());
		}

	}

	@RequestMapping(value = ApplicationConstants.PATH_AUTHENTICATED_BUSINESS_DELEGATE)
	private String showBusinessDelegatePage(final HttpServletRequest request, final HttpServletResponse response,
			final Model model) throws IOException
	{
		String returnView = ApplicationConstants.VIEW_ERROR;
		try
		{
			ApplicationUtility.redirectIfLoginRequired(request, response, this.getEncryptionPassword());
			TokenValidator validator = new TokenValidator(this.getEncryptionPassword());

			// fetch access_token from session
			final String accessToken = (String) request.getSession()
					.getAttribute(ApplicationConstants.SESSION_ATTR_ACCESS_TOKEN_TEXT);
			if (ApplicationUtility.isNullOrEmptyString(accessToken))
			{
				System.err.println("Access token could not be retrieved from session. Sending to error page.");
			}
			else if (validator.isAccessTokenValid(accessToken, this.getEncryptionPassword()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(ApplicationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					List<Business> businesses = ApplicationUtility.getUserBusiness(accessToken,
							ApplicationConstants.BUSINESS_DELEGATE);
					WrapperBean wrapperBean = new WrapperBean();
					wrapperBean.setBusinessList(businesses);

					model.addAttribute(ApplicationConstants.MODEL_ATTR_WRAPPER_BEAN, wrapperBean);
					model.addAttribute(ApplicationConstants.MODEL_ATTR_USER_ROLE,
							ApplicationConstants.USER_ROLE_DELEGATE);
					model.addAttribute(ApplicationConstants.MODEL_ATTR_BUSINESSES, businesses);
					returnView = ApplicationConstants.VIEW_BUSINESS_HOME;
				}
				else
				{
					ApplicationUtility.invalidateSession(request);
					return ApplicationConstants.SESSIONTIMEOUT;
				}
			}
		}
		catch (BadJWTException e)
		{
			ApplicationUtility.invalidateSession(request);
			return ApplicationConstants.SESSIONTIMEOUT;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(ApplicationConstants.ERROR, e.getMessage());
			returnView = ApplicationConstants.ERROR;
		}
		return returnView;
	}

	@RequestMapping(value = ApplicationConstants.AUTHENTICATED_BUSINESS_DETAILS)
	private String loadRegistrationViaIDP(final HttpServletRequest request, final HttpServletResponse response,
			@Valid @ModelAttribute(ApplicationConstants.SELECTED_BUSINESS_BEAN) SelectedBusinessBean selectedOption,
			final Model model)
	{
		try
		{
			ApplicationUtility.redirectIfLoginRequired(request, response, this.getEncryptionPassword());
			TokenValidator validator = new TokenValidator(this.getEncryptionPassword());
			final String accessToken = (String) request.getSession()
					.getAttribute(ApplicationConstants.SESSION_ATTR_ACCESS_TOKEN_TEXT);
			if (ApplicationUtility.isNullOrEmptyString(accessToken))
			{
				System.err.println("Access token could not be retrieved from session. Sending to error page.");
			}
			else if (validator.isAccessTokenValid(accessToken, this.getEncryptionPassword()))
			{
				final DecodedJWT idToken = (DecodedJWT) request.getSession()
						.getAttribute(ApplicationConstants.OIDC_ID_TOKEN);

				if (idToken != null && validator.isIdTokenValid(idToken.getToken()))
				{
					String selectedId = selectedOption.getSelectedBusinessId();

					if (selectedId != null)
					{
						String[] optionDetails = selectedId.split(ApplicationConstants.REGEX_COLON);
						String userRole = optionDetails[0];
						String businessId = optionDetails[1];
						List<Business> listOfBusiness = null;
						if (userRole.equalsIgnoreCase(ApplicationConstants.OWNER))
						{
							listOfBusiness = ApplicationUtility.getUserBusiness(accessToken,
									ApplicationConstants.BUSINESS_OWNER);
							request.getSession().setAttribute(ApplicationConstants.OWNED_BUSINESS_LIST, listOfBusiness);
						}
						else
						{
							listOfBusiness = ApplicationUtility.getUserBusiness(accessToken,
									ApplicationConstants.BUSINESS_DELEGATE);
							request.getSession().setAttribute(ApplicationConstants.DELEGATE_BUSINESS_LIST,
									listOfBusiness);
						}

						if (listOfBusiness != null && !listOfBusiness.isEmpty())
						{
							for (Business business : listOfBusiness)
							{
								if (business.getChBusinessId().getValue().equals(businessId))
								{
									model.addAttribute(ApplicationConstants.BUSINESS_OBJECT, business);
									break;
								}
							}
							return ApplicationConstants.VIEW_BUSINESS_HOME;
						}
					}
				}
				else
				{
					ApplicationUtility.invalidateSession(request);
					return ApplicationConstants.SESSIONTIMEOUT;
				}
			}
		}
		catch (BadJWTException e)
		{
			ApplicationUtility.invalidateSession(request);
			return ApplicationConstants.SESSIONTIMEOUT;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute(ApplicationConstants.ERROR, e.getMessage());
		}
		return ApplicationConstants.VIEW_ERROR;
	}
}
