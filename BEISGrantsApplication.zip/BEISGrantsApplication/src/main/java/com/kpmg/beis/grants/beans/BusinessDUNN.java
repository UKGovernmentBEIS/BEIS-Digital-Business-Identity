/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.beis.grants.beans;

public class BusinessDUNN {
	private String value;
	private String verifiedDate;
	private String verificationSource;

	public String getValue() {
	return value;
	}

	
	public BusinessDUNN()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public BusinessDUNN(String value)
	{
		super();
		this.value = value;
	}


	public void setValue(String value) {
	this.value = value;
	}

	public String getVerifiedDate() {
	return verifiedDate;
	}

	public void setVerifiedDate(String verifiedDate) {
	this.verifiedDate = verifiedDate;
	}

	public String getVerificationSource() {
	return verificationSource;
	}

	public void setVerificationSource(String verificationSource) {
	this.verificationSource = verificationSource;
	}
}
