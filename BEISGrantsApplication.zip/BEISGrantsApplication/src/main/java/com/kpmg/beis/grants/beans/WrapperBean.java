/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.beis.grants.beans;

import java.util.List;

public class WrapperBean
{

	private List<Business> businessList;

	public List<Business> getBusinessList()
	{
		return businessList;
	}

	public void setBusinessList(List<Business> businessList)
	{
		this.businessList = businessList;
	}

	private Business businessSelected;

	public Business getBusinessSelected()
	{
		return businessSelected;
	}

	public void setBusinessSelected(Business businessSelected)
	{
		this.businessSelected = businessSelected;
	}

}
