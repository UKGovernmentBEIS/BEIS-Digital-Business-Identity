/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.beis.grants.beans;

public class Business
{
	private ChBusinessId chBusinessId;
	private BusinessName businessName;
	private BusinessAddress businessAddress;
	private BusinessPostCode businessPostCode;
	private Boolean isOwner;
	private Boolean isDelegate;
	private BusinessCRN businessCRN;
	private BusinessUTR businessUTR;
	private BusinessDUNN businessDUNN;
	private BusinessVAT businessVAT;
	private BusinessPAYE businessPAYE;
	private BusinessSIC businessSIC;
	private BusinessBankDetails businessBankDetails;
	private BusinessPSC businessPSC;
	private NoOfEmployees noOfEmployees;
	private BusinessTurnOver businessTurnOver;
	private boolean hasCharges;
	private boolean registeredOfficeIsInDispute;
	private String businessStatus;
	private boolean hasInsolvencyNotices;
	private int riskScore;

	public ChBusinessId getChBusinessId()
	{
		return chBusinessId;
	}

	public void setChBusinessId(ChBusinessId chBusinessId)
	{
		this.chBusinessId = chBusinessId;
	}

	public BusinessName getBusinessName()
	{
		return businessName;
	}

	public void setBusinessName(BusinessName businessName)
	{
		this.businessName = businessName;
	}

	public BusinessAddress getBusinessAddress()
	{
		return businessAddress;
	}

	public void setBusinessAddress(BusinessAddress businessAddress)
	{
		this.businessAddress = businessAddress;
	}

	public BusinessPostCode getBusinessPostCode()
	{
		return businessPostCode;
	}

	public void setBusinessPostCode(BusinessPostCode businessPostCode)
	{
		this.businessPostCode = businessPostCode;
	}

	public Boolean getIsOwner()
	{
		return isOwner;
	}

	public void setIsOwner(Boolean isOwner)
	{
		this.isOwner = isOwner;
	}

	public Boolean getIsDelegate()
	{
		return isDelegate;
	}

	public void setIsDelegate(Boolean isDelegate)
	{
		this.isDelegate = isDelegate;
	}

	public BusinessCRN getBusinessCRN()
	{
		return businessCRN;
	}

	public void setBusinessCRN(BusinessCRN businessCRN)
	{
		this.businessCRN = businessCRN;
	}

	public BusinessUTR getBusinessUTR()
	{
		return businessUTR;
	}

	public void setBusinessUTR(BusinessUTR businessUTR)
	{
		this.businessUTR = businessUTR;
	}

	public BusinessDUNN getBusinessDUNN()
	{
		return businessDUNN;
	}

	public void setBusinessDUNN(BusinessDUNN businessDUNN)
	{
		this.businessDUNN = businessDUNN;
	}

	public BusinessVAT getBusinessVAT()
	{
		return businessVAT;
	}

	public void setBusinessVAT(BusinessVAT businessVAT)
	{
		this.businessVAT = businessVAT;
	}

	public BusinessPAYE getBusinessPAYE()
	{
		return businessPAYE;
	}

	public void setBusinessPAYE(BusinessPAYE businessPAYE)
	{
		this.businessPAYE = businessPAYE;
	}

	public BusinessSIC getBusinessSIC()
	{
		return businessSIC;
	}

	public void setBusinessSIC(BusinessSIC businessSIC)
	{
		this.businessSIC = businessSIC;
	}

	public BusinessBankDetails getBusinessBankDetails()
	{
		return businessBankDetails;
	}

	public void setBusinessBankDetails(BusinessBankDetails businessBankDetails)
	{
		this.businessBankDetails = businessBankDetails;
	}

	public BusinessPSC getBusinessPSC()
	{
		return businessPSC;
	}

	public void setBusinessPSC(BusinessPSC businessPSC)
	{
		this.businessPSC = businessPSC;
	}

	public NoOfEmployees getNoOfEmployees()
	{
		return noOfEmployees;
	}

	public void setNoOfEmployees(NoOfEmployees noOfEmployees)
	{
		this.noOfEmployees = noOfEmployees;
	}

	public BusinessTurnOver getBusinessTurnOver()
	{
		return businessTurnOver;
	}

	public void setBusinessTurnOver(BusinessTurnOver businessTurnOver)
	{
		this.businessTurnOver = businessTurnOver;
	}

	public boolean isHasCharges()
	{
		return hasCharges;
	}

	public void setHasCharges(boolean hasCharges)
	{
		this.hasCharges = hasCharges;
	}

	public boolean isRegisteredOfficeIsInDispute()
	{
		return registeredOfficeIsInDispute;
	}

	public void setRegisteredOfficeIsInDispute(boolean registeredOfficeIsInDispute)
	{
		this.registeredOfficeIsInDispute = registeredOfficeIsInDispute;
	}

	public String getBusinessStatus()
	{
		return businessStatus;
	}

	public void setBusinessStatus(String businessStatus)
	{
		this.businessStatus = businessStatus;
	}

	public boolean isHasInsolvencyNotices()
	{
		return hasInsolvencyNotices;
	}

	public void setHasInsolvencyNotices(boolean hasInsolvencyNotices)
	{
		this.hasInsolvencyNotices = hasInsolvencyNotices;
	}

	public int getRiskScore()
	{
		return riskScore;
	}

	public void setRiskScore(int riskScore)
	{
		this.riskScore = riskScore;
	}
}
