/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.beis.grants.utils;

import java.io.IOException;
import java.net.URL;
import java.text.ParseException;

import javax.xml.bind.PropertyException;

import org.json.JSONObject;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.proc.BadJOSEException;
import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt.JWTParser;
import com.nimbusds.oauth2.sdk.auth.Secret;
import com.nimbusds.oauth2.sdk.id.ClientID;
import com.nimbusds.oauth2.sdk.id.Issuer;
import com.nimbusds.openid.connect.sdk.validators.IDTokenValidator;

public class TokenValidator
{

	Issuer iss = null;
	ClientID clientId = null;
	JWSAlgorithm jwsAlg = null;
	URL jwksetURL = null;
	Secret clientSecret = null;

	public TokenValidator(final String encryptionPassword) throws IOException, PropertyException
	{
		SecretStoreUtils secretUtil = new SecretStoreUtils(encryptionPassword.toCharArray());
		iss = new Issuer(ApplicationConstants.PF_ISSUER_URL);
		clientId = new ClientID(String.valueOf(secretUtil.getSecrete(ApplicationConstants.CLIENT_ID)));
		jwsAlg = JWSAlgorithm.HS256;
		jwksetURL = new URL(ApplicationConstants.PF_JWKS_URL);
		clientSecret = new Secret(String.valueOf(secretUtil.getSecrete(ApplicationConstants.CLIENT_SECRET)));
	}

	public boolean isIdTokenValid(String idTokenText) throws Exception
	{
		boolean tokenValid = false;
		IDTokenValidator validator = new IDTokenValidator(iss, clientId, jwsAlg, clientSecret);
		JWT idToken;
		try
		{
			idToken = JWTParser.parse(idTokenText);
			validator.validate(idToken, null);
			tokenValid = true;
		}
		catch (ParseException | BadJOSEException | JOSEException e)
		{
			throw e;
		}
		return tokenValid;
	}

	public boolean isAccessTokenValid(String accessToken, String encryptionPassword) throws IOException
	{
		boolean result = false;
		OAuth2Helper helper = new OAuth2Helper(ApplicationConstants.PF_INTROSPECT_URL);
		try
		{
			String apiResponse = helper.checkAccessTokenValidity(accessToken, encryptionPassword);
			if (apiResponse == null)
			{
				System.out.println("No response received from the API call.");
			}
			else
			{
				JSONObject json = new JSONObject(apiResponse);
				if (json.has(ApplicationConstants.PF_TOKEN_VALIDATION_ACTIVE))
				{
					result = json.getBoolean(ApplicationConstants.PF_TOKEN_VALIDATION_ACTIVE);
				}
			}
		}
		catch (IOException e)
		{
			throw e;
		}
		return result;
	}

}
