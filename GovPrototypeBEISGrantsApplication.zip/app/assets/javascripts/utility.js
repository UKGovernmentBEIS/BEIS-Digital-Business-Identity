const fs = require('fs')
const request = require('request')
const jwt = require('jsonwebtoken');
const config = require('../../config.js')
const jsr = require('jsrsasign')
const rp = require('request-promise')
const async = require('async')
const await = require('await')

exports.isArray = function(what) {
  return Object.prototype.toString.call(what) === '[object Array]';
}

exports.getIdTokenParts = function(token) {
  var decoded = jwt.decode(token, {complete: true});
  return [decoded.header, decoded.payload, decoded.signature];
}

exports.isIdTokenValid = function (idToken) {
  let valid = false;
  if(idToken) {
    let idtParts = getIdTokenParts(idToken);
    let payload = JSON.parse(idtParts[1]);
    if(payload) {
      let now = new Date() / 1000;
          if (payload['iat'] > now + (5 * 60)) {
            console.error('ID Token issued time is later than current time');
            valid = false;
          } else valid = true;

          if (valid && payload['exp'] < now - (5 * 60)) {
            console.error('ID Token expired');
            valid = false;
          } else valid = true;

          let audience = null;
          if(payload['aud']) {
            if (payload['aud'] instanceof Array) {
              audience = payload['aud'][0];
            } else {
              audience = payload['aud'];
            }
          }
          if (valid && audience !== config.clientId) {
            console.error('invalid audience');
            valid = false;
          } else valid = true;

          if (valid && payload['iss'] !== config.issuer) {
            console.error('Invalid Issuer');
            valid = false;
          } else valid = true;
    }

    let validSig = verifyIdTokenSig(idToken);
  }
  return valid && validSig;
}

function verifyIdTokenSig(token) {
  let verified = false;
  let idtParts = getIdTokenParts(token);
  let header = JSON.parse(idtParts[0]);
  let jwks = JSON.parse(config.jwks_uri);

  if(!jwks) {
    console.error('No JWK keyset');
  } else {
    if(header['alg'] && header['alg'].substr(0, 2) === 'RS') {
      let jwk = jwkGetKey(jwks, 'RSA', 'sig', header['kid']);
      if (!jwk) {
        console.error('No matching JWK found');
      } else {
        verified = rsaVerifyJWS(id_token, jwk[0]);
      }
    }
  }
  return verified;
}

/**
   * Verifies the JWS string using the JWK
   * @param {string} jws      - The JWS string
   * @param {object} jwk      - The JWK Key that will be used to verify the signature
   * @returns {boolean}       - Validity of the JWS signature
   * @throws {AuthException}
   */
  function rsaVerifyJWS(jws, jwk) {
    if (jws && typeof jwk === 'object') {
        if (jwk['kty'] === 'RSA') {
          let verifier = jsr.KJUR.jws.JWS;
          if (jwk['n'] && jwk['e']) {
            let pubkey = jsr.KEYUTIL.getKey({kty: 'RSA', n: jwk['n'], e: jwk['e']});
            return verifier.verify(jws, pubkey, ['RS256']);
          } else if (jwk['x5c']) {
            return verifier.verifyJWSByPemX509Cert(jws,
                "-----BEGIN CERTIFICATE-----\n" + jwk['x5c'][0]
                + "\n-----END CERTIFICATE-----\n");
          }
        } else {
          console.error('No RSA kty in JWK');
          return false;
        }
      }
  }

function jwkGetKey(jwkIn, kty, use, kid) {
  let jwk = null;
      let foundKeys = [];

      if (jwkIn) {
        if (typeof jwkIn === 'string') {
          jwk = JSON.parse(jwkIn);
        } else if (typeof jwkIn === 'object') {
          jwk = jwkIn;
        }

        if (jwk != null) {
          if (typeof jwk['keys'] === 'object') {
            if (jwk.keys.length === 0) {
              return null;
            }

            for (let i = 0; i < jwk.keys.length; i++) {
              if (jwk['keys'][i]['kty'] === kty) {
                foundKeys.push(jwk.keys[i]);
              }
            }

            if (foundKeys.length === 0) {
              return null;
            }

            if (use) {
              let temp = [];
              for (let j = 0; j < foundKeys.length; j++) {
                if (!foundKeys[j]['use']) {
                  temp.push(foundKeys[j]);
                } else if (foundKeys[j]['use'] === use) {
                  temp.push(foundKeys[j]);
                }
              }
              foundKeys = temp;
            }
            if (foundKeys.length === 0) {
              return null;
            }

            if (kid) {
              temp = [];
              for (let k = 0; k < foundKeys.length; k++) {
                if (foundKeys[k]['kid'] === kid) {
                  temp.push(foundKeys[k]);
                }
              }
              foundKeys = temp;
            }
            if (foundKeys.length === 0) {
              return null;
            } else {
              return foundKeys;
            }
          }
        }
      }
  }

  exports.isAccessTokenValid = async function (accessToken) {
    const postResponse = await checkAccessTokenValid(accessToken);
    return postResponse;
  }

  function checkAccessTokenValid(accessToken) {
    var auth = "Basic "+ new Buffer(config.clientId +":"+config.clientSecret).toString("base64");
    var headersOpt = {
      "Authorization": auth,
      'content-type': 'application/x-www-form-urlencoded'
    }
    return rp.post(config.token_introspect_url, {
      form: {
        'token': accessToken,
        'token_type_hint': 'access_token'
      },
      headers: headersOpt
    }
  )}


exports.renderDate = function(date){
    var res = date.split("");
    var year = res[0].concat(res[1]).concat(res[2]).concat(res[3]);
    var month = "";
    var monthDigit= res[4].concat(res[5]);
    if(monthDigit=='01'){
      month = 'Jan';
    }else if(monthDigit=='02'){
      month = 'Feb';
    }else if(monthDigit=='03'){
      month = 'Mar';
    }else if(monthDigit=='04'){
      month = 'Apr';
    }else if(monthDigit=='05'){
      month = 'May';
    }else if(monthDigit=='06'){
      month = 'Jun';
    }else if(monthDigit=='07'){
      month = 'Jul';
    }else if(monthDigit=='08'){
      month = 'Aug';
    }else if(monthDigit=='09'){
      month = 'Sep';
    }else if(monthDigit=='10'){
      month = 'Oct';
    }else if(monthDigit=='11'){
      month = 'Nov';
    }else if(monthDigit=='12'){
      month = 'Dec';
    }
    var day = res[6].concat(res[7]);

    return day+" "+month+" "+year;
  }
