const request = require('request');
const utility = require('./assets/javascripts/utility')
const express = require('express')
const config = require('./config')
const router = express.Router()

// Add your routes here - above the module.exports line
router.get('/welcome', function(req, res, next){
  if(utility.isIdTokenValid) {
    var idTokenParts = utility.getIdTokenParts(req.session.idToken);
    var pingFedSessionId = idTokenParts[1]['pi.sri'];
    req.session.pingFedSessionId = pingFedSessionId;

    var user = {
      'displayName': idTokenParts[1].name.toUpperCase(),
      'dob' : utility.renderDate(idTokenParts[1].birthdate),
      'gender': idTokenParts[1].gender.toUpperCase(),
      'address':idTokenParts[1].address.toUpperCase()
    };
    req.session.user = user;
    res.render('welcome', {'displayName': idTokenParts[1].name.toUpperCase(), 'user': user});
  } else {
    res.redirect('/login');
  }
})

router.get('/welcome/submit', function(req,res,next){
  var user = req.session.user;
  res.render('confirmation', {'user': user});
});

router.get('/welcome/showBusinesses', function(req, res, next) {
  utility.isAccessTokenValid(req.session.accessToken).then(function(response){
    let valid = JSON.parse(response).active;
    if(valid == true) {
      request.get(config.userInfoURL, {
        'auth': {
          'bearer': req.session.accessToken
        }
      }, function (err, response, body){
        var userInfo = JSON.parse(body);
        var businesses = utility.isArray(userInfo.business) ? userInfo.business : [userInfo.business.replace(/\\/g, "")];
        var ownedBusiness = [];
        var delegatedBusiness = [];

        for (var i = 0; i < businesses.length; i++) {
          var business = JSON.parse(businesses[i]);
          if(business.isOwner) {
            ownedBusiness.push(business);
          }
          if(business.isDelegate) {
            delegatedBusiness.push(business);
          }
        }
        res.render('showBusinesses',{'user': req.session.user, 'ownedBusiness':ownedBusiness, 'delegatedBusiness': delegatedBusiness});
      })
    } else {
      res.redirect('/login');
    }
  })
});

  router.get('/welcome/businessDetails/:chBusinessId', function(req,res,next){
    utility.isAccessTokenValid(req.session.accessToken).then(function(response){
      let valid = JSON.parse(response).active;
      if(valid == true){
        request.get(config.userInfoURL, {
          'auth': {
            'bearer': req.session.accessToken
          }
        }, function (err, response, body){
          var userInfo = JSON.parse(body);

          var businesses = utility.isArray(userInfo.business) ? userInfo.business : [userInfo.business.replace(/\\/g, "")];
          var selectedBusiness;
          for (var i = 0; i < businesses.length; i++) {
            var business = JSON.parse(businesses[i]);

            if(business.chBusinessId.value === req.params.chBusinessId ) {
              selectedBusiness = business;
              break;
            }
          }
          res.render('businessDetails',{'user': req.session.user, 'business':selectedBusiness});
        })
      } else {
        res.redirect('/login');
      }
    })

  });

  module.exports = router
