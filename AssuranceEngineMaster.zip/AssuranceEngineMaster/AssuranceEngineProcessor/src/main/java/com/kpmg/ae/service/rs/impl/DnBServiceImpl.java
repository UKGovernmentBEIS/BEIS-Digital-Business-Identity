/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.rs.impl;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.kpmg.ae.service.bean.Company;
import com.kpmg.ae.service.constants.AssuranceEngineConstants;
import com.kpmg.ae.service.rs.intf.DnBService;
import com.kpmg.ae.service.utilities.AssuranceEngineUtility;

public class DnBServiceImpl implements DnBService
{
	JSONArray dnbCompaniesArray;

	public DnBServiceImpl() throws IOException, ParseException
	{
		InputStream in = DnBServiceImpl.class.getResourceAsStream(AssuranceEngineConstants.CONFIG_DNB_JSON);
		JSONParser parser = new JSONParser();
		Object fileContents = parser.parse(new InputStreamReader(in));
		dnbCompaniesArray = (JSONArray) fileContents;
	}

	/**
	 * @purpose find company details matching with company number from D&B (for now from JSON file)
	 * @since January 20, 2020
	 * @param companyNumber
	 */
	public JSONObject findCompanyDetailsByCompanyNumber(String companyNumber)
	{

		for (Object companyObjectFromFile : dnbCompaniesArray)
		{

			JSONObject companyJsonObj = (JSONObject) companyObjectFromFile;
			if (AssuranceEngineUtility.isMatching(companyJsonObj, AssuranceEngineConstants.COMPANY_ID, companyNumber))
			{
				return companyJsonObj;
			}
		}
		return null;
	}

	@Override
	public void getAdditionalInfoFromDnB(Company company)
	{
		for (Object companyObjectFromFile : dnbCompaniesArray)
		{
			JSONObject companyJsonObj = (JSONObject) companyObjectFromFile;
			if (AssuranceEngineUtility.isMatching(companyJsonObj, AssuranceEngineConstants.COMPANY_ID,
					company.getChCompanyId()))
			{
				company.setBusinessDUNN((String) companyJsonObj.get(AssuranceEngineConstants.DUNN));
				break;
			}
		}
	}
}
