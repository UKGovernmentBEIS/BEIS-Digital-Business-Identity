/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LastVariation
{

	@JsonProperty("case_identifier")
	private String caseIdentifier;
	@JsonProperty("court_name")
	private String courtName;
	@JsonProperty("varied_on")
	private Date variedOn;

	public void setCaseIdentifier(String caseIdentifier)
	{
		this.caseIdentifier = caseIdentifier;
	}

	public String getCaseIdentifier()
	{
		return caseIdentifier;
	}

	public void setCourtName(String courtName)
	{
		this.courtName = courtName;
	}

	public String getCourtName()
	{
		return courtName;
	}

	public void setVariedOn(Date variedOn)
	{
		this.variedOn = variedOn;
	}

	public Date getVariedOn()
	{
		return variedOn;
	}

}
