/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.webservice;

import java.io.IOException;
import java.io.InvalidObjectException;
import java.util.Properties;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

import com.kpmg.ae.service.utilities.AssuranceEngineUtility;

public abstract class AssuranceEngineWebServiceProvider
{
	private Client webClient;
	private Properties resourcesProperties;

	public AssuranceEngineWebServiceProvider() throws IOException
	{
		webClient = ClientBuilder.newClient();
		resourcesProperties = AssuranceEngineUtility.getResourcesProperties();
	}

	public Client getWebClient() throws InvalidObjectException
	{
		if (null == webClient)
		{
			throw new InvalidObjectException("Invalid request for uninitialised web client.");
		}
		return webClient;
	}

	public Properties getResourcesProperties()
	{
		return resourcesProperties;
	}

	public abstract WebTarget getWebTarget();
}
