/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Reason
{

	private String act;
	private String article;
	@JsonProperty("description_identifier")
	private String descriptionIdentifier;
	private String section;

	public void setAct(String act)
	{
		this.act = act;
	}

	public String getAct()
	{
		return act;
	}

	public void setArticle(String article)
	{
		this.article = article;
	}

	public String getArticle()
	{
		return article;
	}

	public void setDescriptionIdentifier(String descriptionIdentifier)
	{
		this.descriptionIdentifier = descriptionIdentifier;
	}

	public String getDescriptionIdentifier()
	{
		return descriptionIdentifier;
	}

	public void setSection(String section)
	{
		this.section = section;
	}

	public String getSection()
	{
		return section;
	}

}
