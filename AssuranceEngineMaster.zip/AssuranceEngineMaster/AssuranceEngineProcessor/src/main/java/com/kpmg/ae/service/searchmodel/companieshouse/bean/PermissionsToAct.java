/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PermissionsToAct
{

	@JsonProperty("company_names")
	private List<String> companyNames;
	@JsonProperty("court_name")
	private String courtName;
	@JsonProperty("expires_on")
	private Date expiresOn;
	@JsonProperty("granted_on")
	private Date grantedOn;

	public void setCompanyNames(List<String> companyNames)
	{
		this.companyNames = companyNames;
	}

	public List<String> getCompanyNames()
	{
		return companyNames;
	}

	public void setCourtName(String courtName)
	{
		this.courtName = courtName;
	}

	public String getCourtName()
	{
		return courtName;
	}

	public void setExpiresOn(Date expiresOn)
	{
		this.expiresOn = expiresOn;
	}

	public Date getExpiresOn()
	{
		return expiresOn;
	}

	public void setGrantedOn(Date grantedOn)
	{
		this.grantedOn = grantedOn;
	}

	public Date getGrantedOn()
	{
		return grantedOn;
	}

}
