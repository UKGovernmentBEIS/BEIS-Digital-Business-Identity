/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.results;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kpmg.ae.service.searchmodel.thegazette.bean.Result;

public class PersonInsolvencyNoticeSearchResult
{
	private String format;
	private String version;

	@JsonProperty("ResultObject")
	Result resultObject;

	// Getter Methods

	public String getFormat()
	{
		return format;
	}

	public String getVersion()
	{
		return version;
	}

	public Result getResult()
	{
		return resultObject;
	}

	// Setter Methods

	public void setFormat(String format)
	{
		this.format = format;
	}

	public void setVersion(String version)
	{
		this.version = version;
	}

	public void setResult(Result resultObject)
	{
		this.resultObject = resultObject;
	}
}
