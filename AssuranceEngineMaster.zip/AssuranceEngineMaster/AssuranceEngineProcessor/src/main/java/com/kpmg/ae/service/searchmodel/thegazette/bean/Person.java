/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.thegazette.bean;

public class Person
{
	private String _about;
	private String type;
	private String familyName;
	private String firstName;
	private String name;
	HasAddress HasAddressObject;
	private String hasPersonDetails;

	// Getter Methods

	public String get_about()
	{
		return _about;
	}

	public String getType()
	{
		return type;
	}

	public String getFamilyName()
	{
		return familyName;
	}

	public String getFirstName()
	{
		return firstName;
	}

	public String getName()
	{
		return name;
	}

	public HasAddress getHasAddress()
	{
		return HasAddressObject;
	}

	public String getHasPersonDetails()
	{
		return hasPersonDetails;
	}

	// Setter Methods

	public void set_about(String _about)
	{
		this._about = _about;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public void setFamilyName(String familyName)
	{
		this.familyName = familyName;
	}

	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public void setHasAddress(HasAddress hasAddressObject)
	{
		this.HasAddressObject = hasAddressObject;
	}

	public void setHasPersonDetails(String hasPersonDetails)
	{
		this.hasPersonDetails = hasPersonDetails;
	}
}
