/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Links
{

	private String charges;
	@JsonProperty("filing_history")
	private String filingHistory;
	private String insolvency;
	private String officers;
	@JsonProperty("persons_with_significant_control")
	private String personsWithSignificantControl;
	@JsonProperty("persons_with_significant_control_statements")
	private String personsWithSignificantControlStatements;
	private String registers;
	private String self;
	private String exemptions;
	@JsonProperty("uk_establishments")
	private String ukEstablishments;
	private String overseas;

	public String getOverseas()
	{
		return overseas;
	}

	public void setOverseas(String overseas)
	{
		this.overseas = overseas;
	}

	public void setCharges(String charges)
	{
		this.charges = charges;
	}

	public String getCharges()
	{
		return charges;
	}

	public void setFilingHistory(String filingHistory)
	{
		this.filingHistory = filingHistory;
	}

	public String getFilingHistory()
	{
		return filingHistory;
	}

	public void setInsolvency(String insolvency)
	{
		this.insolvency = insolvency;
	}

	public String getInsolvency()
	{
		return insolvency;
	}

	public void setOfficers(String officers)
	{
		this.officers = officers;
	}

	public String getOfficers()
	{
		return officers;
	}

	public void setPersonsWithSignificantControl(String personsWithSignificantControl)
	{
		this.personsWithSignificantControl = personsWithSignificantControl;
	}

	public String getPersonsWithSignificantControl()
	{
		return personsWithSignificantControl;
	}

	public void setPersonsWithSignificantControlStatements(String personsWithSignificantControlStatements)
	{
		this.personsWithSignificantControlStatements = personsWithSignificantControlStatements;
	}

	public String getPersonsWithSignificantControlStatements()
	{
		return personsWithSignificantControlStatements;
	}

	public void setRegisters(String registers)
	{
		this.registers = registers;
	}

	public String getRegisters()
	{
		return registers;
	}

	public void setSelf(String self)
	{
		this.self = self;
	}

	public String getSelf()
	{
		return self;
	}

	public String getExemptions()
	{
		return exemptions;
	}

	public void setExemptions(String exemptions)
	{
		this.exemptions = exemptions;
	}

	public String getUkEstablishments()
	{
		return ukEstablishments;
	}

	public void setUkEstablishments(String ukEstablishments)
	{
		this.ukEstablishments = ukEstablishments;
	}
}
