/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.rs.intf;

import java.io.IOException;
import java.util.List;

import org.json.simple.parser.ParseException;

import com.kpmg.ae.service.bean.Company;
import com.kpmg.ae.service.bean.CompanyOfficer;
import com.kpmg.ae.service.bean.CompanyOwnerResponse;
import com.kpmg.ae.service.bean.PersonWithSignificantControl;

public interface CompaniesHouseService extends Service
{
	List<Company> searchCompaniesByName(String searchString) throws IOException, ParseException;

	List<CompanyOfficer> searchOfficersByCompanyNumber(String searchString) throws IOException;

	CompanyOwnerResponse isBusinessOwner(String companyNumber, String companyName, String firstname, String middlename,
			String surname, String postcode) throws IOException;

	List<PersonWithSignificantControl> getListOfPersonWithSignificantControl(String searchString) throws IOException;

	boolean isDisqualifiedOfficer(String firstname, String middlename, String lastname, String postCode, String companyName) throws IOException;
}
