/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import java.util.Arrays;

public class Matches
{
	int[] address_snippet;
	int[] snippet;
	int[] title;

	public int[] getAddress_snippet()
	{
		return address_snippet;
	}

	public void setAddress_snippet(int[] address_snippet)
	{
		this.address_snippet = address_snippet;
	}

	public int[] getSnippet()
	{
		return snippet;
	}

	public void setSnippet(int[] snippet)
	{
		this.snippet = snippet;
	}

	public int[] getTitle()
	{
		return title;
	}

	public void setTitle(int[] title)
	{
		this.title = title;
	}

	@Override
	public String toString()
	{
		return "Matches [address_snippet=" + Arrays.toString(address_snippet) + ", snippet=" + Arrays.toString(snippet)
				+ ", title=" + Arrays.toString(title) + "]";
	}
}
