/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.rs.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.Response;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpmg.ae.service.bean.Company;
import com.kpmg.ae.service.bean.MarketLocationBean;
import com.kpmg.ae.service.constants.AssuranceEngineConstants;
import com.kpmg.ae.service.rs.intf.MarketLocationService;
import com.kpmg.ae.service.searchmodel.marketlocation.bean.RecordBean;
import com.kpmg.ae.service.searchmodel.results.MarketLocationSearchResults;
import com.kpmg.ae.service.webservice.MarketLocationWebServiceProvider;

public class MarketLocationServiceImpl implements MarketLocationService
{

	MarketLocationWebServiceProvider mlWebServiceProvider;

	public MarketLocationServiceImpl() throws IOException
	{
		this.mlWebServiceProvider = new MarketLocationWebServiceProvider();
	}

	@Override
	public MarketLocationBean getMLDataForCompany(String companyName)
	{
		MarketLocationBean mlBean = null;
		Map<String, Object> queryParams = new HashMap<String, Object>();
		queryParams.put(AssuranceEngineConstants.MARKET_LOCATION_PARAM_BUSINESS_NAME, companyName);

		try
		{
			Response wsResponse = mlWebServiceProvider.callGet(mlWebServiceProvider.getResourcesProperties()
					.getProperty(AssuranceEngineConstants.MARKET_LOCATION_LOOKUP_URI), queryParams);
			if (wsResponse != null && wsResponse.getStatus() == 200)
			{
				String responseStr = wsResponse.readEntity(String.class);
				System.out.println(responseStr);
				JSONParser parser = new JSONParser();
				JSONObject responseJson = (JSONObject) parser.parse(responseStr);

				JSONObject summary = (JSONObject) responseJson
						.get(AssuranceEngineConstants.MARKET_LOCATION_JSON_SUMMARY);
				Long totalResults = (Long) summary.get(AssuranceEngineConstants.MARKET_LOCATION_JSON_TOTALRESULTS);
				System.out.println(totalResults);
				if (totalResults == 0 || totalResults > 1)
				{
					System.out
							.println("Either no record or more than one business matches the company name provided :: "
									+ companyName + " Null response will be returned.");
				}
				else
				{
					JSONArray records = (JSONArray) responseJson
							.get(AssuranceEngineConstants.MARKET_LOCATION_JSON_RECORDS);
					JSONObject companyDetails = (JSONObject) records.get(0);
					System.out.println(companyDetails.toString());
					mlBean = new MarketLocationBean();
					String businessName = (companyDetails
							.containsKey(AssuranceEngineConstants.MARKET_LOCATION_JSON_BUSINESSNAME)
							&& companyDetails.get(AssuranceEngineConstants.MARKET_LOCATION_JSON_BUSINESSNAME) != null)
									? (String) companyDetails
											.get(AssuranceEngineConstants.MARKET_LOCATION_JSON_BUSINESSNAME)
									: null;
					mlBean.setBusinessName(businessName);

					String noOfEmps = (companyDetails
							.containsKey(AssuranceEngineConstants.MARKET_LOCATION_JSON_EMPLOYEES)
							&& companyDetails.get(AssuranceEngineConstants.MARKET_LOCATION_JSON_EMPLOYEES) != null)
									? String.valueOf((long) companyDetails
											.get(AssuranceEngineConstants.MARKET_LOCATION_JSON_EMPLOYEES))
									: null;
					mlBean.setNoOfEmployees(noOfEmps);

					String recTurnover = (companyDetails
							.containsKey(AssuranceEngineConstants.MARKET_LOCATION_JSON_REC_TURNOVER)
							&& companyDetails.get(AssuranceEngineConstants.MARKET_LOCATION_JSON_REC_TURNOVER) != null)
									? String.valueOf((long) companyDetails
											.get(AssuranceEngineConstants.MARKET_LOCATION_JSON_REC_TURNOVER))
									: null;
					mlBean.setRecordedTurnover(recTurnover);

					String liabilities = (companyDetails
							.containsKey(AssuranceEngineConstants.MARKET_LOCATION_JSON_LIABILITIES)
							&& companyDetails.get(AssuranceEngineConstants.MARKET_LOCATION_JSON_LIABILITIES) != null)
									? (String) companyDetails
											.get(AssuranceEngineConstants.MARKET_LOCATION_JSON_LIABILITIES)
									: null;
					mlBean.setTotalLiabilities(liabilities);

					String networth = (companyDetails
							.containsKey(AssuranceEngineConstants.MARKET_LOCATION_JSON_NETWORTH)
							&& companyDetails.get(AssuranceEngineConstants.MARKET_LOCATION_JSON_NETWORTH) != null)
									? (String) companyDetails
											.get(AssuranceEngineConstants.MARKET_LOCATION_JSON_NETWORTH)
									: null;
					mlBean.setNetworth(networth);

					String email = (companyDetails.containsKey(AssuranceEngineConstants.MARKET_LOCATION_JSON_EMAIL)
							&& companyDetails.get(AssuranceEngineConstants.MARKET_LOCATION_JSON_EMAIL) != null)
									? (String) companyDetails.get(AssuranceEngineConstants.MARKET_LOCATION_JSON_EMAIL)
									: null;
					mlBean.setEmail(email);

					String modTurnover = companyDetails
							.containsKey(AssuranceEngineConstants.MARKET_LOCATION_JSON_MOD_TURNOVER)
									? String.valueOf((double) companyDetails
											.get(AssuranceEngineConstants.MARKET_LOCATION_JSON_MOD_TURNOVER))
									: null;
					mlBean.setModelledTurnover(modTurnover);

					String sicCode = (companyDetails.containsKey(AssuranceEngineConstants.MARKET_LOCATION_JSON_SIC)
							&& companyDetails.get(AssuranceEngineConstants.MARKET_LOCATION_JSON_SIC) != null)
									? (String) companyDetails.get(AssuranceEngineConstants.MARKET_LOCATION_JSON_SIC)
									: null;
					mlBean.setSicCode(sicCode);
				}
			}
		}
		catch (ParseException | IOException e)
		{
			e.printStackTrace();
		}
		return mlBean;
	}

	public MarketLocationBean getCompanyDetails(String companyName)
	{
		MarketLocationBean marketLocationBean = null;
		Map<String, Object> queryParams = new HashMap<String, Object>();
		queryParams.put(AssuranceEngineConstants.MARKET_LOCATION_PARAM_BUSINESS_NAME, companyName);

		try
		{
			Response wsResponse = mlWebServiceProvider.callGet(mlWebServiceProvider.getResourcesProperties()
					.getProperty(AssuranceEngineConstants.MARKET_LOCATION_LOOKUP_URI), queryParams);
			if (wsResponse != null && wsResponse.getStatus() == 200)
			{
				MarketLocationSearchResults result = new ObjectMapper().readValue(wsResponse.readEntity(String.class),
						MarketLocationSearchResults.class);
				for (RecordBean record : result.getRecords())
				{
					if (record.getBusinessName().equalsIgnoreCase(companyName))
					{
						marketLocationBean = new MarketLocationBean();
						marketLocationBean.setBusinessName(record.getBusinessName());
						marketLocationBean.setEmail(record.getEmail());
						marketLocationBean.setNoOfEmployees(Integer.toString(record.getEmployees_site()));
						marketLocationBean.setRecordedTurnover(Double.toString(record.getRecordedTurnover()));
					}
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return marketLocationBean;
	}

	@Override
	public void getAdditionalInfoFromMarketLocation(Company company)
	{
		Map<String, Object> queryParams = new HashMap<String, Object>();
		queryParams.put(AssuranceEngineConstants.MARKET_LOCATION_PARAM_BUSINESS_NAME, company.getCompanyName());

		try
		{
			Response wsResponse = mlWebServiceProvider.callGet(mlWebServiceProvider.getResourcesProperties()
					.getProperty(AssuranceEngineConstants.MARKET_LOCATION_LOOKUP_URI), queryParams);
			if (wsResponse != null && wsResponse.getStatus() == 200)
			{
				MarketLocationSearchResults result = new ObjectMapper().readValue(wsResponse.readEntity(String.class),
						MarketLocationSearchResults.class);
				for (RecordBean record : result.getRecords())
				{
					if (record.getBusinessName().equalsIgnoreCase(company.getCompanyName()))
					{

						company.setNoOfEmployees(record.getEmployees_site());
						company.setTurnover(record.getEstTurnover());
						break;
					}
				}

			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

	}
}
