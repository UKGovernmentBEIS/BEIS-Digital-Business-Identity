/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.webservice;

import java.io.IOException;
import java.io.InvalidObjectException;
import java.util.Arrays;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;

import com.kpmg.ae.service.constants.AssuranceEngineConstants;
import com.kpmg.ae.service.password.utils.PasswordUtils;

public class FSAWebServiceProvider extends AssuranceEngineWebServiceProvider
{

	private WebTarget fsaWebTarget;
	private HttpAuthenticationFeature authenticationFeature;
	private Client webClient;

	public FSAWebServiceProvider() throws IOException
	{
		super();
		setBasicAuthenticationFeature();
		registerWebClient();
	}

	private void setBasicAuthenticationFeature() throws IOException
	{
		char[] secrete = new PasswordUtils().getSecrete(AssuranceEngineConstants.PROPERTY_FSA_SECRETE_KEY);
		authenticationFeature = HttpAuthenticationFeature.basic(String.valueOf(secrete), "");
		Arrays.fill(secrete, Character.MIN_VALUE);	}

	private void registerWebClient() throws InvalidObjectException
	{
		this.webClient = getWebClient().register(authenticationFeature);
	}

	public void setWebTarget(String wsTargetURL) throws InvalidObjectException
	{
		String baseUrl = super.getResourcesProperties().getProperty(AssuranceEngineConstants.FSA_BASE_URL);
		UriBuilder uriBuilder = UriBuilder.fromPath(baseUrl + wsTargetURL);
		fsaWebTarget = this.webClient.target(uriBuilder);
	}

	public void setWebTarget(String wsTargetURL, String searchString) throws InvalidObjectException
	{
		String baseUrl = super.getResourcesProperties().getProperty(AssuranceEngineConstants.FSA_BASE_URL);
		UriBuilder uriBuilder = UriBuilder.fromPath(baseUrl + wsTargetURL);
		uriBuilder.queryParam("q", searchString);

		fsaWebTarget = this.webClient.target(uriBuilder);
	}

	public void setWebTarget(String wsTargetURL, Map<String, String> queryParams) throws InvalidObjectException
	{

		String baseUrl = super.getResourcesProperties().getProperty(AssuranceEngineConstants.FSA_BASE_URL);
		UriBuilder uriBuilder = UriBuilder.fromPath(baseUrl + wsTargetURL);

		for (Map.Entry<String, String> queryParam : queryParams.entrySet())
		{
			uriBuilder.queryParam(queryParam.getKey(), queryParam.getValue());
		}
		fsaWebTarget = this.webClient.target(uriBuilder);
	}

	@Override
	public WebTarget getWebTarget()
	{
		return fsaWebTarget;
	}
}
