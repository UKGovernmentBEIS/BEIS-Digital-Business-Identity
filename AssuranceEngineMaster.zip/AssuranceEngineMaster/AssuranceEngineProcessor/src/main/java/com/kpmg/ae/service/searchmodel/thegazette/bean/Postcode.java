
/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.thegazette.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Postcode
{
	@JsonProperty("_about")
	private String about;
	private String label;
	private double lat;
	@JsonProperty("long")
	private double longitude;
	@JsonProperty("Msg0_administrative_areaObject")
	Msg0AdministrativeArea msg0AdministrativeArea;

	// Getter Methods

	public String get_about()
	{
		return about;
	}

	public String getLabel()
	{
		return label;
	}

	public double getLat()
	{
		return lat;
	}

	public double getLong()
	{
		return longitude;
	}

	public Msg0AdministrativeArea getMsg0AdministrativeArea()
	{
		return msg0AdministrativeArea;
	}

	// Setter Methods

	public void set_about(String about)
	{
		this.about = about;
	}

	public void setLabel(String label)
	{
		this.label = label;
	}

	public void setLat(double lat)
	{
		this.lat = lat;
	}

	public void setLong(double longitude)
	{
		this.longitude = longitude;
	}

	public void setMsg0_administrative_area(Msg0AdministrativeArea msg0AdministrativeArea)
	{
		this.msg0AdministrativeArea = msg0AdministrativeArea;
	}
}
