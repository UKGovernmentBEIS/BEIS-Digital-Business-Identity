/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PersonWithSignificantControlBean
{

	@JsonProperty("address")
	AddressBean address;

	@JsonProperty("ceased_on")
	Date ceasedOn;

	@JsonProperty("country_of_residence")
	String countryOfResidence;

	@JsonProperty("date_of_birth")
	DateOfBirth dateOfBirth;

	@JsonProperty("etag")
	String etag;

	@JsonProperty("links")
	LinksBean links;

	@JsonProperty("name")
	String name;

	@JsonProperty("name_elements")
	NameElements nameElements;

	@JsonProperty("nationality")
	String nationality;

	@JsonProperty("notified_on")
	Date notifiedOn;

	@JsonProperty("natures_of_control")
	List<String> naturesOfControl;

	@JsonProperty("kind")
	String kind;

	@JsonProperty("identification")
	Identification identification;

	public AddressBean getAddress()
	{
		return address;
	}

	public void setAddress(AddressBean address)
	{
		this.address = address;
	}

	public Date getCeasedOn()
	{
		return ceasedOn;
	}

	public void setCeasedOn(Date ceasedOn)
	{
		this.ceasedOn = ceasedOn;
	}

	public String getCountryOfResidence()
	{
		return countryOfResidence;
	}

	public void setCountryOfResidence(String countryOfResidence)
	{
		this.countryOfResidence = countryOfResidence;
	}

	public DateOfBirth getDateOfBirth()
	{
		return dateOfBirth;
	}

	public void setDateOfBirth(DateOfBirth dateOfBirth)
	{
		this.dateOfBirth = dateOfBirth;
	}

	public String getEtag()
	{
		return etag;
	}

	public void setEtag(String etag)
	{
		this.etag = etag;
	}

	public LinksBean getLinks()
	{
		return links;
	}

	public void setLinks(LinksBean links)
	{
		this.links = links;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public NameElements getNameElements()
	{
		return nameElements;
	}

	public void setNameElements(NameElements nameElements)
	{
		this.nameElements = nameElements;
	}

	public String getNationality()
	{
		return nationality;
	}

	public void setNationality(String nationality)
	{
		this.nationality = nationality;
	}

	public List<String> getNaturesOfControl()
	{
		return naturesOfControl;
	}

	public void setNaturesOfControl(List<String> naturesOfControl)
	{
		this.naturesOfControl = naturesOfControl;
	}

	public Date getNotifiedOn()
	{
		return notifiedOn;
	}

	public void setNotifiedOn(Date notifiedOn)
	{
		this.notifiedOn = notifiedOn;
	}

	public String getKind()
	{
		return kind;
	}

	public void setKind(String kind)
	{
		this.kind = kind;
	}

	public Identification getIdentification()
	{
		return identification;
	}

	public void setIdentification(Identification identification)
	{
		this.identification = identification;
	}
}
