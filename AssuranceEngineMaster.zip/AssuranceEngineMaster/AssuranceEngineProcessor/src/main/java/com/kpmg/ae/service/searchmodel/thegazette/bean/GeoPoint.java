/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.thegazette.bean;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "geo:lat", "geo:long" })
public class GeoPoint
{

	@JsonProperty("geo:lat")
	private String geoLat;
	@JsonProperty("geo:long")
	private String geoLong;

	@JsonProperty("geo:lat")
	public String getGeoLat()
	{
		return geoLat;
	}

	@JsonProperty("geo:lat")
	public void setGeoLat(String geoLat)
	{
		this.geoLat = geoLat;
	}

	@JsonProperty("geo:long")
	public String getGeoLong()
	{
		return geoLong;
	}

	@JsonProperty("geo:long")
	public void setGeoLong(String geoLong)
	{
		this.geoLong = geoLong;
	}
}
