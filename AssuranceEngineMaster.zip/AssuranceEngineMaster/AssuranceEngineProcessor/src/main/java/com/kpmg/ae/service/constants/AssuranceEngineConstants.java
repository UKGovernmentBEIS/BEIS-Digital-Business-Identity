/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.constants;

public class AssuranceEngineConstants
{

	/**
	 * General constants
	 */
	public static final String COMPANY_ID = "companyId";
	public static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
	public static final String VERIFICATION_DATE_THRESHOLD = "verification.date.threshold";

	public static final String VERIFICATION_SOURCE_CH = "Companies House";
	public static final String VERIFICATION_SOURCE_MARKETLOCATION = "Market Location";

	/**
	 * JSON Constants
	 */
	public static final String VERIFIED_DATE = "verifiedDate";
	public static final String VERIFICATION_SOURCE = "verificationSource";
	public static final String VALUE = "value";

	public static final String COMPANIES_HOUSE_BASE_URL = "companieshouse.rs.ws.base.url";
	public static final String COMPANIES_HOUSE_SEARCH_BY_NAME = "companieshouse.rs.ws.search.companies.byName";
	public static final String COMPANIES_HOUSE_SEARCH_OFFICERS_BY_COMPANY_NUMBER = "companieshouse.rs.ws.search.officers.companyNumber";
	public static final String COMPANIES_HOUSE_SEARCH_PSC_BY_COMPANY_NUMBER = "companieshouse.rs.ws.search.psc.companyNumber";
	public static final String COMPANIES_HOUSE_COMPANY_NUMBER_URL_PATTERN = "{company_number}";
	public static final String COMPANIES_HOUSE_COMPANY_DIRECTOR = "director";
	public static final String COMPANIES_HOUSE_COMPANY_PROFILE_COMPANY_NUMBER = "companieshouse.rs.ws.company.profile.companyNumber";
	public static final String COMPANIES_HOUSE_DISQUALIFIED_OFFICER = "companieshouse.rs.ws.disqualified.officer";
	/**
	 * HMRC constants
	 */
	public static final String HMRC_BASE_URL = "hmrc.rs.ws.base.url";
	public static final String PROPERTY_HMRC_SECRETE_KEY = "companieshouse.rs.ws.api.key";// needs to be change in
																							// future

	/**
	 * D&B Constants
	 */
	public static final String DNB_BASE_URL = "dandb.rs.ws.base.url";
	public static final String PROPERTY_DNB_SECRETE_KEY = "companieshouse.rs.ws.api.key";// needs to be change in future

	/**
	 * Lloyds Banking constants
	 */
	public static final String LLOYDS_BASE_URL = "lloyds.rs.ws.base.url";
	public static final String PROPERTY_LLOYDS_SECRETE_KEY = "companieshouse.rs.ws.api.key";// needs to be change in
																							// future

	/**
	 * FSA constants
	 */
	public static final String FSA_BASE_URL = "fsa.rs.ws.base.url";
	public static final String PROPERTY_FSA_SECRETE_KEY = "companieshouse.rs.ws.api.key";// needs to be change in future

	/**
	 * THE GAZETTE constants
	 */
	public static final String THE_GAZETTE_BASE_URL = "thegazette.rs.ws.base.url";
	public static final String PROPERTY_THE_GAZETTE_SECRETE_KEY = "companieshouse.rs.ws.api.key";// needs to be change
																									// in future
	public static final String THE_GAZETTE_GET_ALL_NOTICES_BY_COMPANY_NAME = "thegazette.rs.ws.insolvency.notice.bycompanyname";
	public static final String THE_GAZETTE_GET_ALL_NOTICES_BY_COMPANY_NUMBER = "thegazette.rs.ws.insolvency.notice.bycrnnumber";
	public static final String THE_GAZETTE_GET_ALL_NOTICES = "thegazette.rs.ws.insolvency.notice";
	public static final String THE_GAZETTE_NOTICE_ID_LINK = "https://www.thegazette.co.uk/id/notice/";
	public static final String THE_GAZETTE_INSOLVENCY_NOTICE_RESULTS_PAGE = "thegazette.rs.ws.insolvency.notice.results.page";

	public static final String MARKET_LOCATION_BASE_URL = "marketlocation.rs.ws.base.url";
	public static final String MARKET_LOCATION_LOOKUP_URI = "marketlocation.rs.ws.lookup.uri";

	public static final String MARKET_LOCATION_PARAM_BUSINESS_NAME = "business_name";
	public static final String MARKET_LOCATION_PARAM_CLIENT_ID = "client_id";
	public static final String MARKET_LOCATION_JSON_SUMMARY = "summary";
	public static final String MARKET_LOCATION_JSON_TOTALRESULTS = "total_results_number";
	public static final String MARKET_LOCATION_JSON_RECORDS = "records";
	public static final String MARKET_LOCATION_JSON_BUSINESSNAME = "business_name";
	public static final String MARKET_LOCATION_JSON_NETWORTH = "networth";
	public static final String MARKET_LOCATION_JSON_EMAIL = "email";
	public static final String MARKET_LOCATION_JSON_EMPLOYEES = "employees_site";
	public static final String MARKET_LOCATION_JSON_REC_TURNOVER = "recorded_turnover";
	public static final String MARKET_LOCATION_JSON_MOD_TURNOVER = "est_turnover";
	public static final String MARKET_LOCATION_JSON_SIC = "sic_07";
	public static final String MARKET_LOCATION_JSON_LIABILITIES = "total_liabilities";
	public static final String SERVER_CONFIG_PROPERTY = "serverconfig.properties";
	public static final String PROPERTY_COMPANIES_HOUSE_API_KEY = "companieshouse.rs.ws.api.key";
	public static final String PROPERTY_MARKET_LOCATION_TOKEN = "marketlocation.rs.ws.token";
	public static final String PROPERTY_MARKET_LOCATION_CLIENT_ID = "marketlocation.rs.ws.client.id";
	
	public static final String PBE_WITH_HMACSHA512_AND_AES_256 = "PBEWithHMACSHA512AndAES_256";
	public static final String SERVERCONFIG_PROPERTIES = "serverconfig.properties";
	
	public static final String COMPANIES_HOUSE = "Companies House";
	public static final String D_B = "D&B";
	public static final String DUNN = "dunn";
	public static final String COMPANY_VAT = "companyVAT";
	public static final String COMPANY_PAYE = "companyPAYE";
	public static final String HMRC = "HMRC";
	public static final String COMPANY_UTR = "companyUTR";
	public static final String LLOYDS = "LLOYDS";
	public static final String ACCOUNT_NUMBER = "accountNumber";
	public static final String SORT_CODE = "sortCode";
	
	public static final String CLOSED = "closed";
	public static final String OPEN = "open";
	public static final String ADMINISTRATION = "administration";
	public static final String INSOLVENCY_PROCEEDINGS = "insolvency-proceedings";
	public static final String VOLUNTARY_ARRANGEMENT = "voluntary-arrangement";
	public static final String CONVERTED_CLOSED = "converted-closed";
	public static final String RECEIVERSHIP = "receivership";
	public static final String LIQUIDATION = "liquidation";
	public static final String DISSOLVED = "dissolved";
	public static final String ACTIVE = "active";
	public static final String SPACE = " ";
	public static final String REGEX_COMMA = ",";
	public static final String NATURAL = "natural";
	public static final String CONFIG_DNB_JSON = "/config/dnb.json";
	public static final String CONFIG_HMRCUK_JSON = "/config/hmrcuk.json";
	public static final String CONFIG_LLOYDSBANKING_JSON = "/config/lloydsbanking.json";

	public static final String LOCATION_DISTANCE_1 = "location-distance-1";
	public static final String LOCATION_POSTCODE_1 = "location-postcode-1";
	public static final String TEXT = "text";
	public static final String REGEX_COMMA_SPACE = ", ";
	public static final String SELF = "self";	
	public static final String RESOURCES_PROPERTIES = "resources.properties";
}
