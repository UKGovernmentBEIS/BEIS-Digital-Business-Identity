/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.thegazette.bean;

public class HasCourtCase
{
	private String _about;
	  private String type;
	  private String caseNumber;
	  private String caseYear;
	  HasCourt HasCourtObject;


	 // Getter Methods 

	  public String get_about() {
	    return _about;
	  }

	  public String getType() {
	    return type;
	  }

	  public String getCaseNumber() {
	    return caseNumber;
	  }

	  public String getCaseYear() {
	    return caseYear;
	  }

	  public HasCourt getHasCourt() {
	    return HasCourtObject;
	  }

	 // Setter Methods 

	  public void set_about( String _about ) {
	    this._about = _about;
	  }

	  public void setType( String type ) {
	    this.type = type;
	  }

	  public void setCaseNumber( String caseNumber ) {
	    this.caseNumber = caseNumber;
	  }

	  public void setCaseYear( String caseYear ) {
	    this.caseYear = caseYear;
	  }

	  public void setHasCourt( HasCourt hasCourtObject ) {
	    this.HasCourtObject = hasCourtObject;
	  }
}
