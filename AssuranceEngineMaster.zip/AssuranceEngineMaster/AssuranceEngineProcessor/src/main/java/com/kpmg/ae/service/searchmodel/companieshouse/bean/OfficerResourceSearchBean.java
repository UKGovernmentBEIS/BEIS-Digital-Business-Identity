/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OfficerResourceSearchBean
{

	@JsonProperty("address")
	AddressBean address;

	@JsonProperty("appointed_on")
	Date appointedOn;

	@JsonProperty("country_of_residence")
	String countryOfResidence;

	@JsonProperty("date_of_birth")
	DateOfBirth dateOfBirth;

	@JsonProperty("former_names")
	List<FormerNames> formerNames;

	@JsonProperty("links")
	OfficerLinksBean links;

	@JsonProperty("name")
	String name;

	@JsonProperty("nationality")
	String nationality;

	@JsonProperty("occupation")
	String occupation;

	@JsonProperty("officer_role")
	String officerRole;

	@JsonProperty("resigned_on")
	Date resignedOn;

	public AddressBean getAddress()
	{
		return address;
	}

	public void setAddress(AddressBean address)
	{
		this.address = address;
	}

	public Date getAppointedOn()
	{
		return appointedOn;
	}

	public void setAppointedOn(Date appointedOn)
	{
		this.appointedOn = appointedOn;
	}

	public String getCountryOfResidence()
	{
		return countryOfResidence;
	}

	public void setCountryOfResidence(String countryOfResidence)
	{
		this.countryOfResidence = countryOfResidence;
	}

	public DateOfBirth getDateOfBirth()
	{
		return dateOfBirth;
	}

	public void setDateOfBirth(DateOfBirth dateOfBirth)
	{
		this.dateOfBirth = dateOfBirth;
	}

	public List<FormerNames> getFormerNames()
	{
		return formerNames;
	}

	public void setFormerNames(List<FormerNames> formerNames)
	{
		this.formerNames = formerNames;
	}

	public OfficerLinksBean getLinks()
	{
		return links;
	}

	public void setLinks(OfficerLinksBean links)
	{
		this.links = links;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getNationality()
	{
		return nationality;
	}

	public void setNationality(String nationality)
	{
		this.nationality = nationality;
	}

	public String getOccupation()
	{
		return occupation;
	}

	public void setOccupation(String occupation)
	{
		this.occupation = occupation;
	}

	public String getOfficerRole()
	{
		return officerRole;
	}

	public void setOfficerRole(String officerRole)
	{
		this.officerRole = officerRole;
	}

	public Date getResignedOn()
	{
		return resignedOn;
	}

	public void setResignedOn(Date resignedOn)
	{
		this.resignedOn = resignedOn;
	}

	@Override
	public String toString()
	{
		return "OfficerResourceSearchBean [address=" + address + ", appointedOn=" + appointedOn
				+ ", countryOfResidence=" + countryOfResidence + ", dateOfBirth=" + dateOfBirth + ", links=" + links
				+ ", name=" + name + ", nationality=" + nationality + ", occupation=" + occupation + ", officerRole="
				+ officerRole + ", resignedOn=" + resignedOn.getTime() + "]";
	}

}

class FormerNames
{

	@JsonProperty("forenames")
	String forenames;

	@JsonProperty("surname")
	String surname;

	public String getForenames()
	{
		return forenames;
	}

	public void setForenames(String forenames)
	{
		this.forenames = forenames;
	}

	public String getSurname()
	{
		return surname;
	}

	public void setSurname(String surname)
	{
		this.surname = surname;
	}
}
