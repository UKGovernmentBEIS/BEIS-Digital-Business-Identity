/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.bean;

import java.util.Date;

public class CompanyOfficer
{

	Date appointedOn;
	String officerId;
	String name;
	String occupation;
	String officerRole;
	Date resignedOn;

	public Date getAppointedOn()
	{
		return appointedOn;
	}

	public void setAppointedOn(Date appointedOn)
	{
		this.appointedOn = appointedOn;
	}

	public String getOfficerId()
	{
		return officerId;
	}

	public void setOfficerId(String officerId)
	{
		this.officerId = officerId;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getOccupation()
	{
		return occupation;
	}

	public void setOccupation(String occupation)
	{
		this.occupation = occupation;
	}

	public String getOfficerRole()
	{
		return officerRole;
	}

	public void setOfficerRole(String officerRole)
	{
		this.officerRole = officerRole;
	}

	public Date getResignedOn()
	{
		return resignedOn;
	}

	public void setResignedOn(Date resignedOn)
	{
		this.resignedOn = resignedOn;
	}

}
