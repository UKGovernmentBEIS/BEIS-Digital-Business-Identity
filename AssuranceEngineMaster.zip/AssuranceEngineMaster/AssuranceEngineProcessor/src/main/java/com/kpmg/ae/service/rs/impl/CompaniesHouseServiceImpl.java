/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.rs.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.Response;

import org.json.simple.parser.ParseException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpmg.ae.service.bean.Company;
import com.kpmg.ae.service.bean.CompanyOfficer;
import com.kpmg.ae.service.bean.CompanyOwnerResponse;
import com.kpmg.ae.service.bean.PersonWithSignificantControl;
import com.kpmg.ae.service.constants.AssuranceEngineConstants;
import com.kpmg.ae.service.rs.intf.CompaniesHouseService;
import com.kpmg.ae.service.searchmodel.companieshouse.bean.CompanySearchBean;
import com.kpmg.ae.service.searchmodel.companieshouse.bean.Disqualifications;
import com.kpmg.ae.service.searchmodel.companieshouse.bean.DisqualifiedOfficerSearchBean;
import com.kpmg.ae.service.searchmodel.companieshouse.bean.NaturalDisqualifiedOfficer;
import com.kpmg.ae.service.searchmodel.companieshouse.bean.OfficerResourceSearchBean;
import com.kpmg.ae.service.searchmodel.companieshouse.bean.PersonWithSignificantControlBean;
import com.kpmg.ae.service.searchmodel.results.CompanyProfileResult;
import com.kpmg.ae.service.searchmodel.results.CompanySearchResult;
import com.kpmg.ae.service.searchmodel.results.DisqualifiedOfficerSearchResult;
import com.kpmg.ae.service.searchmodel.results.OfficerResourceSearchResult;
import com.kpmg.ae.service.searchmodel.results.PersonWithSignificantControlSerachResult;
import com.kpmg.ae.service.utilities.AssuranceEngineUtility;
import com.kpmg.ae.service.webservice.CompaniesHouseWebServiceProvider;

public class CompaniesHouseServiceImpl implements CompaniesHouseService
{
	CompaniesHouseWebServiceProvider webServiceProvider;

	public CompaniesHouseServiceImpl() throws IOException
	{
		webServiceProvider = new CompaniesHouseWebServiceProvider();
	}

	/**
	 * @purpose Returns list of companies matching with company name
	 * @since January 14, 2020
	 * @param searchString
	 *            (Name of company)
	 * @return List<Company>
	 * @throws IOException
	 */
	public List<Company> searchCompaniesByName(String searchString) throws IOException, ParseException
	{
		List<Company> listOfCompanies = new ArrayList<Company>();

		String companiesHouseWSTargetURL = webServiceProvider.getResourcesProperties()
				.getProperty(AssuranceEngineConstants.COMPANIES_HOUSE_SEARCH_BY_NAME);

		webServiceProvider.setWebTarget(companiesHouseWSTargetURL, searchString);

		Response restResponse = webServiceProvider.getWebTarget().request().get();

		if (restResponse.getStatus() == 200)
		{

			CompanySearchResult companySearch;
			try
			{
				companySearch = new ObjectMapper().readValue(restResponse.readEntity(String.class),
						CompanySearchResult.class);
				
				for (CompanySearchBean companySearchBean : companySearch.getItems())
				{
					Company company = new Company();

					if (!AssuranceEngineUtility.isNullOrEmptyString(companySearchBean.getTitle()))
					{
						company.setCompanyName(companySearchBean.getTitle());

						company.setChCompanyId(companySearchBean.getCompanyNumber());
						company.setChCompanyLink(companySearchBean.getLinks().getSelf());
						if (null != companySearchBean.getAddress())
						{
							if (!AssuranceEngineUtility
									.isNullOrEmptyString(companySearchBean.getAddress().getPremises()))
							{
								company.setPremise(companySearchBean.getAddress().getPremises());
							}

							if (!AssuranceEngineUtility
									.isNullOrEmptyString(companySearchBean.getAddress().getLocality()))
							{
								company.setLocality(companySearchBean.getAddress().getLocality());
							}

							if (!AssuranceEngineUtility
									.isNullOrEmptyString(companySearchBean.getAddress().getAddressLine1()))
							{
								company.setAddressLine1(companySearchBean.getAddress().getAddressLine1());
							}

							if (!AssuranceEngineUtility
									.isNullOrEmptyString(companySearchBean.getAddress().getAddressLine2()))
							{
								company.setAddressLine2(companySearchBean.getAddress().getAddressLine2());
							}

							if (!AssuranceEngineUtility
									.isNullOrEmptyString(companySearchBean.getAddress().getPostalCode()))
							{
								company.setPostCode(companySearchBean.getAddress().getPostalCode());
							}
						}
						List<PersonWithSignificantControl> personWithSignificantControlList = getListOfPersonWithSignificantControl(
								companySearchBean.getCompanyNumber());
						company.setPersonWithSignificantControl(personWithSignificantControlList);
						getCompanyProfileByCompanyNumber(company);						
						listOfCompanies.add(company);
					}
				}
			}
			catch (IOException e)
			{
				throw e;
			}

		}
		return listOfCompanies;
	}

	/**
	 * @purpose search business officers matching with company number
	 * @since January 25, 2020
	 * @param searchString
	 * @return List<CompanyOfficer>
	 * @throws IOException
	 */
	public List<CompanyOfficer> searchOfficersByCompanyNumber(String searchString) throws IOException
	{

		List<CompanyOfficer> listOfCompanyOfficers = new ArrayList<CompanyOfficer>();

		String companiesHouseWSTargetURL = webServiceProvider.getResourcesProperties()
				.getProperty(AssuranceEngineConstants.COMPANIES_HOUSE_SEARCH_OFFICERS_BY_COMPANY_NUMBER)
				.replace(AssuranceEngineConstants.COMPANIES_HOUSE_COMPANY_NUMBER_URL_PATTERN, searchString);

		webServiceProvider.setWebTarget(companiesHouseWSTargetURL);

		Response restResponse = webServiceProvider.getWebTarget().request().get();

		OfficerResourceSearchResult officerSearchResult;
		if (restResponse.getStatus() == 200)
		{
			try
			{
				officerSearchResult = new ObjectMapper().readValue(restResponse.readEntity(String.class),
						OfficerResourceSearchResult.class);
				for (OfficerResourceSearchBean officerResource : officerSearchResult.getItems())
				{
					CompanyOfficer officer = new CompanyOfficer();
					officer.setName(officerResource.getName());
					String officerIdStr = officerResource.getLinks().getOfficer().getAppointments().split("/")[2];
					officer.setOfficerId(officerIdStr);
					officer.setOfficerRole(officerResource.getOfficerRole());
					officer.setAppointedOn(officerResource.getAppointedOn());
					officer.setResignedOn(officerResource.getResignedOn());
					officer.setOccupation(officerResource.getOccupation());
					listOfCompanyOfficers.add(officer);
				}
			}
			catch (IOException e)
			{
				e.printStackTrace();
				throw e;
			}
		}
		return listOfCompanyOfficers;
	}

	/**
	 * @purpose checks is user with matching user name is owner of business
	 * @since January 15, 2020
	 * @param companyNumber
	 * @param name
	 * @return boolean result
	 * @throws IOException
	 */
	public CompanyOwnerResponse isBusinessOwner(String companyNumber, String companyName, String firstname, String middlename, String surname, String postcode) throws IOException
	{
		String companiesHouseWSTargetURL = webServiceProvider.getResourcesProperties()
				.getProperty(AssuranceEngineConstants.COMPANIES_HOUSE_SEARCH_OFFICERS_BY_COMPANY_NUMBER)
				.replace(AssuranceEngineConstants.COMPANIES_HOUSE_COMPANY_NUMBER_URL_PATTERN, companyNumber);

		webServiceProvider.setWebTarget(companiesHouseWSTargetURL);

		Response restResponse = webServiceProvider.getWebTarget().request().get();
		CompanyOwnerResponse ownerResponseResult = new CompanyOwnerResponse();
		
		OfficerResourceSearchResult officerSearchResult;
		if (restResponse.getStatus() == 200)
		{
			try
			{
				officerSearchResult = new ObjectMapper().readValue(restResponse.readEntity(String.class),
						OfficerResourceSearchResult.class);

				for (OfficerResourceSearchBean officerResource : officerSearchResult.getItems())
				{
					if (officerResource.getOfficerRole()
							.equalsIgnoreCase(AssuranceEngineConstants.COMPANIES_HOUSE_COMPANY_DIRECTOR))
					{
						String[] officerName = officerResource.getName().split(AssuranceEngineConstants.REGEX_COMMA);
						String officerFirstName = officerName[1].trim();
						if (surname.equalsIgnoreCase(officerName[0]))
						{
							if (firstname.equalsIgnoreCase(officerFirstName))
							{
								ownerResponseResult.setOwner(true);
								break;
							}
							else if (officerFirstName.toLowerCase().contains(firstname.toLowerCase()))
							{
								ownerResponseResult.setOwner(true);
								break;
							}
						}
					}
				}
				if(ownerResponseResult.isOwner()) 
				{
					ownerResponseResult.setNaturalDisqualified(isDisqualifiedOfficer(firstname, middlename, surname, postcode, companyName));
				}
			}
			catch (IOException e)
			{
				throw e;
			}
		}
		return ownerResponseResult;
	}

	/**
	 * @purpose returns list of persons with significant control in business matching with company number
	 * @since January 20, 2020
	 * @param companyNumber
	 * @return List<PersonWithSignificantControl>
	 * @throws IOException
	 */
	public List<PersonWithSignificantControl> getListOfPersonWithSignificantControl(String companyNumber)
			throws IOException
	{

		List<PersonWithSignificantControl> listOfPSC = new ArrayList<PersonWithSignificantControl>();
		String companiesHouseWSTargetURL = webServiceProvider.getResourcesProperties()
				.getProperty(AssuranceEngineConstants.COMPANIES_HOUSE_SEARCH_PSC_BY_COMPANY_NUMBER)
				.replace(AssuranceEngineConstants.COMPANIES_HOUSE_COMPANY_NUMBER_URL_PATTERN, companyNumber);

		webServiceProvider.setWebTarget(companiesHouseWSTargetURL);

		Response restResponse = webServiceProvider.getWebTarget().request().get();

		PersonWithSignificantControlSerachResult pscSearchResult;
		if (restResponse.getStatus() == 200)
		{

			try
			{
				pscSearchResult = new ObjectMapper().readValue(restResponse.readEntity(String.class),
						PersonWithSignificantControlSerachResult.class);
				for (PersonWithSignificantControlBean pscBean : pscSearchResult.getItems())
				{
					PersonWithSignificantControl psc = new PersonWithSignificantControl();

					psc.setName(pscBean.getName());

					if (null != pscBean.getNameElements())
					{

						if (null != pscBean.getNameElements().getForename())
						{
							psc.setForename(pscBean.getNameElements().getForename());
						}

						if (null != pscBean.getNameElements().getSurname())
						{
							psc.setSurname(pscBean.getNameElements().getSurname());
						}

						if (null != pscBean.getNameElements().getTitle())
						{
							psc.setTitle(pscBean.getNameElements().getTitle());
						}
					}

					String pscIdString = pscBean.getLinks().getSelf();
					/*
					 * remove '/company/{company_number}/persons-with-significant-control/individual/' from pscID
					 */
					String strToRemove = "/company/" + companyNumber + "/persons-with-significant-control/individual/";
					pscIdString = pscIdString.replaceAll(strToRemove, "");
					psc.setPscID(pscIdString);
					listOfPSC.add(psc);
				}
			}
			catch (IOException e)
			{
				e.printStackTrace();
				throw e;
			}
		}
		return listOfPSC;
	}

	/**
	 * @purpose Update company profile from companies house
	 * @since January 23, 2020
	 * @param company
	 * @throws IOException
	 */
	private void getCompanyProfileByCompanyNumber(Company company) throws IOException
	{

		String companiesHouseWSTargetURL = webServiceProvider.getResourcesProperties()
				.getProperty(AssuranceEngineConstants.COMPANIES_HOUSE_COMPANY_PROFILE_COMPANY_NUMBER)
				.replace(AssuranceEngineConstants.COMPANIES_HOUSE_COMPANY_NUMBER_URL_PATTERN, company.getChCompanyId());

		webServiceProvider.setWebTarget(companiesHouseWSTargetURL);

		Response restResponse = webServiceProvider.getWebTarget().request().get();

		CompanyProfileResult companyProfileSearchResult;
		if (restResponse.getStatus() == 200)
		{
			try
			{
				companyProfileSearchResult = new ObjectMapper().readValue(restResponse.readEntity(String.class),
						CompanyProfileResult.class);
				company.setHasCharges(Boolean.parseBoolean(companyProfileSearchResult.getHasCharges()));

				company.setRegisteredOfficeIsInDispute(
						Boolean.parseBoolean(companyProfileSearchResult.getRegisteredOfficeIsInDispute()));

				if (!AssuranceEngineUtility.isNullOrEmptyString(companyProfileSearchResult.getType()))
				{
					company.setCompanyType(companyProfileSearchResult.getType());
				}

				if (!AssuranceEngineUtility.isNullOrEmptyString(companyProfileSearchResult.getCompanyStatus()))
				{
					company.setCompanyStatus(companyProfileSearchResult.getCompanyStatus().toUpperCase());
				}

				if (null != companyProfileSearchResult.getSicCodes())
				{
					company.setSicCodes(companyProfileSearchResult.getSicCodes());
				}

			}
			catch (IOException e)
			{
				e.printStackTrace();
				throw e;
			}
		}
	}

	/**
	 * @purpose Check if owner is disqualified
	 * @since January 23, 2020
	 * @param company
	 * @throws IOException
	 */
	public boolean isDisqualifiedOfficer(String firstname, String middlename, String lastname, String postCode, String companyName) throws IOException
	{

		String companiesHouseWSTargetURL = webServiceProvider.getResourcesProperties()
				.getProperty(AssuranceEngineConstants.COMPANIES_HOUSE_DISQUALIFIED_OFFICER);
		String officerNameToSearch = "";
		if (AssuranceEngineUtility.isNullOrEmptyString(middlename))
		{
			officerNameToSearch = firstname + AssuranceEngineConstants.SPACE + lastname;
		}
		else
		{
			officerNameToSearch = firstname + AssuranceEngineConstants.SPACE + middlename + AssuranceEngineConstants.SPACE + lastname;
		}
		webServiceProvider.setWebTarget(companiesHouseWSTargetURL, officerNameToSearch);

		Response restResponse = webServiceProvider.getWebTarget().request().get();

		DisqualifiedOfficerSearchResult disqualifiedOfficerSearchResult;
		if (restResponse.getStatus() == 200)
		{
			try
			{
				String officerLink = "";
				disqualifiedOfficerSearchResult = new ObjectMapper().readValue(restResponse.readEntity(String.class),
						DisqualifiedOfficerSearchResult.class);

				for (DisqualifiedOfficerSearchBean disqualifiedOfficerBean : disqualifiedOfficerSearchResult.getItems())
				{
					if (disqualifiedOfficerBean.getTitle().equalsIgnoreCase(officerNameToSearch))
					{
						officerLink = disqualifiedOfficerBean.getLinks().getSelf();
						break;
					}
					else if (disqualifiedOfficerBean.getTitle().toLowerCase().contains(officerNameToSearch.toLowerCase())
							&& (disqualifiedOfficerBean.getAddress().getPostalCode().replace(AssuranceEngineConstants.SPACE, ""))
									.equalsIgnoreCase(postCode.replace(AssuranceEngineConstants.SPACE, "")))
					{
						officerLink = disqualifiedOfficerBean.getLinks().getSelf();
						break;
					}
				}
				if (!AssuranceEngineUtility.isNullOrEmptyString(officerLink))
				{
					return isUserDisqualifiedForCompany(officerLink, firstname, lastname, companyName);
				}

			}
			catch (IOException e)
			{
				e.printStackTrace();
				throw e;
			}
		}

		return false;
	}

	private boolean isUserDisqualifiedForCompany(String officerLink, String firstname, String lastname,
			String companyName) throws IOException
	{

		try
		{
			webServiceProvider.setWebTarget(officerLink);
			Response restResponse = webServiceProvider.getWebTarget().request().get();

			if (restResponse.getStatus() == 200)
			{
				if (officerLink.contains(AssuranceEngineConstants.NATURAL))
				{
					NaturalDisqualifiedOfficer disqualifiedOfficerSearchResult = new ObjectMapper()
							.readValue(restResponse.readEntity(String.class), NaturalDisqualifiedOfficer.class);
					if (firstname.equalsIgnoreCase(disqualifiedOfficerSearchResult.getForename())
							&& lastname.equalsIgnoreCase(disqualifiedOfficerSearchResult.getSurname()))
					{
						for (Disqualifications disqualification : disqualifiedOfficerSearchResult
								.getDisqualifications())
						{
							for (String disqualifiedFromCompany : disqualification.getCompanyNames())
							{
								if (companyName.equalsIgnoreCase(disqualifiedFromCompany))
								{
									return true;
								}
							}
						}
					}
				}
				else
				{
					//check to add corporate disqualification
					
					/*
					 * CorporateDisqualifiedOfficer disqualifiedOfficerSearchResult = new ObjectMapper()
					 * .readValue(restResponse.readEntity(String.class), CorporateDisqualifiedOfficer.class);
					 */

				}

			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
			throw e;
		}

		return false;
	}
}
