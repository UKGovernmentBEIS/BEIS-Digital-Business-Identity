/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.rs.intf;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.kpmg.ae.service.bean.InsolvencyNotice;
import com.kpmg.ae.service.bean.PersonWithInsolvencyNoticeResponse;

public interface TheGazetteService extends Service
{
	List<InsolvencyNotice> getInsolvencyNoticesByCompanyNumber(String companyNumber, String companyName)
			throws JsonParseException, JsonMappingException, IOException;

	List<InsolvencyNotice> getInsolvencyNoticesByCompanyName(String companyName)
			throws JsonParseException, JsonMappingException, IOException;

	PersonWithInsolvencyNoticeResponse getInsolvencyNoticesOfUser(String firstName, String lastName, String middleName,
			String postCode) throws JsonParseException, JsonMappingException, IOException;
}
