/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.results;

import java.util.List;

import com.kpmg.ae.service.searchmodel.companieshouse.bean.CompanySearchBean;

public class CompanySearchResult
{
	int items_per_page;
	String kind;
	int start_index;
	int total_results;
	List<CompanySearchBean> items;
	int page_number;

	public String getKind()
	{
		return kind;
	}

	public void setKind(String kind)
	{
		this.kind = kind;
	}

	public int getItems_per_page()
	{
		return items_per_page;
	}

	public void setItems_per_page(int items_per_page)
	{
		this.items_per_page = items_per_page;
	}

	public int getStart_index()
	{
		return start_index;
	}

	public void setStart_index(int start_index)
	{
		this.start_index = start_index;
	}

	public int getTotal_results()
	{
		return total_results;
	}

	public void setTotal_results(int total_results)
	{
		this.total_results = total_results;
	}

	public List<CompanySearchBean> getItems()
	{
		return items;
	}

	public void setItems(List<CompanySearchBean> items)
	{
		this.items = items;
	}

	public int getPage_number()
	{
		return page_number;
	}

	public void setPage_number(int page_number)
	{
		this.page_number = page_number;
	}

}
