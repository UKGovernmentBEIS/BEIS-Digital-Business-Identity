/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ForeignCompanyDetails
{

	@JsonProperty("accounting_requirement")
	private AccountingRequirement accountingRequirement;
	private Accounts accounts;
	@JsonProperty("business_activity")
	private String businessActivity;
	@JsonProperty("company_type")
	private String companyType;
	@JsonProperty("governed_by")
	private String governedBy;
	@JsonProperty("is_a_credit_finance_institution")
	private String isACreditFinanceInstitution;
	@JsonProperty("originating_registry")
	private OriginatingRegistry originatingRegistry;
	@JsonProperty("registration_number")
	private String registrationNumber;
	@JsonProperty("legal_form")
	private String legalForm;
	@JsonProperty("is_a_credit_financial_institution")
	private String isCreditFinancialInstitution;

	public void setAccountingRequirement(AccountingRequirement accountingRequirement)
	{
		this.accountingRequirement = accountingRequirement;
	}

	public AccountingRequirement getAccountingRequirement()
	{
		return accountingRequirement;
	}

	public void setAccounts(Accounts accounts)
	{
		this.accounts = accounts;
	}

	public Accounts getAccounts()
	{
		return accounts;
	}

	public void setBusinessActivity(String businessActivity)
	{
		this.businessActivity = businessActivity;
	}

	public String getBusinessActivity()
	{
		return businessActivity;
	}

	public void setCompanyType(String companyType)
	{
		this.companyType = companyType;
	}

	public String getCompanyType()
	{
		return companyType;
	}

	public void setGovernedBy(String governedBy)
	{
		this.governedBy = governedBy;
	}

	public String getGovernedBy()
	{
		return governedBy;
	}

	public void setIsACreditFinanceInstitution(String isACreditFinanceInstitution)
	{
		this.isACreditFinanceInstitution = isACreditFinanceInstitution;
	}

	public String getIsACreditFinanceInstitution()
	{
		return isACreditFinanceInstitution;
	}

	public void setOriginatingRegistry(OriginatingRegistry originatingRegistry)
	{
		this.originatingRegistry = originatingRegistry;
	}

	public OriginatingRegistry getOriginatingRegistry()
	{
		return originatingRegistry;
	}

	public void setRegistrationNumber(String registrationNumber)
	{
		this.registrationNumber = registrationNumber;
	}

	public String getRegistrationNumber()
	{
		return registrationNumber;
	}

	public String getLegalForm()
	{
		return legalForm;
	}

	public void setLegalForm(String legalForm)
	{
		this.legalForm = legalForm;
	}

	public String getIsCreditFinancialInstitution()
	{
		return isCreditFinancialInstitution;
	}

	public void setIsCreditFinancialInstitution(String isCreditFinancialInstitution)
	{
		this.isCreditFinancialInstitution = isCreditFinancialInstitution;
	}

}
