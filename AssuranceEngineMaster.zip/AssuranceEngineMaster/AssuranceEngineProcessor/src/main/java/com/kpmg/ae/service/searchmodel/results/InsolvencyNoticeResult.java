/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.results;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.kpmg.ae.service.searchmodel.thegazette.bean.Entry;
import com.kpmg.ae.service.searchmodel.thegazette.bean.Link;
import com.kpmg.ae.service.searchmodel.thegazette.bean.OpenSearchQuery;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "id", "link", "title", "updated", "openSearch:Query", "f:page-number", "f:page-size",
		"f:page-start", "f:page-stop", "f:total", "f:total-errors", "f:facets", "entry" })
public class InsolvencyNoticeResult
{

	@JsonProperty("id")
	private String id;
	@JsonProperty("link")
	private List<Link> link = null;
	@JsonProperty("title")
	private String title;
	@JsonProperty("updated")
	private String updated;
	@JsonProperty("openSearch:Query")
	private OpenSearchQuery openSearchQuery;
	@JsonProperty("f:page-number")
	private String fPageNumber;
	@JsonProperty("f:page-size")
	private String fPageSize;
	@JsonProperty("f:page-start")
	private String fPageStart;
	@JsonProperty("f:page-stop")
	private String fPageStop;
	@JsonProperty("f:total")
	private String fTotal;
	@JsonProperty("f:total-errors")
	private String fTotalErrors;
	@JsonProperty("f:facets")
	private Object fFacets;
	@JsonProperty("entry")
	private List<Entry> entry = null;

	@JsonProperty("id")
	public String getId()
	{
		return id;
	}

	@JsonProperty("id")
	public void setId(String id)
	{
		this.id = id;
	}

	@JsonProperty("link")
	public List<Link> getLink()
	{
		return link;
	}

	@JsonProperty("link")
	public void setLink(List<Link> link)
	{
		this.link = link;
	}

	@JsonProperty("title")
	public String getTitle()
	{
		return title;
	}

	@JsonProperty("title")
	public void setTitle(String title)
	{
		this.title = title;
	}

	@JsonProperty("updated")
	public String getUpdated()
	{
		return updated;
	}

	@JsonProperty("updated")
	public void setUpdated(String updated)
	{
		this.updated = updated;
	}

	@JsonProperty("openSearch:Query")
	public OpenSearchQuery getOpenSearchQuery()
	{
		return openSearchQuery;
	}

	@JsonProperty("openSearch:Query")
	public void setOpenSearchQuery(OpenSearchQuery openSearchQuery)
	{
		this.openSearchQuery = openSearchQuery;
	}

	@JsonProperty("f:page-number")
	public String getFPageNumber()
	{
		return fPageNumber;
	}

	@JsonProperty("f:page-number")
	public void setFPageNumber(String fPageNumber)
	{
		this.fPageNumber = fPageNumber;
	}

	@JsonProperty("f:page-size")
	public String getFPageSize()
	{
		return fPageSize;
	}

	@JsonProperty("f:page-size")
	public void setFPageSize(String fPageSize)
	{
		this.fPageSize = fPageSize;
	}

	@JsonProperty("f:page-start")
	public String getFPageStart()
	{
		return fPageStart;
	}

	@JsonProperty("f:page-start")
	public void setFPageStart(String fPageStart)
	{
		this.fPageStart = fPageStart;
	}

	@JsonProperty("f:page-stop")
	public String getFPageStop()
	{
		return fPageStop;
	}

	@JsonProperty("f:page-stop")
	public void setFPageStop(String fPageStop)
	{
		this.fPageStop = fPageStop;
	}

	@JsonProperty("f:total")
	public String getFTotal()
	{
		return fTotal;
	}

	@JsonProperty("f:total")
	public void setFTotal(String fTotal)
	{
		this.fTotal = fTotal;
	}

	@JsonProperty("f:total-errors")
	public String getFTotalErrors()
	{
		return fTotalErrors;
	}

	@JsonProperty("f:total-errors")
	public void setFTotalErrors(String fTotalErrors)
	{
		this.fTotalErrors = fTotalErrors;
	}

	@JsonProperty("f:facets")
	public Object getFFacets()
	{
		return fFacets;
	}

	@JsonProperty("f:facets")
	public void setFFacets(Object fFacets)
	{
		this.fFacets = fFacets;
	}

	@JsonProperty("entry")
	public List<Entry> getEntry()
	{
		return entry;
	}

	@JsonProperty("entry")
	public void setEntry(List<Entry> entry)
	{
		this.entry = entry;
	}
}
