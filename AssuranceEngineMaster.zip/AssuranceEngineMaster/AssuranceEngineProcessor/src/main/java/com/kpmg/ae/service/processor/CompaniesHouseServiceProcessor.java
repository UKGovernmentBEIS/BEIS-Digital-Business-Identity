/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.processor;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.json.simple.parser.ParseException;

import com.kpmg.ae.service.bean.Business;
import com.kpmg.ae.service.bean.BusinessAddress;
import com.kpmg.ae.service.bean.BusinessCRN;
import com.kpmg.ae.service.bean.BusinessName;
import com.kpmg.ae.service.bean.BusinessPSC;
import com.kpmg.ae.service.bean.BusinessPostCode;
import com.kpmg.ae.service.bean.BusinessSIC;
import com.kpmg.ae.service.bean.ChBusinessId;
import com.kpmg.ae.service.bean.Company;
import com.kpmg.ae.service.bean.CompanyOfficer;
import com.kpmg.ae.service.bean.CompanyOwnerResponse;
import com.kpmg.ae.service.bean.PersonWithSignificantControl;
import com.kpmg.ae.service.constants.AssuranceEngineConstants;
import com.kpmg.ae.service.factory.AssuranceEngineServiceFactory;
import com.kpmg.ae.service.rs.intf.CompaniesHouseService;

public class CompaniesHouseServiceProcessor
{
	CompaniesHouseService companiesHouseService;

	public CompaniesHouseServiceProcessor()
	{
		companiesHouseService = (CompaniesHouseService) AssuranceEngineServiceFactory
				.getService(CompaniesHouseService.class);
	}

	/**
	 * @purpose search companies matching with company name 
	 * @since January 07, 2020 
	 * @param searchString 
	 * @return List<Company> 
	 * @throws IOException 
	 * @throws ParseException
	 */
	public List<Company> searchCompaniesByName(String searchString) throws IOException, ParseException
	{
		List<Company> listOfCompanies = companiesHouseService.searchCompaniesByName(searchString);
		return listOfCompanies;
	}

	/**
	 * @purpose Search company officers by company number 
	 * @since January 08, 2020 
	 * @param searchString 
	 * @return List<CompanyOfficer>
	 * @throws IOException
	 */
	public List<CompanyOfficer> searchOfficersByCompanyNumber(String searchString) throws IOException
	{
		List<CompanyOfficer> listOfOfficers = companiesHouseService.searchOfficersByCompanyNumber(searchString);
		return listOfOfficers;
	}

	/**
	 * * @purpose Check if user is company director * @since January 12, 2020 * @param companyNumber * @param name
	 * * @return * @throws IOException
	 */
	public CompanyOwnerResponse isBusinessOwner(String companyNumber, String companyName, String firstname,
			String middlename, String surname, String postcode) throws IOException
	{
		return companiesHouseService.isBusinessOwner(companyNumber, companyName, firstname, middlename, surname,
				postcode);

	}

	/**
	 * @purpose Verify business details from companies house interface Attributes verified are :business name,
	 * business * address, CRN, Company number, post code, person with significant control, SIC Codes
	 * @since January 20, 2020
	 * @param businessObject 
	 * @throws IOException
	 * @throws ParseException
	 */
	public void verifyWithCompaniesHouse(Business businessObject) throws IOException, ParseException
	{

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(AssuranceEngineConstants.DATE_FORMAT);

		BusinessName businessNameObj = businessObject.getBusinessName();
		BusinessAddress businessAddressObj = businessObject.getBusinessAddress();
		BusinessCRN businessCRNObj = businessObject.getBusinessCRN();
		ChBusinessId businessCompanyNumberObj = businessObject.getChBusinessId();
		BusinessPostCode businessPostCodeObj = businessObject.getBusinessPostCode();
		BusinessPSC businessPSCObj = businessObject.getBusinessPSC();
		BusinessSIC businessSICObj = businessObject.getBusinessSIC();
		String businessName = businessNameObj.getValue();
		List<Company> listOfCompanies = searchCompaniesByName(businessName);

		for (Company company : listOfCompanies)
		{
			if (company.getCompanyName().equalsIgnoreCase(businessName))
			{

				businessNameObj.setVerifiedDate(simpleDateFormat.format(new Date()));
				businessNameObj.setVerificationSource(AssuranceEngineConstants.COMPANIES_HOUSE);
				/*
				 * * Verify address
				 */
				String locality = businessAddressObj.getLocality();
				String premise = businessAddressObj.getPremise();
				String postCode = businessAddressObj.getPostcode();
				String addressLine1 = businessAddressObj.getAddressLine1();

				if (((null != locality && company.getLocality().equalsIgnoreCase(locality))
						|| (null != premise && company.getLocality().equalsIgnoreCase(premise))
						|| (null != addressLine1 && company.getLocality().equalsIgnoreCase(addressLine1)))
						&& null != postCode && company.getPostCode().equalsIgnoreCase(postCode))
				{

					businessAddressObj.setVerifiedDate(simpleDateFormat.format(new Date()));
					businessAddressObj.setVerificationSource(AssuranceEngineConstants.COMPANIES_HOUSE);
				}
				else
				{
					businessAddressObj.setVerifiedDate(null);
					businessAddressObj.setVerificationSource("");
				}

				/*
				 * * Verify CRN
				 */
				if (company.getChCompanyId().equalsIgnoreCase(businessCRNObj.getValue()))
				{
					businessCRNObj.setVerifiedDate(simpleDateFormat.format(new Date()));
					businessCRNObj.setVerificationSource(AssuranceEngineConstants.COMPANIES_HOUSE);
				}
				else
				{
					businessCRNObj.setVerifiedDate(null);
					businessCRNObj.setVerificationSource("");
				}

				/*
				 * * Verify company_number
				 */
				if (company.getChCompanyId().equalsIgnoreCase(businessCompanyNumberObj.getValue()))
				{
					businessCompanyNumberObj.setVerifiedDate(simpleDateFormat.format(new Date()));
					businessCompanyNumberObj.setVerificationSource(AssuranceEngineConstants.COMPANIES_HOUSE);
				}
				else
				{
					businessCompanyNumberObj.setVerifiedDate(null);
					businessCompanyNumberObj.setVerificationSource("");
				}

				/*
				 * * Verify post code
				 */
				if (company.getPostCode().equalsIgnoreCase(businessPostCodeObj.getValue()))
				{
					businessPostCodeObj.setVerifiedDate(simpleDateFormat.format(new Date()));
					businessPostCodeObj.setVerificationSource(AssuranceEngineConstants.COMPANIES_HOUSE);
				}
				else
				{
					businessPostCodeObj.setVerifiedDate(null);
					businessPostCodeObj.setVerificationSource("");
				}

				/*
				 * * Verify PSC
				 */
				if (null != company.getPersonWithSignificantControl()
						&& company.getPersonWithSignificantControl().size() > 0)
				{
					boolean isAllVerified = true;

					for (PersonWithSignificantControl businessPSC : businessPSCObj.getPersonWithSignificantControl())
					{
						boolean isMatched = false;
						for (PersonWithSignificantControl companyPSC : company.getPersonWithSignificantControl())
						{
							if (businessPSC.getName().equalsIgnoreCase(companyPSC.getName()))
							{
								isMatched = true;
								break;
							}
							else if (companyPSC.getName().toLowerCase().contains(businessPSC.getName()))
							{
								isMatched = true;
								break;
							}
						}
						if (!isMatched)
						{
							isAllVerified = false;
						}
					}

					if (isAllVerified)
					{
						businessPSCObj.setVerifiedDate(simpleDateFormat.format(new Date()));
						businessPSCObj.setVerificationSource(AssuranceEngineConstants.COMPANIES_HOUSE);
					}
					else
					{
						businessPSCObj.setVerifiedDate(null);
						businessPSCObj.setVerificationSource("");
					}
				}

				/*
				 * * SIC codes verification
				 */
				if (null != company.getSicCodes() && company.getSicCodes().size() > 0)
				{
					boolean isAllVerified = true;

					for (String businessSICCode : businessSICObj.getSicCodes())
					{
						boolean isMatched = false;
						for (String companySICCode : company.getSicCodes())
						{
							if (businessSICCode.equalsIgnoreCase(companySICCode))
							{
								isMatched = true;
								break;
							}
						}
						if (!isMatched)
						{
							isAllVerified = false;
						}
					}

					if (isAllVerified)
					{
						businessSICObj.setVerifiedDate(simpleDateFormat.format(new Date()));
						businessSICObj.setVerificationSource(AssuranceEngineConstants.COMPANIES_HOUSE);
					}
					else
					{
						businessSICObj.setVerifiedDate(null);
						businessSICObj.setVerificationSource("");
					}
				}

				/*
				 * * Set high risk attributes
				 */

				businessObject.setHasCharges(company.isHasCharges());
				businessObject.setRegisteredOfficeIsInDispute(company.isRegisteredOfficeIsInDispute());
				businessObject.setBusinessStatus(company.getCompanyStatus());
				break;
			}

		}
	}

	/**
	 * @purpose Get list of person with significant controls of the company matching with company number 
	 * @since January 21, 2020 
	 * @param companyNumber
	 * @return 
	 * @throws IOException
	 */
	public List<PersonWithSignificantControl> getListOfPersonWithSignificantControl(String companyNumber)
			throws IOException
	{
		List<PersonWithSignificantControl> pscList = companiesHouseService
				.getListOfPersonWithSignificantControl(companyNumber);
		return pscList;
	}

	/**
	 *  @purpose Check if user is company director 
	 *  @since January 12, 2020 
	 *  @param companyNumber 
	 *  @param name
	 *  @return 
	 *  @throws IOException
	 */
	public boolean isDisqualified(String companyNumber, String companyName, String firstname, String middlename,
			String surname, String postcode) throws IOException
	{
		return companiesHouseService.isDisqualifiedOfficer(firstname, middlename, surname, postcode, companyName);

	}
}
