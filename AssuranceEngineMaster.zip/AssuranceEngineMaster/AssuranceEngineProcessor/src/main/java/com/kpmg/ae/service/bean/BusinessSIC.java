/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.bean;

import java.util.List;

public class BusinessSIC
{
	private List<String> sicCodes;
	private String verifiedDate;
	private String verificationSource;

	public String getVerifiedDate()
	{
		return verifiedDate;
	}

	public void setVerifiedDate(String verifiedDate)
	{
		this.verifiedDate = verifiedDate;
	}

	public String getVerificationSource()
	{
		return verificationSource;
	}

	public void setVerificationSource(String verificationSource)
	{
		this.verificationSource = verificationSource;
	}

	public List<String> getSicCodes()
	{
		return sicCodes;
	}

	public void setSicCodes(List<String> sicCodes)
	{
		this.sicCodes = sicCodes;
	}

}
