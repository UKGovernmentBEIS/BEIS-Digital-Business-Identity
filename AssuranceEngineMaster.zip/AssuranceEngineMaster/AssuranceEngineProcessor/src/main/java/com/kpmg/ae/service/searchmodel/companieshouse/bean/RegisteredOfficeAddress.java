/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RegisteredOfficeAddress
{

	@JsonProperty("address_line_1")
	private String addressLine1;
	@JsonProperty("address_line_2")
	private String addressLine2;
	@JsonProperty("care_of")
	private String careOf;
	private String country;
	private String locality;
	@JsonProperty("po_box")
	private String poBox;
	@JsonProperty("postal_code")
	private String postalCode;
	private String premises;
	private String region;

	public void setAddressLine1(String addressLine1)
	{
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine1()
	{
		return addressLine1;
	}

	public void setAddressLine2(String addressLine2)
	{
		this.addressLine2 = addressLine2;
	}

	public String getAddressLine2()
	{
		return addressLine2;
	}

	public void setCareOf(String careOf)
	{
		this.careOf = careOf;
	}

	public String getCareOf()
	{
		return careOf;
	}

	public void setCountry(String country)
	{
		this.country = country;
	}

	public String getCountry()
	{
		return country;
	}

	public void setLocality(String locality)
	{
		this.locality = locality;
	}

	public String getLocality()
	{
		return locality;
	}

	public void setPoBox(String poBox)
	{
		this.poBox = poBox;
	}

	public String getPoBox()
	{
		return poBox;
	}

	public void setPostalCode(String postalCode)
	{
		this.postalCode = postalCode;
	}

	public String getPostalCode()
	{
		return postalCode;
	}

	public void setPremises(String premises)
	{
		this.premises = premises;
	}

	public String getPremises()
	{
		return premises;
	}

	public void setRegion(String region)
	{
		this.region = region;
	}

	public String getRegion()
	{
		return region;
	}

}
