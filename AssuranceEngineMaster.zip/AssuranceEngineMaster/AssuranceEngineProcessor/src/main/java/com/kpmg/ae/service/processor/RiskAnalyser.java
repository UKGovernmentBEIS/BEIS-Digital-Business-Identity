/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.processor;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import com.kpmg.ae.service.bean.Business;
import com.kpmg.ae.service.bean.InsolvencyNotice;
import com.kpmg.ae.service.constants.AssuranceEngineConstants;
import com.kpmg.ae.service.utilities.AssuranceEngineUtility;

public class RiskAnalyser
{
	private Properties resourceProperties;
	private int finalRiskScore = 0;

	/**
	 * @purpose Return risk score of business profile
	 * @since January 24, 2020
	 * @param businessObject
	 * @return RiskScore
	 * @throws IOException
	 * @throws ParseException
	 */
	public int getRiskScoreOfBusiness(Business businessObject) throws IOException, ParseException
	{

		resourceProperties = AssuranceEngineUtility.getResourcesProperties();
		/**
		 * Calculate risk score of high risk business attributes
		 */
		/*
		 * hasInsolvencyNotice
		 */
		isHasInsolvencyNotices(businessObject);
		calculateRiskScoreOfHighRiskAttribute(businessObject.isHasInsolvencyNotices(), 15);
		/*
		 * hasCharges
		 */
		calculateRiskScoreOfHighRiskAttribute(businessObject.isHasCharges(), 15);

		/*
		 * businessStatus
		 */
		if (!AssuranceEngineUtility.isNullOrEmptyString(businessObject.getBusinessStatus()))
		{
			calculateRiskScoreOfBusinessStatus(businessObject);
		}

		/*
		 * registeredOfficeIsInDispute
		 */
		calculateRiskScoreOfHighRiskAttribute(businessObject.isRegisteredOfficeIsInDispute(), 10);

		/**
		 * Calculate risk score of moderately high risk business attributes
		 */
		/*
		 * chBusinessId
		 */
		if (null != businessObject.getChBusinessId())
		{
			calculateRiskScoreOfUnVerifiedDate(businessObject.getChBusinessId().getVerifiedDate(), 5);
		}
		/*
		 * businessCRN
		 */
		if (null != businessObject.getBusinessCRN())
		{
			calculateRiskScoreOfUnVerifiedDate(businessObject.getBusinessCRN().getVerifiedDate(), 5);
		}
		/*
		 * businessName
		 */
		if (null != businessObject.getBusinessName())
		{
			calculateRiskScoreOfUnVerifiedDate(businessObject.getBusinessName().getVerifiedDate(), 5);
		}
		/*
		 * businessPostCode
		 */
		if (null != businessObject.getBusinessPostCode())
		{
			calculateRiskScoreOfVerificationDate(businessObject.getBusinessPostCode().getVerifiedDate(), 5, 2);
		}
		/*
		 * businessVAT
		 */
		if (null != businessObject.getBusinessVAT())
		{
			calculateRiskScoreOfVerificationDate(businessObject.getBusinessVAT().getVerifiedDate(), 5, 2);
		}
		/*
		 * businessBankDetails
		 */
		if (null != businessObject.getBusinessBankDetails())
		{
			calculateRiskScoreOfBankingDetails(businessObject);
		}
		/**
		 * Calculate risk score of medium risk business attributes
		 */

		/*
		 * businessAddress
		 */
		if (null != businessObject.getBusinessAddress())
		{
			calculateRiskScoreOfVerificationDate(businessObject.getBusinessAddress().getVerifiedDate(), 3, 1);
		}
		/*
		 * businessUTR
		 */
		if (null != businessObject.getBusinessUTR())
		{
			calculateRiskScoreOfVerificationDate(businessObject.getBusinessUTR().getVerifiedDate(), 3, 1);
		}
		/*
		 * businessDUNN
		 */
		if (null != businessObject.getBusinessDUNN())
		{
			calculateRiskScoreOfVerificationDate(businessObject.getBusinessDUNN().getVerifiedDate(), 3, 1);
		}
		/*
		 * businessPAYE
		 */
		if (null != businessObject.getBusinessPAYE())
		{
			calculateRiskScoreOfVerificationDate(businessObject.getBusinessPAYE().getVerifiedDate(), 3, 1);
		}
		/*
		 * businessSIC
		 */
		if (null != businessObject.getBusinessSIC())
		{
			calculateRiskScoreOfVerificationDate(businessObject.getBusinessSIC().getVerifiedDate(), 3, 1);
		}
		/**
		 * Calculate risk score of low risk business attributes
		 */

		/*
		 * noOfEmployees
		 */
		if (null != businessObject.getNoOfEmployees())
		{
			calculateRiskScoreOfVerificationDate(businessObject.getNoOfEmployees().getVerifiedDate(), 1, 1);
		}
		/*
		 * businessTurnOver
		 */
		if (null != businessObject.getBusinessTurnOver())
		{
			calculateRiskScoreOfVerificationDate(businessObject.getBusinessTurnOver().getVerifiedDate(), 1, 1);
		}
		/*
		 * businessPSC
		 */
		if (null != businessObject.getBusinessPSC())
		{
			calculateRiskScoreOfVerificationDate(businessObject.getBusinessPSC().getVerifiedDate(), 1, 1);
		}
		/*
		 * set risk score to business object
		 */
		if (finalRiskScore < 0)
		{
			finalRiskScore = 0;
		}
		businessObject.setRiskScore(finalRiskScore);
		return finalRiskScore;
	}

	/**
	 * @purpose Validate if verification is expired
	 * @since January 22, 2020
	 * @param lastVerifiedDateStr
	 * @return boolean result
	 * @throws ParseException
	 */
	private boolean isVerificationExpired(String lastVerifiedDateStr) throws ParseException
	{

		int threshold = Integer
				.parseInt(resourceProperties.getProperty(AssuranceEngineConstants.VERIFICATION_DATE_THRESHOLD));
		Date lastVerifiedDate = new SimpleDateFormat(AssuranceEngineConstants.DATE_FORMAT).parse(lastVerifiedDateStr);

		Calendar currentDateBefore3Months = Calendar.getInstance();
		currentDateBefore3Months.add(Calendar.DATE, -threshold);

		if (lastVerifiedDate.before(currentDateBefore3Months.getTime()))
		{
			return true;
		}
		return false;
	}

	/**
	 * @purpose Calculate risk score associated with business status
	 * @since January 24, 2020
	 * @param businessObject
	 * @param finalRiskScore
	 * @return
	 */
	private void calculateRiskScoreOfBusinessStatus(Business businessObject)
	{
		switch (businessObject.getBusinessStatus().toLowerCase())
		{
			case AssuranceEngineConstants.ACTIVE:
				finalRiskScore = finalRiskScore + 12;
				break;

			case AssuranceEngineConstants.DISSOLVED:
				finalRiskScore = finalRiskScore - 10;
				break;

			case AssuranceEngineConstants.LIQUIDATION:
				finalRiskScore = finalRiskScore - 10;
				break;

			case AssuranceEngineConstants.RECEIVERSHIP:
				finalRiskScore = finalRiskScore + 5;
				break;

			case AssuranceEngineConstants.CONVERTED_CLOSED:
				finalRiskScore = finalRiskScore + 2;
				break;

			case AssuranceEngineConstants.VOLUNTARY_ARRANGEMENT:
				finalRiskScore = finalRiskScore + 2;
				break;

			case AssuranceEngineConstants.INSOLVENCY_PROCEEDINGS:
				finalRiskScore = finalRiskScore - 12;
				break;

			case AssuranceEngineConstants.ADMINISTRATION:
				finalRiskScore = finalRiskScore + 5;
				break;

			case AssuranceEngineConstants.OPEN:
				finalRiskScore = finalRiskScore + 3;
				break;

			case AssuranceEngineConstants.CLOSED:
				finalRiskScore = finalRiskScore - 3;
				break;

			default:
				finalRiskScore = finalRiskScore - 10;
		}
	}

	/**
	 * @purpose Get risk if date is unverified or expired
	 * @since January 24, 2020
	 * @param lastVerificationDateStr
	 *            : last verified date
	 * @param attributeRiskScore
	 *            : Risk score of attribute
	 * @param expiryPenalty
	 *            : Risk score if verification date expired
	 * @param finalRiskScore
	 * @return
	 * @throws ParseException
	 */
	private void calculateRiskScoreOfVerificationDate(String lastVerificationDateStr, int attributeRiskScore,
			int expiryPenalty) throws ParseException
	{
		if (AssuranceEngineUtility.isNullOrEmptyString(lastVerificationDateStr))
		{
			finalRiskScore = finalRiskScore - attributeRiskScore;
		}
		else if (isVerificationExpired(lastVerificationDateStr))
		{
			finalRiskScore = finalRiskScore - expiryPenalty;
		}
		else
		{
			finalRiskScore = finalRiskScore + attributeRiskScore;
		}
	}

	/**
	 * @purpose Calculate risk of unverified date
	 * @since January 24, 2020
	 * @param lastVerificationDateStr
	 * @param attributeRiskScore
	 * @param finalRiskScore
	 * @return
	 */
	private void calculateRiskScoreOfUnVerifiedDate(String lastVerificationDateStr, int attributeRiskScore)
	{
		if (AssuranceEngineUtility.isNullOrEmptyString(lastVerificationDateStr))
		{
			finalRiskScore = finalRiskScore - attributeRiskScore;
		}
		else
		{
			finalRiskScore = finalRiskScore + attributeRiskScore;
		}
	}

	/**
	 * @purpose Calculate risk score from bank details
	 * @since January 24, 2020
	 * @param businessObject
	 * @param finalRiskScore
	 * @return
	 * @throws ParseException
	 */
	private void calculateRiskScoreOfBankingDetails(Business businessObject) throws ParseException
	{
		if (AssuranceEngineUtility
				.isNullOrEmptyString(businessObject.getBusinessBankDetails().getSortcode().getVerifiedDate())
				&& AssuranceEngineUtility.isNullOrEmptyString(
						businessObject.getBusinessBankDetails().getAccountNumber().getVerifiedDate()))
		{
			finalRiskScore = finalRiskScore - 5;
		}
		else if (AssuranceEngineUtility
				.isNullOrEmptyString(businessObject.getBusinessBankDetails().getSortcode().getVerifiedDate())
				|| AssuranceEngineUtility.isNullOrEmptyString(
						businessObject.getBusinessBankDetails().getAccountNumber().getVerifiedDate()))
		{
			finalRiskScore = finalRiskScore - 3;
		}
		else if ((!AssuranceEngineUtility
				.isNullOrEmptyString(businessObject.getBusinessBankDetails().getSortcode().getVerifiedDate())
				&& isVerificationExpired(businessObject.getBusinessBankDetails().getSortcode().getVerifiedDate()))
				|| (!AssuranceEngineUtility.isNullOrEmptyString(
						businessObject.getBusinessBankDetails().getAccountNumber().getVerifiedDate())
						&& isVerificationExpired(
								businessObject.getBusinessBankDetails().getAccountNumber().getVerifiedDate())))
		{

			finalRiskScore = finalRiskScore - 2;
		}
		else
		{
			finalRiskScore = finalRiskScore + 5;
		}
	}

	/**
	 * @purpose Calculate risk score of high risk attributes
	 * @param attributeValue
	 * @param attributeRiskScore
	 * @param finalRiskScore
	 * @return
	 */
	private void calculateRiskScoreOfHighRiskAttribute(boolean attributeValue, int attributeRiskScore)
	{
		if (attributeValue)
		{
			finalRiskScore = finalRiskScore - attributeRiskScore;
		}
		else
		{
			finalRiskScore = finalRiskScore + attributeRiskScore;
		}
	}

	/**
	 * @purpose check if business has any insolvency notices
	 * @since January 24, 2020
	 * @param businessObject
	 * @throws IOException
	 */
	private void isHasInsolvencyNotices(Business businessObject) throws IOException
	{
		try
		{
			TheGazetteServiceProcessor tgServiceProcessor = new TheGazetteServiceProcessor();
			List<InsolvencyNotice> listOfNotices = tgServiceProcessor.getAllInsolvencyNoticesByCompanyNumber(
					businessObject.getChBusinessId().getValue(), businessObject.getBusinessName().getValue());

			if (listOfNotices.size() > 0)
			{
				businessObject.setHasInsolvencyNotices(true);
			}
		}
		catch (IOException e)
		{
			throw e;
		}
	}
}
