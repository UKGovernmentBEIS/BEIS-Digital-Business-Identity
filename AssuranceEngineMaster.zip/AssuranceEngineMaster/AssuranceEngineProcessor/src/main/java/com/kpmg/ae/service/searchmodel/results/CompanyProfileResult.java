/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.results;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kpmg.ae.service.searchmodel.companieshouse.bean.Accounts;
import com.kpmg.ae.service.searchmodel.companieshouse.bean.AnnualReturn;
import com.kpmg.ae.service.searchmodel.companieshouse.bean.BranchCompanyDetails;
import com.kpmg.ae.service.searchmodel.companieshouse.bean.ConfirmationStatement;
import com.kpmg.ae.service.searchmodel.companieshouse.bean.ForeignCompanyDetails;
import com.kpmg.ae.service.searchmodel.companieshouse.bean.Links;
import com.kpmg.ae.service.searchmodel.companieshouse.bean.PreviousCompanyNames;
import com.kpmg.ae.service.searchmodel.companieshouse.bean.RegisteredOfficeAddress;

public class CompanyProfileResult
{

	private Accounts accounts;
	@JsonProperty("annual_return")
	private AnnualReturn annualReturn;
	@JsonProperty("branch_company_details")
	private BranchCompanyDetails branchCompanyDetails;
	@JsonProperty("can_file")
	private String canFile;
	@JsonProperty("company_name")
	private String companyName;
	@JsonProperty("company_number")
	private String companyNumber;
	@JsonProperty("company_status")
	private String companyStatus;
	@JsonProperty("company_status_detail")
	private String companyStatusDetail;
	@JsonProperty("confirmation_statement")
	private ConfirmationStatement confirmationStatement;
	@JsonProperty("date_of_cessation")
	private String dateOfCessation;
	@JsonProperty("date_of_creation")
	private String dateOfCreation;
	private String etag;
	@JsonProperty("external_registration_number")
	private String externalRegistrationNumber;
	@JsonProperty("foreign_company_details")
	private ForeignCompanyDetails foreignCompanyDetails;
	@JsonProperty("has_been_liquidated")
	private String hasBeenLiquidated;
	@JsonProperty("has_charges")
	private String hasCharges;
	@JsonProperty("has_insolvency_history")
	private String hasInsolvencyHistory;
	@JsonProperty("is_community_interest_company")
	private String isCommunityInterestCompany;
	private String jurisdiction;
	@JsonProperty("last_full_members_list_date")
	private String lastFullMembersListDate;
	private Links links;
	@JsonProperty("partial_data_available")
	private String partialDataAvailable;
	@JsonProperty("previous_company_names")
	private List<PreviousCompanyNames> previousCompanyNames;
	@JsonProperty("registered_office_address")
	private RegisteredOfficeAddress registeredOfficeAddress;
	@JsonProperty("registered_office_is_in_dispute")
	private String registeredOfficeIsInDispute;
	@JsonProperty("sic_codes")
	private List<String> sicCodes;
	private String subtype;
	private String type;
	@JsonProperty("undeliverable_registered_office_address")
	private String undeliverableRegisteredOfficeAddress;

	private String status;

	public void setAccounts(Accounts accounts)
	{
		this.accounts = accounts;
	}

	public Accounts getAccounts()
	{
		return accounts;
	}

	public void setAnnualReturn(AnnualReturn annualReturn)
	{
		this.annualReturn = annualReturn;
	}

	public AnnualReturn getAnnualReturn()
	{
		return annualReturn;
	}

	public void setBranchCompanyDetails(BranchCompanyDetails branchCompanyDetails)
	{
		this.branchCompanyDetails = branchCompanyDetails;
	}

	public BranchCompanyDetails getBranchCompanyDetails()
	{
		return branchCompanyDetails;
	}

	public void setCanFile(String canFile)
	{
		this.canFile = canFile;
	}

	public String getCanFile()
	{
		return canFile;
	}

	public void setCompanyName(String companyName)
	{
		this.companyName = companyName;
	}

	public String getCompanyName()
	{
		return companyName;
	}

	public void setCompanyNumber(String companyNumber)
	{
		this.companyNumber = companyNumber;
	}

	public String getCompanyNumber()
	{
		return companyNumber;
	}

	public void setCompanyStatus(String companyStatus)
	{
		this.companyStatus = companyStatus;
	}

	public String getCompanyStatus()
	{
		return companyStatus;
	}

	public void setCompanyStatusDetail(String companyStatusDetail)
	{
		this.companyStatusDetail = companyStatusDetail;
	}

	public String getCompanyStatusDetail()
	{
		return companyStatusDetail;
	}

	public void setConfirmationStatement(ConfirmationStatement confirmationStatement)
	{
		this.confirmationStatement = confirmationStatement;
	}

	public ConfirmationStatement getConfirmationStatement()
	{
		return confirmationStatement;
	}

	public void setDateOfCessation(String dateOfCessation)
	{
		this.dateOfCessation = dateOfCessation;
	}

	public String getDateOfCessation()
	{
		return dateOfCessation;
	}

	public void setDateOfCreation(String dateOfCreation)
	{
		this.dateOfCreation = dateOfCreation;
	}

	public String getDateOfCreation()
	{
		return dateOfCreation;
	}

	public void setEtag(String etag)
	{
		this.etag = etag;
	}

	public String getEtag()
	{
		return etag;
	}

	public void setExternalRegistrationNumber(String externalRegistrationNumber)
	{
		this.externalRegistrationNumber = externalRegistrationNumber;
	}

	public String getExternalRegistrationNumber()
	{
		return externalRegistrationNumber;
	}

	public void setForeignCompanyDetails(ForeignCompanyDetails foreignCompanyDetails)
	{
		this.foreignCompanyDetails = foreignCompanyDetails;
	}

	public ForeignCompanyDetails getForeignCompanyDetails()
	{
		return foreignCompanyDetails;
	}

	public void setHasBeenLiquidated(String hasBeenLiquidated)
	{
		this.hasBeenLiquidated = hasBeenLiquidated;
	}

	public String getHasBeenLiquidated()
	{
		return hasBeenLiquidated;
	}

	public void setHasCharges(String hasCharges)
	{
		this.hasCharges = hasCharges;
	}

	public String getHasCharges()
	{
		return hasCharges;
	}

	public void setHasInsolvencyHistory(String hasInsolvencyHistory)
	{
		this.hasInsolvencyHistory = hasInsolvencyHistory;
	}

	public String getHasInsolvencyHistory()
	{
		return hasInsolvencyHistory;
	}

	public void setIsCommunityInterestCompany(String isCommunityInterestCompany)
	{
		this.isCommunityInterestCompany = isCommunityInterestCompany;
	}

	public String getIsCommunityInterestCompany()
	{
		return isCommunityInterestCompany;
	}

	public void setJurisdiction(String jurisdiction)
	{
		this.jurisdiction = jurisdiction;
	}

	public String getJurisdiction()
	{
		return jurisdiction;
	}

	public void setLastFullMembersListDate(String lastFullMembersListDate)
	{
		this.lastFullMembersListDate = lastFullMembersListDate;
	}

	public String getLastFullMembersListDate()
	{
		return lastFullMembersListDate;
	}

	public void setLinks(Links links)
	{
		this.links = links;
	}

	public Links getLinks()
	{
		return links;
	}

	public void setPartialDataAvailable(String partialDataAvailable)
	{
		this.partialDataAvailable = partialDataAvailable;
	}

	public String getPartialDataAvailable()
	{
		return partialDataAvailable;
	}

	public void setPreviousCompanyNames(List<PreviousCompanyNames> previousCompanyNames)
	{
		this.previousCompanyNames = previousCompanyNames;
	}

	public List<PreviousCompanyNames> getPreviousCompanyNames()
	{
		return previousCompanyNames;
	}

	public void setRegisteredOfficeAddress(RegisteredOfficeAddress registeredOfficeAddress)
	{
		this.registeredOfficeAddress = registeredOfficeAddress;
	}

	public RegisteredOfficeAddress getRegisteredOfficeAddress()
	{
		return registeredOfficeAddress;
	}

	public void setRegisteredOfficeIsInDispute(String registeredOfficeIsInDispute)
	{
		this.registeredOfficeIsInDispute = registeredOfficeIsInDispute;
	}

	public String getRegisteredOfficeIsInDispute()
	{
		return registeredOfficeIsInDispute;
	}

	public void setSicCodes(List<String> sicCodes)
	{
		this.sicCodes = sicCodes;
	}

	public List<String> getSicCodes()
	{
		return sicCodes;
	}

	public void setSubtype(String subtype)
	{
		this.subtype = subtype;
	}

	public String getSubtype()
	{
		return subtype;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public String getType()
	{
		return type;
	}

	public void setUndeliverableRegisteredOfficeAddress(String undeliverableRegisteredOfficeAddress)
	{
		this.undeliverableRegisteredOfficeAddress = undeliverableRegisteredOfficeAddress;
	}

	public String getUndeliverableRegisteredOfficeAddress()
	{
		return undeliverableRegisteredOfficeAddress;
	}

	public String getStatus()
	{
		return status;
	}

	public void setStatus(String status)
	{
		this.status = status;
	}

}
