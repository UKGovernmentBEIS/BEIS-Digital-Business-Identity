/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.thegazette.bean;

import java.util.ArrayList;

public class Adr
{
	private String _about;
	private String type;
	ArrayList<Object> extendedAddress = new ArrayList<Object>();
	private String label;
	ArrayList<Object> postalCode = new ArrayList<Object>();
	private String streetAddress;
	private String postcode;

	// Getter Methods

	public String get_about()
	{
		return _about;
	}

	public ArrayList<Object> getExtendedAddress()
	{
		return extendedAddress;
	}

	public void setExtendedAddress(ArrayList<Object> extendedAddress)
	{
		this.extendedAddress = extendedAddress;
	}

	public ArrayList<Object> getPostalCode()
	{
		return postalCode;
	}

	public void setPostalCode(ArrayList<Object> postalCode)
	{
		this.postalCode = postalCode;
	}

	public String getType()
	{
		return type;
	}

	public String getLabel()
	{
		return label;
	}

	public String getStreetAddress()
	{
		return streetAddress;
	}

	public String getPostcode()
	{
		return postcode;
	}

	// Setter Methods

	public void set_about(String _about)
	{
		this._about = _about;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public void setLabel(String label)
	{
		this.label = label;
	}

	public void setStreetAddress(String streetAddress)
	{
		this.streetAddress = streetAddress;
	}

	public void setPostcode(String postcode)
	{
		this.postcode = postcode;
	}
}
