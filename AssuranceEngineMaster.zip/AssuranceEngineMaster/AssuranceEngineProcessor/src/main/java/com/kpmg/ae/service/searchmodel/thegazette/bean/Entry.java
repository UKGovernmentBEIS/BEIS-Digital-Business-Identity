/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.thegazette.bean;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "id", "f:status", "f:notice-code", "title", "link", "author", "updated", "published", "category",
		"content", "geo:Point" })
public class Entry
{

	@JsonProperty("id")
	private String id;
	@JsonProperty("f:status")
	private String fStatus;
	@JsonProperty("f:notice-code")
	private String fNoticeCode;
	@JsonProperty("title")
	private String title;
	@JsonProperty("link")
	private List<Link_> link = null;
	@JsonProperty("author")
	private Author author;
	@JsonProperty("updated")
	private String updated;
	@JsonProperty("published")
	private String published;
	@JsonProperty("category")
	private Category category;
	@JsonProperty("content")
	private String content;
	@JsonProperty("geo:Point")
	private GeoPoint geoPoint;

	@JsonProperty("id")
	public String getId()
	{
		return id;
	}

	@JsonProperty("id")
	public void setId(String id)
	{
		this.id = id;
	}

	@JsonProperty("f:status")
	public String getFStatus()
	{
		return fStatus;
	}

	@JsonProperty("f:status")
	public void setFStatus(String fStatus)
	{
		this.fStatus = fStatus;
	}

	@JsonProperty("f:notice-code")
	public String getFNoticeCode()
	{
		return fNoticeCode;
	}

	@JsonProperty("f:notice-code")
	public void setFNoticeCode(String fNoticeCode)
	{
		this.fNoticeCode = fNoticeCode;
	}

	@JsonProperty("title")
	public String getTitle()
	{
		return title;
	}

	@JsonProperty("title")
	public void setTitle(String title)
	{
		this.title = title;
	}

	@JsonProperty("link")
	public List<Link_> getLink()
	{
		return link;
	}

	@JsonProperty("link")
	public void setLink(List<Link_> link)
	{
		this.link = link;
	}

	@JsonProperty("author")
	public Author getAuthor()
	{
		return author;
	}

	@JsonProperty("author")
	public void setAuthor(Author author)
	{
		this.author = author;
	}

	@JsonProperty("updated")
	public String getUpdated()
	{
		return updated;
	}

	@JsonProperty("updated")
	public void setUpdated(String updated)
	{
		this.updated = updated;
	}

	@JsonProperty("published")
	public String getPublished()
	{
		return published;
	}

	@JsonProperty("published")
	public void setPublished(String published)
	{
		this.published = published;
	}

	@JsonProperty("category")
	public Category getCategory()
	{
		return category;
	}

	@JsonProperty("category")
	public void setCategory(Category category)
	{
		this.category = category;
	}

	@JsonProperty("content")
	public String getContent()
	{
		return content;
	}

	@JsonProperty("content")
	public void setContent(String content)
	{
		this.content = content;
	}

	@JsonProperty("geo:Point")
	public GeoPoint getGeoPoint()
	{
		return geoPoint;
	}

	@JsonProperty("geo:Point")
	public void setGeoPoint(GeoPoint geoPoint)
	{
		this.geoPoint = geoPoint;
	}
}
