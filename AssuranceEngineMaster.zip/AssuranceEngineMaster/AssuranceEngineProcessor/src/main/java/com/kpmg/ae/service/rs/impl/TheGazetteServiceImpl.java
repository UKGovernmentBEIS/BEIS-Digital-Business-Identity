/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.rs.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.ws.rs.core.Response;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpmg.ae.service.bean.InsolvencyNotice;
import com.kpmg.ae.service.bean.PersonWithInsolvencyNoticeResponse;
import com.kpmg.ae.service.constants.AssuranceEngineConstants;
import com.kpmg.ae.service.rs.intf.TheGazetteService;
import com.kpmg.ae.service.searchmodel.results.InsolvencyNoticeResult;
import com.kpmg.ae.service.searchmodel.thegazette.bean.Entry;
import com.kpmg.ae.service.searchmodel.thegazette.bean.Link_;
import com.kpmg.ae.service.utilities.AssuranceEngineUtility;
import com.kpmg.ae.service.webservice.TheGazetteWebServiceProvider;

public class TheGazetteServiceImpl implements TheGazetteService
{

	TheGazetteWebServiceProvider webServiceProvider;
	HashMap<String, List<InsolvencyNotice>> insolvencyNoticeMap;

	public TheGazetteServiceImpl() throws IOException
	{
		webServiceProvider = new TheGazetteWebServiceProvider();

	}

	/**
	 * @purpose return list of insolvency notices of company
	 * @since 23 January 2020
	 * @param companyName
	 * @throws JsonParseException,
	 *             JsonMappingException, IOException
	 */
	public List<InsolvencyNotice> getInsolvencyNoticesByCompanyName(String companyName)
			throws JsonParseException, JsonMappingException, IOException
	{

		List<InsolvencyNotice> listOfInsolvencyNotices = new ArrayList<InsolvencyNotice>();

		HashMap<String, String> queryMap = new HashMap<String, String>();
		queryMap.put(AssuranceEngineConstants.TEXT, companyName);
		webServiceProvider.setWebTarget(webServiceProvider.getResourcesProperties()
				.getProperty(AssuranceEngineConstants.THE_GAZETTE_GET_ALL_NOTICES_BY_COMPANY_NAME), queryMap);

		Response restResponse = webServiceProvider.getWebTarget().request().get();
		String jsonResponseStr = restResponse.readEntity(String.class);

		/*
		 * This is to handle error in json response returned from thegazette rest call
		 */
		jsonResponseStr = jsonResponseStr.replace("\"request\"\"@searchTerms\"", "\"request\",\"@searchTerms\"");

		if (restResponse.getStatus() == 200)
		{
			InsolvencyNoticeResult weserviceResult = new ObjectMapper().readValue(jsonResponseStr,
					InsolvencyNoticeResult.class);
			if (null != weserviceResult.getEntry())
			{
				for (Entry noticeResult : weserviceResult.getEntry())
				{

					if (noticeResult.getTitle().equalsIgnoreCase(companyName))
					{
						InsolvencyNotice notice = new InsolvencyNotice();
						notice.setNoticeId(
								noticeResult.getId().replace(AssuranceEngineConstants.THE_GAZETTE_NOTICE_ID_LINK, ""));
						notice.setTitle(noticeResult.getTitle());
						notice.setNoticeCode(noticeResult.getFNoticeCode());
						notice.setContent(noticeResult.getContent());
						notice.setNoticeStatus(noticeResult.getFStatus());
						notice.setPublishedOn(noticeResult.getPublished());
						notice.setTerm(noticeResult.getCategory().getTerm());
						listOfInsolvencyNotices.add(notice);
					}
				}
			}
		}
		return listOfInsolvencyNotices;
	}

	/**
	 * @purpose return list of insolvency notices of company
	 * @since 23 January 2020
	 * @param companyName
	 * @throws JsonParseException,
	 *             JsonMappingException, IOException
	 */
	public List<InsolvencyNotice> getInsolvencyNoticesByCompanyNumber(String companyNumber, String companyName)
			throws JsonParseException, JsonMappingException, IOException
	{

		List<InsolvencyNotice> listOfInsolvencyNotices = new ArrayList<InsolvencyNotice>();

		HashMap<String, String> queryMap = new HashMap<String, String>();
		queryMap.put(AssuranceEngineConstants.TEXT, companyNumber);
		webServiceProvider.setWebTarget(webServiceProvider.getResourcesProperties()
				.getProperty(AssuranceEngineConstants.THE_GAZETTE_GET_ALL_NOTICES), queryMap);

		Response restResponse = webServiceProvider.getWebTarget().request().get();
		String jsonResponseStr = restResponse.readEntity(String.class);

		/*
		 * This is to handle error in json response returned from thegazette rest call
		 */
		jsonResponseStr = jsonResponseStr.replace("\"request\"\"@searchTerms\"", "\"request\",\"@searchTerms\"");

		if (restResponse.getStatus() == 200)
		{
			InsolvencyNoticeResult weserviceResult = new ObjectMapper().readValue(jsonResponseStr,
					InsolvencyNoticeResult.class);
			if (null != weserviceResult.getEntry())
			{
				for (Entry noticeResult : weserviceResult.getEntry())
				{

					if (noticeResult.getTitle().equalsIgnoreCase(companyName))
					{
						InsolvencyNotice notice = new InsolvencyNotice();
						notice.setNoticeId(
								noticeResult.getId().replace(AssuranceEngineConstants.THE_GAZETTE_NOTICE_ID_LINK, ""));
						notice.setTitle(noticeResult.getTitle());
						notice.setNoticeCode(noticeResult.getFNoticeCode());
						notice.setContent(noticeResult.getContent());
						notice.setNoticeStatus(noticeResult.getFStatus());
						notice.setPublishedOn(noticeResult.getPublished());
						notice.setTerm(noticeResult.getCategory().getTerm());
						listOfInsolvencyNotices.add(notice);
					}
				}
			}
		}
		return listOfInsolvencyNotices;
	}

	/**
	 * @purpose return list of insolvency notices of company
	 * @since 23 January 2020
	 * @param companyName
	 * @throws JsonParseException,
	 *             JsonMappingException, IOException
	 */
	public PersonWithInsolvencyNoticeResponse getInsolvencyNoticesOfUser(String firstName, String lastName,
			String middleName, String postCode) throws JsonParseException, JsonMappingException, IOException
	{
		PersonWithInsolvencyNoticeResponse personWithInsolvencyNotice = new PersonWithInsolvencyNoticeResponse();

		HashMap<String, String> queryMap = new HashMap<String, String>();
		String nameToSearch = "";

		if (AssuranceEngineUtility.isNullOrEmptyString(middleName))
		{
			nameToSearch = lastName + AssuranceEngineConstants.REGEX_COMMA_SPACE + firstName;
		}
		else
		{
			nameToSearch = lastName + AssuranceEngineConstants.REGEX_COMMA_SPACE + firstName + AssuranceEngineConstants.SPACE + middleName;
		}

		queryMap.put(AssuranceEngineConstants.TEXT, nameToSearch);
		queryMap.put(AssuranceEngineConstants.LOCATION_POSTCODE_1, postCode);
		queryMap.put(AssuranceEngineConstants.LOCATION_DISTANCE_1, "1");
		webServiceProvider.setWebTarget(webServiceProvider.getResourcesProperties()
				.getProperty(AssuranceEngineConstants.THE_GAZETTE_GET_ALL_NOTICES), queryMap);

		Response restResponse = webServiceProvider.getWebTarget().request().get();
		String jsonResponseStr = restResponse.readEntity(String.class);

		/*
		 * This is to handle error in json response returned from thegazette rest call
		 */
		jsonResponseStr = jsonResponseStr.replace("\"request\"\"@searchTerms\"", "\"request\",\"@searchTerms\"");

		if (restResponse.getStatus() == 200)
		{
			InsolvencyNoticeResult weserviceResult = new ObjectMapper().readValue(jsonResponseStr,
					InsolvencyNoticeResult.class);

			if (null != weserviceResult.getEntry())
			{
				for (Entry noticeResult : weserviceResult.getEntry())
				{

					if (noticeResult.getTitle().equalsIgnoreCase(firstName + AssuranceEngineConstants.SPACE + middleName + AssuranceEngineConstants.SPACE + lastName)
							|| noticeResult.getTitle().equalsIgnoreCase(firstName + AssuranceEngineConstants.SPACE + lastName))
					{

						String[] nameArray = noticeResult.getTitle().split(AssuranceEngineConstants.SPACE);
						personWithInsolvencyNotice.setFirstName(nameArray[0].trim()
								+ (AssuranceEngineUtility.isNullOrEmptyString(nameArray[1].trim()) ? ""
										: AssuranceEngineConstants.SPACE + nameArray[1].trim()));
						personWithInsolvencyNotice.setLastName(nameArray[nameArray.length - 1].trim());
						for (Link_ link : noticeResult.getLink())
						{
							if (link.getRel() != null && link.getRel().equalsIgnoreCase(AssuranceEngineConstants.SELF))
							{
								personWithInsolvencyNotice.setInsolvencyNoticeLink(link.getHref());
								break;
							}
						}
						personWithInsolvencyNotice.setPostCode(postCode);
						personWithInsolvencyNotice.setCategory(noticeResult.getCategory().getTerm());
						personWithInsolvencyNotice.setHasInsolvencyNotices(true);
					}
				}
			}
		}
		return personWithInsolvencyNotice;
	}
}
