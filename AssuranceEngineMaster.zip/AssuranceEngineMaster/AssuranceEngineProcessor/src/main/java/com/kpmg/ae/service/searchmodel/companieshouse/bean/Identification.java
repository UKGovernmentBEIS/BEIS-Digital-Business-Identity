/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Identification
{

	@JsonProperty("country_registered")
	String countryRegistered;

	@JsonProperty("legal_authority")
	String legalAuthority;

	@JsonProperty("legal_form")
	String legalForm;

	@JsonProperty("place_registered")
	String placeRegistered;

	@JsonProperty("registration_number")
	String registrationNumber;

	public String getCountryRegistered()
	{
		return countryRegistered;
	}

	public void setCountryRegistered(String countryRegistered)
	{
		this.countryRegistered = countryRegistered;
	}

	public String getLegalAuthority()
	{
		return legalAuthority;
	}

	public void setLegalAuthority(String legalAuthority)
	{
		this.legalAuthority = legalAuthority;
	}

	public String getLegalForm()
	{
		return legalForm;
	}

	public void setLegalForm(String legalForm)
	{
		this.legalForm = legalForm;
	}

	public String getPlaceRegistered()
	{
		return placeRegistered;
	}

	public void setPlaceRegistered(String placeRegistered)
	{
		this.placeRegistered = placeRegistered;
	}

	public String getRegistrationNumber()
	{
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber)
	{
		this.registrationNumber = registrationNumber;
	}
}
