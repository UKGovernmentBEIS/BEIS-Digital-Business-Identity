/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.results;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kpmg.ae.service.searchmodel.companieshouse.bean.LinksBean;
import com.kpmg.ae.service.searchmodel.companieshouse.bean.OfficerResourceSearchBean;

public class OfficerResourceSearchResult
{

	@JsonProperty("active_count")
	int activeCount;

	@JsonProperty("inactive_count")
	int inactiveCount;

	@JsonProperty("items_per_page")
	int itemsPerPage;

	@JsonProperty("kind")
	String kind;

	@JsonProperty("start_index")
	int startIndex;

	@JsonProperty("total_results")
	int totalResults;

	@JsonProperty("items")
	List<OfficerResourceSearchBean> items;

	@JsonProperty("page_number")
	int pageNumber;

	@JsonProperty("links")
	LinksBean links;

	@JsonProperty("resigned_count")
	int resignedCount;

	@JsonProperty("etag")
	String etag;

	public String getKind()
	{
		return kind;
	}

	public void setKind(String kind)
	{
		this.kind = kind;
	}

	public List<OfficerResourceSearchBean> getItems()
	{
		return items;
	}

	public void setItems(List<OfficerResourceSearchBean> items)
	{
		this.items = items;
	}

	public int getItemsPerPage()
	{
		return itemsPerPage;
	}

	public void setItemsPerPage(int itemsPerPage)
	{
		this.itemsPerPage = itemsPerPage;
	}

	public int getStartIndex()
	{
		return startIndex;
	}

	public void setStartIndex(int startIndex)
	{
		this.startIndex = startIndex;
	}

	public int getTotalResults()
	{
		return totalResults;
	}

	public void setTotalResults(int totalResults)
	{
		this.totalResults = totalResults;
	}

	public int getPageNumber()
	{
		return pageNumber;
	}

	public void setPageNumber(int pageNumber)
	{
		this.pageNumber = pageNumber;
	}

	public int getActiveCount()
	{
		return activeCount;
	}

	public void setActiveCount(int activeCount)
	{
		this.activeCount = activeCount;
	}

	public int getInactiveCount()
	{
		return inactiveCount;
	}

	public void setInactiveCount(int inactiveCount)
	{
		this.inactiveCount = inactiveCount;
	}

	public LinksBean getLinks()
	{
		return links;
	}

	public void setLinks(LinksBean links)
	{
		this.links = links;
	}

	public int getResignedCount()
	{
		return resignedCount;
	}

	public void setResignedCount(int resignedCount)
	{
		this.resignedCount = resignedCount;
	}

	public String getEtag()
	{
		return etag;
	}

	public void setEtag(String etag)
	{
		this.etag = etag;
	}

}
