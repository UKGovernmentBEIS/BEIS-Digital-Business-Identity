/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.marketlocation.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RecordBean
{
	@JsonProperty("record_id")
	String recordId;

	@JsonProperty("business_name")
	String businessName;

	String add1;
	String add2;
	String locality;
	String town;
	String county;

	@JsonProperty("post_code")
	String postCode;

	String telno;
	@JsonProperty("employees_site")
	int employeesSite;

	String email;
	@JsonProperty("recorded_turnover")
	double recordedTurnover;

	@JsonProperty("est_turnover")
	double estTurnover;

	@JsonProperty("sic_07")
	String sic;

	@JsonProperty("sic_07_desc")
	String sicDesc;

	String latitude;
	
	String longitude;
	
	public String getRecordId()
	{
		return recordId;
	}
	public void setRecordId(String recordId)
	{
		this.recordId = recordId;
	}
	public String getBusinessName()
	{
		return businessName;
	}
	public void setBusinessName(String businessName)
	{
		this.businessName = businessName;
	}
	public String getAdd1()
	{
		return add1;
	}
	public void setAdd1(String add1)
	{
		this.add1 = add1;
	}
	public String getAdd2()
	{
		return add2;
	}
	public void setAdd2(String add2)
	{
		this.add2 = add2;
	}
	public String getLocality()
	{
		return locality;
	}
	public void setLocality(String locality)
	{
		this.locality = locality;
	}
	public String getTown()
	{
		return town;
	}
	public void setTown(String town)
	{
		this.town = town;
	}
	public String getCounty()
	{
		return county;
	}
	public void setCounty(String county)
	{
		this.county = county;
	}
	public String getPostCode()
	{
		return postCode;
	}
	public void setPostCode(String postCode)
	{
		this.postCode = postCode;
	}
	public String getTelno()
	{
		return telno;
	}
	public void setTelno(String telno)
	{
		this.telno = telno;
	}
	public int getEmployees_site()
	{
		return employeesSite;
	}
	public void setEmployees_site(int employees_site)
	{
		this.employeesSite = employees_site;
	}
	public String getEmail()
	{
		return email;
	}
	public void setEmail(String email)
	{
		this.email = email;
	}
	public double getRecordedTurnover()
	{
		return recordedTurnover;
	}
	public void setRecordedTurnover(double recordedTurnover)
	{
		this.recordedTurnover = recordedTurnover;
	}
	public double getEstTurnover()
	{
		return estTurnover;
	}
	public void setEstTurnover(double estTurnover)
	{
		this.estTurnover = estTurnover;
	}
	public String getSic()
	{
		return sic;
	}
	public void setSic(String sic)
	{
		this.sic = sic;
	}
	public String getSicDesc()
	{
		return sicDesc;
	}
	public void setSicDesc(String sicDesc)
	{
		this.sicDesc = sicDesc;
	}
	public String getLatitude()
	{
		return latitude;
	}
	public void setLatitude(String latitude)
	{
		this.latitude = latitude;
	}
	public String getLongitude()
	{
		return longitude;
	}
	public void setLongitude(String longitude)
	{
		this.longitude = longitude;
	}

}
