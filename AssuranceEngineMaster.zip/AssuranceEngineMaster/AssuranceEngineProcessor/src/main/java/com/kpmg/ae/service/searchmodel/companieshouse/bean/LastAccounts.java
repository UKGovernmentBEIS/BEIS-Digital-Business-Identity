/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LastAccounts
{

	@JsonProperty("made_up_to")
	private String madeUpTo;
	@JsonProperty("period_end_on")
	private String periodEndOn;
	@JsonProperty("period_start_on")
	private String periodStartOn;
	private String type;

	public void setMadeUpTo(String madeUpTo)
	{
		this.madeUpTo = madeUpTo;
	}

	public String getMadeUpTo()
	{
		return madeUpTo;
	}

	public void setPeriodEndOn(String periodEndOn)
	{
		this.periodEndOn = periodEndOn;
	}

	public String getPeriodEndOn()
	{
		return periodEndOn;
	}

	public void setPeriodStartOn(String periodStartOn)
	{
		this.periodStartOn = periodStartOn;
	}

	public String getPeriodStartOn()
	{
		return periodStartOn;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public String getType()
	{
		return type;
	}

}
