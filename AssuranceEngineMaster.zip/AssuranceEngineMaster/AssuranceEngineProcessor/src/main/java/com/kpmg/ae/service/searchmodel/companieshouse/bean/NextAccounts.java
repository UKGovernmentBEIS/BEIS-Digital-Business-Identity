/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class NextAccounts
{

	@JsonProperty("due_on")
	private String dueOn;
	private String overdue;
	@JsonProperty("period_end_on")
	private String periodEndOn;
	@JsonProperty("period_start_on")
	private String periodStartOn;

	public void setDueOn(String dueOn)
	{
		this.dueOn = dueOn;
	}

	public String getDueOn()
	{
		return dueOn;
	}

	public void setOverdue(String overdue)
	{
		this.overdue = overdue;
	}

	public String getOverdue()
	{
		return overdue;
	}

	public void setPeriodEndOn(String periodEndOn)
	{
		this.periodEndOn = periodEndOn;
	}

	public String getPeriodEndOn()
	{
		return periodEndOn;
	}

	public void setPeriodStartOn(String periodStartOn)
	{
		this.periodStartOn = periodStartOn;
	}

	public String getPeriodStartOn()
	{
		return periodStartOn;
	}

}
