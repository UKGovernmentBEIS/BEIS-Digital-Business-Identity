/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.thegazette.bean;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PrimaryTopic
{
	private String _about;
	private String publisher;
	ArrayList<Object> type = new ArrayList<Object>();
	private String sameAs;
	private String alternateOf;
	private String has_anchor;
	private String hasProvenance;
	private String isPrimaryTopicOf;
	private String earliestPublicationDate;
	private float hasNoticeCode;
	private String hasNoticeID;
	private String hasNoticeNumber;
	@JsonProperty("IsAboutObject")
	IsAbout isAboutObject;
	private String hasPageNumber;
	private String hasPublicationDate;

	public String getHasPublicationDate()
	{
		return hasPublicationDate;
	}

	public void setHasPublicationDate(String hasPublicationDate)
	{
		this.hasPublicationDate = hasPublicationDate;
	}

	public String getHasPageNumber()
	{
		return hasPageNumber;
	}

	public void setHasPageNumber(String hasPageNumber)
	{
		this.hasPageNumber = hasPageNumber;
	}

	public ArrayList<Object> getType()
	{
		return type;
	}

	public void setType(ArrayList<Object> type)
	{
		this.type = type;
	}

	public IsAbout getIsAboutObject()
	{
		return isAboutObject;
	}

	public void setIsAboutObject(IsAbout isAboutObject)
	{
		this.isAboutObject = isAboutObject;
	}

	private String isInIssue;

	// Getter Methods

	public String get_about()
	{
		return _about;
	}

	public String getPublisher()
	{
		return publisher;
	}

	public String getSameAs()
	{
		return sameAs;
	}

	public String getAlternateOf()
	{
		return alternateOf;
	}

	public String getHas_anchor()
	{
		return has_anchor;
	}

	public String getHasProvenance()
	{
		return hasProvenance;
	}

	public String getIsPrimaryTopicOf()
	{
		return isPrimaryTopicOf;
	}

	public String getEarliestPublicationDate()
	{
		return earliestPublicationDate;
	}

	public float getHasNoticeCode()
	{
		return hasNoticeCode;
	}

	public String getHasNoticeID()
	{
		return hasNoticeID;
	}

	public String getHasNoticeNumber()
	{
		return hasNoticeNumber;
	}

	public IsAbout getIsAbout()
	{
		return isAboutObject;
	}

	public String getIsInIssue()
	{
		return isInIssue;
	}

	// Setter Methods

	public void set_about(String _about)
	{
		this._about = _about;
	}

	public void setPublisher(String publisher)
	{
		this.publisher = publisher;
	}

	public void setSameAs(String sameAs)
	{
		this.sameAs = sameAs;
	}

	public void setAlternateOf(String alternateOf)
	{
		this.alternateOf = alternateOf;
	}

	public void setHas_anchor(String has_anchor)
	{
		this.has_anchor = has_anchor;
	}

	public void setHasProvenance(String hasProvenance)
	{
		this.hasProvenance = hasProvenance;
	}

	public void setIsPrimaryTopicOf(String isPrimaryTopicOf)
	{
		this.isPrimaryTopicOf = isPrimaryTopicOf;
	}

	public void setEarliestPublicationDate(String earliestPublicationDate)
	{
		this.earliestPublicationDate = earliestPublicationDate;
	}

	public void setHasNoticeCode(float hasNoticeCode)
	{
		this.hasNoticeCode = hasNoticeCode;
	}

	public void setHasNoticeID(String hasNoticeID)
	{
		this.hasNoticeID = hasNoticeID;
	}

	public void setHasNoticeNumber(String hasNoticeNumber)
	{
		this.hasNoticeNumber = hasNoticeNumber;
	}

	public void setIsAbout(IsAbout isAboutObject)
	{
		this.isAboutObject = isAboutObject;
	}

	public void setIsInIssue(String isInIssue)
	{
		this.isInIssue = isInIssue;
	}
}
