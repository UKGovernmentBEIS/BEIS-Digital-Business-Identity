/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LinksBean
{

	@JsonProperty("self")
	String self;

	@JsonProperty("statement")
	String statement;

	@JsonProperty("persons_with_significant_control_statements_list")
	String pscStatementsList;

	@JsonProperty("persons_with_significant_control_statements")
	String pscStatements;

	public String getStatement()
	{
		return statement;
	}

	public void setStatement(String statement)
	{
		this.statement = statement;
	}

	public String getSelf()
	{
		return self;
	}

	public void setSelf(String self)
	{
		this.self = self;
	}

	public String getPscStatementsList()
	{
		return pscStatementsList;
	}

	public void setPscStatementsList(String pscStatementsList)
	{
		this.pscStatementsList = pscStatementsList;
	}

	public String getPscStatements()
	{
		return pscStatements;
	}

	public void setPscStatements(String pscStatements)
	{
		this.pscStatements = pscStatements;
	}

	@Override
	public String toString()
	{
		return "Links [self=" + self + "]";
	}
}
