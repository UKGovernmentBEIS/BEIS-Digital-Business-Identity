/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.utilities;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.json.simple.JSONObject;

import com.kpmg.ae.service.constants.AssuranceEngineConstants;

public class AssuranceEngineUtility
{
	
	private static Properties resourcesProperties;

	public static Properties getResourcesProperties() throws IOException
	{

		if (null == resourcesProperties)
		{
			resourcesProperties = new Properties();
			InputStream inStream = AssuranceEngineUtility.class.getClassLoader()
					.getResourceAsStream(AssuranceEngineConstants.RESOURCES_PROPERTIES);
			resourcesProperties.load(inStream);

			if (resourcesProperties.isEmpty())
			{
				throw new IOException("Error while reading resources.properties");
			}
		}
		return resourcesProperties;
	}

	public static boolean isMatching(JSONObject jsonObj, String key, String value)
	{
		String valueToCompare = (String) jsonObj.get(key);
		if (valueToCompare != null && !valueToCompare.isEmpty())
		{
			if (value.equalsIgnoreCase(valueToCompare))
			{
				return true;
			}
		}
		return false;
	}

	public static boolean isNullOrEmptyString(String key)
	{
		if (key == null || key.isEmpty() || key.equals(AssuranceEngineConstants.SPACE))
		{
			return true;
		}
		return false;
	}

	public static String formatDate(Date date)
	{
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(AssuranceEngineConstants.DATE_FORMAT);
		return simpleDateFormat.format(date);
	}
}
