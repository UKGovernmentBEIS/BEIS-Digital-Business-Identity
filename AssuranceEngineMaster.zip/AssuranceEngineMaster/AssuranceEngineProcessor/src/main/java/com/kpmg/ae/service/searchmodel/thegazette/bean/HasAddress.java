/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.thegazette.bean;

import java.util.ArrayList;

public class HasAddress
{
	private String _about;
	private String type;
	ArrayList<String> extendedAddress = new ArrayList<String>();
	private String label;
	ArrayList<String> postalCode = new ArrayList<String>();
	private String streetAddress;
	Postcode PostcodeObject;

	// Getter Methods

	public String get_about()
	{
		return _about;
	}

	public String getType()
	{
		return type;
	}

	public String getLabel()
	{
		return label;
	}

	public String getStreetAddress()
	{
		return streetAddress;
	}

	public Postcode getPostcode()
	{
		return PostcodeObject;
	}

	// Setter Methods

	public void set_about(String _about)
	{
		this._about = _about;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public void setLabel(String label)
	{
		this.label = label;
	}

	public void setStreetAddress(String streetAddress)
	{
		this.streetAddress = streetAddress;
	}

	public void setPostcode(Postcode postcodeObject)
	{
		this.PostcodeObject = postcodeObject;
	}

	public ArrayList<String> getExtendedAddress()
	{
		return extendedAddress;
	}

	public void setExtendedAddress(ArrayList<String> extendedAddress)
	{
		this.extendedAddress = extendedAddress;
	}

	public ArrayList<String> getPostalCode()
	{
		return postalCode;
	}

	public void setPostalCode(ArrayList<String> postalCode)
	{
		this.postalCode = postalCode;
	}

	public Postcode getPostcodeObject()
	{
		return PostcodeObject;
	}

	public void setPostcodeObject(Postcode postcodeObject)
	{
		PostcodeObject = postcodeObject;
	}
}
