/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.factory;

import java.io.IOException;

import org.json.simple.parser.ParseException;

import com.kpmg.ae.service.rs.impl.CompaniesHouseServiceImpl;
import com.kpmg.ae.service.rs.impl.DnBServiceImpl;
import com.kpmg.ae.service.rs.impl.HMRCServiceImpl;
import com.kpmg.ae.service.rs.impl.LloydsBankingServiceImpl;
import com.kpmg.ae.service.rs.impl.MarketLocationServiceImpl;
import com.kpmg.ae.service.rs.impl.TheGazetteServiceImpl;
import com.kpmg.ae.service.rs.intf.CompaniesHouseService;
import com.kpmg.ae.service.rs.intf.DnBService;
import com.kpmg.ae.service.rs.intf.HMRCService;
import com.kpmg.ae.service.rs.intf.LloydsBankingService;
import com.kpmg.ae.service.rs.intf.MarketLocationService;
import com.kpmg.ae.service.rs.intf.Service;
import com.kpmg.ae.service.rs.intf.TheGazetteService;

public class AssuranceEngineServiceFactory
{
	static Service service;

	public static Service getService(@SuppressWarnings("rawtypes") Class referenceClass)
	{

		try
		{

			if (CompaniesHouseService.class.isAssignableFrom(referenceClass))
			{
				service = new CompaniesHouseServiceFactory().getService();
			}
			if (DnBService.class.isAssignableFrom(referenceClass))
			{
				service = new DnBServiceFactory().getService();
			}
			if (HMRCService.class.isAssignableFrom(referenceClass))
			{
				service = new HMRCServiceFactory().getService();
			}
			if (LloydsBankingService.class.isAssignableFrom(referenceClass))
			{
				service = new LloydsBankingServiceFactory().getService();
			}
			if (TheGazetteService.class.isAssignableFrom(referenceClass))
			{
				service = new TheGazetteServiceFactory().getService();
			}
			if (MarketLocationService.class.isAssignableFrom(referenceClass))
			{
				service = new MarketLocationServiceFactory().getService();
			}
		}
		catch (IOException | ParseException e)
		{
			System.err.println("Exception occured while initiating service (" + referenceClass.getCanonicalName()
					+ ") Error:" + e.getMessage());
		}
		return service;
	}
}

class MarketLocationServiceFactory
{
	Service service;

	MarketLocationServiceFactory() throws IOException
	{
		service = (Service) new MarketLocationServiceImpl();
	}

	Service getService()
	{
		return service;
	}
}

class CompaniesHouseServiceFactory
{
	Service service;

	CompaniesHouseServiceFactory() throws IOException
	{
		service = (Service) new CompaniesHouseServiceImpl();
	}

	Service getService()
	{
		return service;
	}
}

class DnBServiceFactory
{
	Service service;

	DnBServiceFactory() throws IOException, ParseException
	{
		service = (Service) new DnBServiceImpl();
	}

	Service getService()
	{
		return service;
	}
}

class HMRCServiceFactory
{
	Service service;

	HMRCServiceFactory() throws IOException, ParseException
	{
		service = (Service) new HMRCServiceImpl();
	}

	Service getService()
	{
		return service;
	}
}

class LloydsBankingServiceFactory
{
	Service service;

	LloydsBankingServiceFactory() throws IOException, ParseException
	{
		service = (Service) new LloydsBankingServiceImpl();
	}

	Service getService()
	{
		return service;
	}
}

class TheGazetteServiceFactory
{
	Service service;

	TheGazetteServiceFactory() throws IOException
	{
		service = (Service) new TheGazetteServiceImpl();
	}

	Service getService()
	{
		return service;
	}
}
