/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.results;

import java.util.List;

import com.kpmg.ae.service.searchmodel.marketlocation.bean.MarketLocationResultSummaryBean;
import com.kpmg.ae.service.searchmodel.marketlocation.bean.RecordBean;

public class MarketLocationSearchResults
{
	MarketLocationResultSummaryBean summary;
	List<RecordBean> records;

	public MarketLocationResultSummaryBean getSummary()
	{
		return summary;
	}

	public void setSummary(MarketLocationResultSummaryBean summary)
	{
		this.summary = summary;
	}

	public List<RecordBean> getRecords()
	{
		return records;
	}

	public void setRecords(List<RecordBean> records)
	{
		this.records = records;
	}
}
