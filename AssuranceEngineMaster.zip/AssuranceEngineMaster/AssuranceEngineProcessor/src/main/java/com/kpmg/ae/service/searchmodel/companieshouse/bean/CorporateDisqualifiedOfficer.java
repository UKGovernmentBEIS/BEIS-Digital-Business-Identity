/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CorporateDisqualifiedOfficer
{

	@JsonProperty("company_number")
	private String companyNumber;
	@JsonProperty("country_of_registration")
	private String countryOfRegistration;
	private List<Disqualifications> disqualifications;
	private String etag;
	private String kind;
	private Links links;
	private String name;
	@JsonProperty("permissions_to_act")
	private List<PermissionsToAct> permissionsToAct;

	public void setCompanyNumber(String companyNumber)
	{
		this.companyNumber = companyNumber;
	}

	public String getCompanyNumber()
	{
		return companyNumber;
	}

	public void setCountryOfRegistration(String countryOfRegistration)
	{
		this.countryOfRegistration = countryOfRegistration;
	}

	public String getCountryOfRegistration()
	{
		return countryOfRegistration;
	}

	public void setDisqualifications(List<Disqualifications> disqualifications)
	{
		this.disqualifications = disqualifications;
	}

	public List<Disqualifications> getDisqualifications()
	{
		return disqualifications;
	}

	public void setEtag(String etag)
	{
		this.etag = etag;
	}

	public String getEtag()
	{
		return etag;
	}

	public void setKind(String kind)
	{
		this.kind = kind;
	}

	public String getKind()
	{
		return kind;
	}

	public void setLinks(Links links)
	{
		this.links = links;
	}

	public Links getLinks()
	{
		return links;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getName()
	{
		return name;
	}

	public void setPermissionsToAct(List<PermissionsToAct> permissionsToAct)
	{
		this.permissionsToAct = permissionsToAct;
	}

	public List<PermissionsToAct> getPermissionsToAct()
	{
		return permissionsToAct;
	}

}
