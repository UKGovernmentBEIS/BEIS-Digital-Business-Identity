/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.thegazette.bean;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IsAbout
{
	private String _about;
	ArrayList<String> type = new ArrayList<String>();
	ArrayList<String> postalCode = new ArrayList<String>();
	private String dateOfAppointment;
	private String dateOfBankruptcyOrder;
	private String datePetitionFiled;
	HasCourtCase HasCourtCaseObject;
	HasOfficialReceiver HasOfficialReceiverObject;
	private String typeOfPetition;
	private String phoneNumber;
	Postcode postcode = new Postcode();
	private String email;
	@JsonProperty("PersonObject")
	Person personObject;
	ArrayList<String> relatedDate = new ArrayList<String>();
	private String hasPrimaryIP;

	// Getter Methods

	public ArrayList<String> getType()
	{
		return type;
	}

	public void setType(ArrayList<String> type)
	{
		this.type = type;
	}

	public ArrayList<String> getPostalCode()
	{
		return postalCode;
	}

	public void setPostalCode(ArrayList<String> postalCode)
	{
		this.postalCode = postalCode;
	}

	public HasCourtCase getHasCourtCaseObject()
	{
		return HasCourtCaseObject;
	}

	public void setHasCourtCaseObject(HasCourtCase hasCourtCaseObject)
	{
		HasCourtCaseObject = hasCourtCaseObject;
	}

	public HasOfficialReceiver getHasOfficialReceiverObject()
	{
		return HasOfficialReceiverObject;
	}

	public void setHasOfficialReceiverObject(HasOfficialReceiver hasOfficialReceiverObject)
	{
		HasOfficialReceiverObject = hasOfficialReceiverObject;
	}

	public Postcode getPostcode()
	{
		return postcode;
	}

	public void setPostcode(Postcode postcode)
	{
		this.postcode = postcode;
	}

	public Person getPersonObject()
	{
		return personObject;
	}

	public void setPersonObject(Person personObject)
	{
		this.personObject = personObject;
	}

	public ArrayList<String> getRelatedDate()
	{
		return relatedDate;
	}

	public void setRelatedDate(ArrayList<String> relatedDate)
	{
		this.relatedDate = relatedDate;
	}

	public String get_about()
	{
		return _about;
	}

	public String getDateOfAppointment()
	{
		return dateOfAppointment;
	}

	public String getDateOfBankruptcyOrder()
	{
		return dateOfBankruptcyOrder;
	}

	public String getDatePetitionFiled()
	{
		return datePetitionFiled;
	}

	public HasCourtCase getHasCourtCase()
	{
		return HasCourtCaseObject;
	}

	public HasOfficialReceiver getHasOfficialReceiver()
	{
		return HasOfficialReceiverObject;
	}

	public String getTypeOfPetition()
	{
		return typeOfPetition;
	}

	public String getPhoneNumber()
	{
		return phoneNumber;
	}

	public String getEmail()
	{
		return email;
	}

	public Person getPerson()
	{
		return personObject;
	}

	// Setter Methods

	public void set_about(String _about)
	{
		this._about = _about;
	}

	public void setDateOfAppointment(String dateOfAppointment)
	{
		this.dateOfAppointment = dateOfAppointment;
	}

	public void setDateOfBankruptcyOrder(String dateOfBankruptcyOrder)
	{
		this.dateOfBankruptcyOrder = dateOfBankruptcyOrder;
	}

	public void setDatePetitionFiled(String datePetitionFiled)
	{
		this.datePetitionFiled = datePetitionFiled;
	}

	public void setHasCourtCase(HasCourtCase hasCourtCaseObject)
	{
		this.HasCourtCaseObject = hasCourtCaseObject;
	}

	public void setHasOfficialReceiver(HasOfficialReceiver hasOfficialReceiverObject)
	{
		this.HasOfficialReceiverObject = hasOfficialReceiverObject;
	}

	public void setTypeOfPetition(String typeOfPetition)
	{
		this.typeOfPetition = typeOfPetition;
	}

	public void setPhoneNumber(String phoneNumber)
	{
		this.phoneNumber = phoneNumber;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public void setPerson(Person personObject)
	{
		this.personObject = personObject;
	}

	public String getHasPrimaryIP()
	{
		return hasPrimaryIP;
	}

	public void setHasPrimaryIP(String hasPrimaryIP)
	{
		this.hasPrimaryIP = hasPrimaryIP;
	}

}
