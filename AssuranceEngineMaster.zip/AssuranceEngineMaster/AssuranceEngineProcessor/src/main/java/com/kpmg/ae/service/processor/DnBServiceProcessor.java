/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.processor;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import com.kpmg.ae.service.bean.Business;
import com.kpmg.ae.service.bean.BusinessDUNN;
import com.kpmg.ae.service.bean.ChBusinessId;
import com.kpmg.ae.service.bean.Company;
import com.kpmg.ae.service.constants.AssuranceEngineConstants;
import com.kpmg.ae.service.factory.AssuranceEngineServiceFactory;
import com.kpmg.ae.service.rs.intf.DnBService;
import com.kpmg.ae.service.utilities.AssuranceEngineUtility;

public class DnBServiceProcessor
{
	private DnBService dnbService;

	public DnBServiceProcessor() throws IOException, ParseException
	{
		dnbService = (DnBService) AssuranceEngineServiceFactory.getService(DnBService.class);
	}

	/**
	 * @purpose Verify DUNN of business
	 * @since January 21, 2020
	 * @param businessObject
	 */
	public void verifyWithDAndB(Business businessObject)
	{
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(AssuranceEngineConstants.DATE_FORMAT);

		ChBusinessId businessCompanyNumberObj = businessObject.getChBusinessId();
		BusinessDUNN businessDUNNObj = businessObject.getBusinessDUNN();

		if (!AssuranceEngineUtility.isNullOrEmptyString(businessCompanyNumberObj.getVerifiedDate()))
		{

			JSONObject dnbBusinessJsonObj = dnbService
					.findCompanyDetailsByCompanyNumber(businessCompanyNumberObj.getValue());

			if (null != dnbBusinessJsonObj)
			{
				/*
				 * Verify DUNN
				 */
				String dnbDUNN = (String) dnbBusinessJsonObj.get(AssuranceEngineConstants.DUNN);

				if (!AssuranceEngineUtility.isNullOrEmptyString(dnbDUNN))
				{
					String businessDUNNStr = businessDUNNObj.getValue();
					if (!AssuranceEngineUtility.isNullOrEmptyString(businessDUNNStr)
							&& dnbDUNN.equalsIgnoreCase(businessDUNNStr))
					{
						businessDUNNObj.setVerifiedDate(simpleDateFormat.format(new Date()));
						businessDUNNObj.setVerificationSource(AssuranceEngineConstants.D_B);
					}
					else
					{
						businessDUNNObj.setVerifiedDate(null);
						businessDUNNObj.setVerificationSource("");
					}
				}
			}
		}
	}

	public void getAdditionalInfo(List<Company> companiesList)
	{
		for (Company company : companiesList)
		{
			dnbService.getAdditionalInfoFromDnB(company);
		}
	}
}
