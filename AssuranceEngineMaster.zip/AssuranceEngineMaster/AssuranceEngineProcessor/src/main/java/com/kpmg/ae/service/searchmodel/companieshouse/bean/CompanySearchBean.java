/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import java.util.Date;
import java.util.List;

public class CompanySearchBean
{

	AddressBean address;
	String address_snippet;
	String company_number;
	String company_status;
	String company_type;
	Date date_of_creation;
	Date date_of_cessation;
	String description;
	List<String> description_identifier;
	String external_registration_number;
	String kind;
	LinksBean links;
	Matches matches;
	String snippet;
	String title;

	public AddressBean getAddress()
	{
		return address;
	}

	public void setAddress(AddressBean address)
	{
		this.address = address;
	}

	public String getDescription()
	{
		return description;
	}

	public void setDescription(String description)
	{
		this.description = description;
	}

	public String getAddressSnippet()
	{
		return address_snippet;
	}

	public void setAddress_snippet(String address_snippet)
	{
		this.address_snippet = address_snippet;
	}

	public String getCompanyNumber()
	{
		return company_number;
	}

	public void setCompany_number(String company_number)
	{
		this.company_number = company_number;
	}

	public String getCompanyStatus()
	{
		return company_status;
	}

	public void setCompany_status(String company_status)
	{
		this.company_status = company_status;
	}

	public String getCompanyType()
	{
		return company_type;
	}

	public void setCompany_type(String company_type)
	{
		this.company_type = company_type;
	}

	public Date getDateOfCreation()
	{
		return date_of_creation;
	}

	public void setDate_of_creation(Date date_of_creation)
	{
		this.date_of_creation = date_of_creation;
	}

	public Date getDateOfCessation()
	{
		return date_of_cessation;
	}

	public void setDate_of_cessation(Date date_of_cessation)
	{
		this.date_of_cessation = date_of_cessation;
	}

	public List<String> getDescription_identifier()
	{
		return description_identifier;
	}

	public void setDescription_identifier(List<String> description_identifier)
	{
		this.description_identifier = description_identifier;
	}

	public String getExternalRegistrationNumber()
	{
		return external_registration_number;
	}

	public void setExternal_registration_number(String external_registration_number)
	{
		this.external_registration_number = external_registration_number;
	}

	public String getKind()
	{
		return kind;
	}

	public void setKind(String kind)
	{
		this.kind = kind;
	}

	public LinksBean getLinks()
	{
		return links;
	}

	public void setLinks(LinksBean links)
	{
		this.links = links;
	}

	public Matches getMatches()
	{
		return matches;
	}

	public void setMatches(Matches matches)
	{
		this.matches = matches;
	}

	public String getSnippet()
	{
		return snippet;
	}

	public void setSnippet(String snippet)
	{
		this.snippet = snippet;
	}

	public String getTitle()
	{
		return title;
	}

	public void setTitle(String title)
	{
		this.title = title;
	}

	@Override
	public String toString()
	{
		return "CompanySearchBean [address=" + address + ", address_snippet=" + address_snippet + ", company_number="
				+ company_number + ", company_status=" + company_status + ", company_type=" + company_type
				+ ", date_of_creation=" + date_of_creation + ", date_of_cessation=" + date_of_cessation
				+ ", description=" + description + ", description_identifier=" + description_identifier
				+ ", external_registration_number=" + external_registration_number + ", kind=" + kind + ", links="
				+ links + ", matches=" + matches + ", snippet=" + snippet + ", title=" + title + "]";
	}

}
