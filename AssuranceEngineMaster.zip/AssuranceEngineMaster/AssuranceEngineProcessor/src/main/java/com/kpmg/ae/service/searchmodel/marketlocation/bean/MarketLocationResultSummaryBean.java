/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.marketlocation.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MarketLocationResultSummaryBean
{
	@JsonProperty("search_id")
	String searchId;
	
	@JsonProperty("total_results_number")
	int totalResultsNumber;
	
	@JsonProperty("current_results_number")
	double currentResultsNumber;
	
	@JsonProperty("total_pages")
	long totalPages;
	
	@JsonProperty("current_page")
	int currentPage;

	public String getSearchId()
	{
		return searchId;
	}

	public void setSearchId(String searchId)
	{
		this.searchId = searchId;
	}

	public int getTotalResultsNumber()
	{
		return totalResultsNumber;
	}

	public void setTotalResultsNumber(int totalResultsNumber)
	{
		this.totalResultsNumber = totalResultsNumber;
	}

	public double getCurrentResultsNumber()
	{
		return currentResultsNumber;
	}

	public void setCurrentResultsNumber(double currentResultsNumber)
	{
		this.currentResultsNumber = currentResultsNumber;
	}

	public long getTotalPages()
	{
		return totalPages;
	}

	public void setTotalPages(long totalPages)
	{
		this.totalPages = totalPages;
	}

	public int getCurrentPage()
	{
		return currentPage;
	}

	public void setCurrentPage(int currentPage)
	{
		this.currentPage = currentPage;
	}
		
}
