/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.webservice;

import java.io.IOException;
import java.io.InvalidObjectException;
import java.util.Arrays;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import com.kpmg.ae.service.constants.AssuranceEngineConstants;
import com.kpmg.ae.service.password.utils.PasswordUtils;

public class MarketLocationWebServiceProvider extends AssuranceEngineWebServiceProvider
{

	private WebTarget marketLocationWebTarget;
	private Client webClient;

	public MarketLocationWebServiceProvider() throws IOException
	{
		super();
		registerWebClient();
	}

	private void registerWebClient() throws InvalidObjectException
	{
		this.webClient = getWebClient();
	}

	@Override
	public WebTarget getWebTarget()
	{
		String baseUrl = super.getResourcesProperties().getProperty(AssuranceEngineConstants.MARKET_LOCATION_BASE_URL);
		marketLocationWebTarget = this.webClient.target(baseUrl);
		return marketLocationWebTarget;
	}

	public Response callGet(String uri, Map<String, Object> params) throws IOException
	{
		this.getWebTarget();
		String baseUrl = super.getResourcesProperties().getProperty(AssuranceEngineConstants.MARKET_LOCATION_BASE_URL);
		char[] clientId = new PasswordUtils().getSecrete(AssuranceEngineConstants.PROPERTY_MARKET_LOCATION_CLIENT_ID);
		
		UriBuilder uriBuilder = UriBuilder.fromPath(baseUrl + uri);
		uriBuilder.queryParam(AssuranceEngineConstants.MARKET_LOCATION_PARAM_CLIENT_ID, String.valueOf(clientId));
		Arrays.fill(clientId, Character.MIN_VALUE);
		
		for (String key : params.keySet())
		{
			uriBuilder.queryParam(key, params.get(key));
		}

		char[] token = new PasswordUtils().getSecrete(AssuranceEngineConstants.PROPERTY_MARKET_LOCATION_TOKEN);

		Response response = this.webClient.target(uriBuilder).request()
				.header(HttpHeaders.AUTHORIZATION, "Bearer " + String.valueOf(token)).get();
		Arrays.fill(token, Character.MIN_VALUE);
		return response;
	}

}
