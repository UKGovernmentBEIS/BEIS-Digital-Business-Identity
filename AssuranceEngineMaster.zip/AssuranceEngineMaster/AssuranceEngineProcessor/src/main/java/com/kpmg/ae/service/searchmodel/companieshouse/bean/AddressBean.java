/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AddressBean
{
	@JsonProperty("locality")
	String locality;

	@JsonProperty("premises")
	String premises;

	@JsonProperty("address_line_1")
	String addressLine1;

	@JsonProperty("address_line_2")
	String addressLine2;

	@JsonProperty("postal_code")
	String postalCode;

	@JsonProperty("care_of")
	String careOf;

	@JsonProperty("country")
	String country;

	@JsonProperty("po_box")
	String poBox;

	@JsonProperty("region")
	String region;

	@JsonProperty("care_of_name")
	String careOfName;

	public String getLocality()
	{
		return locality;
	}

	public void setLocality(String locality)
	{
		this.locality = locality;
	}

	public String getPremises()
	{
		return premises;
	}

	public void setPremises(String premises)
	{
		this.premises = premises;
	}

	public String getCountry()
	{
		return country;
	}

	public void setCountry(String country)
	{
		this.country = country;
	}

	public String getRegion()
	{
		return region;
	}

	public void setRegion(String region)
	{
		this.region = region;
	}

	public String getAddressLine1()
	{
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1)
	{
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2()
	{
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2)
	{
		this.addressLine2 = addressLine2;
	}

	public String getPostalCode()
	{
		return postalCode;
	}

	public void setPostalCode(String postalCode)
	{
		this.postalCode = postalCode;
	}

	public String getCareOf()
	{
		return careOf;
	}

	public void setCareOf(String careOf)
	{
		this.careOf = careOf;
	}

	public String getPoBox()
	{
		return poBox;
	}

	public void setPoBox(String poBox)
	{
		this.poBox = poBox;
	}

	public String getCareOfName()
	{
		return careOfName;
	}

	public void setCareOfName(String careOfName)
	{
		this.careOfName = careOfName;
	}

	@Override
	public String toString()
	{
		return "AddressSearchBean [locality=" + locality + ", premises=" + premises + ", addressLine1=" + addressLine1
				+ ", addressLine2=" + addressLine2 + ", postalCode=" + postalCode + ", careOf=" + careOf + ", country="
				+ country + ", poBox=" + poBox + ", region=" + region + "]";
	}
}
