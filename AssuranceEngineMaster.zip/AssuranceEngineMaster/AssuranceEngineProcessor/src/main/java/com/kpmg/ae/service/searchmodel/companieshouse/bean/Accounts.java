/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Accounts
{

	@JsonProperty("account_period_from")
	private AccountPeriodFrom accountPeriodFrom;
	@JsonProperty("account_period_to")
	private AccountPeriodTo accountPeriodTo;
	@JsonProperty("must_file_within")
	private MustFileWithin mustFileWithin;
	@JsonProperty("next_accounts")
	private NextAccounts nextAccounts;

	@JsonProperty("next_made_up_to")
	private String nextMadeUpTo;
	private String overdue;
	@JsonProperty("next_due")
	private String nextDue;
	@JsonProperty("accounting_reference_date")
	private AccountingReferenceDate accountingReferenceDate;
	@JsonProperty("last_accounts")
	private LastAccounts lastAccount;

	public void setAccountPeriodFrom(AccountPeriodFrom accountPeriodFrom)
	{
		this.accountPeriodFrom = accountPeriodFrom;
	}

	public AccountPeriodFrom getAccountPeriodFrom()
	{
		return accountPeriodFrom;
	}

	public void setAccountPeriodTo(AccountPeriodTo accountPeriodTo)
	{
		this.accountPeriodTo = accountPeriodTo;
	}

	public AccountPeriodTo getAccountPeriodTo()
	{
		return accountPeriodTo;
	}

	public void setMustFileWithin(MustFileWithin mustFileWithin)
	{
		this.mustFileWithin = mustFileWithin;
	}

	public MustFileWithin getMustFileWithin()
	{
		return mustFileWithin;
	}

	public NextAccounts getNextAccounts()
	{
		return nextAccounts;
	}

	public void setNextAccounts(NextAccounts nextAccounts)
	{
		this.nextAccounts = nextAccounts;
	}

	public String getNextMadeUpTo()
	{
		return nextMadeUpTo;
	}

	public void setNextMadeUpTo(String nextMadeUpTo)
	{
		this.nextMadeUpTo = nextMadeUpTo;
	}

	public String getOverdue()
	{
		return overdue;
	}

	public void setOverdue(String overdue)
	{
		this.overdue = overdue;
	}

	public String getNextDue()
	{
		return nextDue;
	}

	public void setNextDue(String nextDue)
	{
		this.nextDue = nextDue;
	}

	public AccountingReferenceDate getAccountingReferenceDate()
	{
		return accountingReferenceDate;
	}

	public void setAccountingReferenceDate(AccountingReferenceDate accountingReferenceDate)
	{
		this.accountingReferenceDate = accountingReferenceDate;
	}

	public LastAccounts getLastAccount()
	{
		return lastAccount;
	}

	public void setLastAccount(LastAccounts lastAccount)
	{
		this.lastAccount = lastAccount;
	}

}
