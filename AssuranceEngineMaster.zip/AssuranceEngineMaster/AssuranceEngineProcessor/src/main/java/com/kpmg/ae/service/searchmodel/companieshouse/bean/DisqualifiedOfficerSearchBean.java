/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DisqualifiedOfficerSearchBean
{

	@JsonProperty("address")
	AddressBean address;

	@JsonProperty("description")
	String description;

	@JsonProperty("date_of_birth")
	Date dateOfBirth;

	@JsonProperty("links")
	LinksBean links;

	@JsonProperty("title")
	String title;

	@JsonProperty("address_snippet")
	String addressSnippet;

	@JsonProperty("kind")
	String kind;

	@JsonProperty("officer_role")
	String officerRole;

	@JsonProperty("resigned_on")
	Date resignedOn;

	@JsonProperty("description_identifiers")
	SearchDescriptions[] descriptionIdentifiers;

	Matches matches;

	@JsonProperty("snippet")
	String snippet;

	public AddressBean getAddress()
	{
		return address;
	}

	public void setAddress(AddressBean address)
	{
		this.address = address;
	}

	public Date getDateOfBirth()
	{
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth)
	{
		this.dateOfBirth = dateOfBirth;
	}

	public String getDescription()
	{
		return description;
	}

	public void setDescription(String description)
	{
		this.description = description;
	}

	public LinksBean getLinks()
	{
		return links;
	}

	public void setLinks(LinksBean links)
	{
		this.links = links;
	}

	public String getTitle()
	{
		return title;
	}

	public void setTitle(String title)
	{
		this.title = title;
	}

	public String getAddressSnippet()
	{
		return addressSnippet;
	}

	public void setAddressSnippet(String addressSnippet)
	{
		this.addressSnippet = addressSnippet;
	}

	public String getKind()
	{
		return kind;
	}

	public void setKind(String kind)
	{
		this.kind = kind;
	}

	public SearchDescriptions[] getDescriptionIdentifiers()
	{
		return descriptionIdentifiers;
	}

	public void setDescriptionIdentifiers(SearchDescriptions[] descriptionIdentifiers)
	{
		this.descriptionIdentifiers = descriptionIdentifiers;
	}

	public Matches getMatches()
	{
		return matches;
	}

	public void setMatches(Matches matches)
	{
		this.matches = matches;
	}

	public String getSnippet()
	{
		return snippet;
	}

	public void setSnippet(String snippet)
	{
		this.snippet = snippet;
	}

	public String getOfficerRole()
	{
		return officerRole;
	}

	public void setOfficerRole(String officerRole)
	{
		this.officerRole = officerRole;
	}

	public Date getResignedOn()
	{
		return resignedOn;
	}

	public void setResignedOn(Date resignedOn)
	{
		this.resignedOn = resignedOn;
	}
}
