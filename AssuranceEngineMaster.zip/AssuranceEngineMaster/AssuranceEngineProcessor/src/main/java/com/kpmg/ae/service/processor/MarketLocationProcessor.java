/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.processor;

import java.util.Date;
import java.util.List;

import com.kpmg.ae.service.bean.Business;
import com.kpmg.ae.service.bean.Company;
import com.kpmg.ae.service.bean.MarketLocationBean;
import com.kpmg.ae.service.constants.AssuranceEngineConstants;
import com.kpmg.ae.service.factory.AssuranceEngineServiceFactory;
import com.kpmg.ae.service.rs.intf.MarketLocationService;
import com.kpmg.ae.service.utilities.AssuranceEngineUtility;

public class MarketLocationProcessor
{

	MarketLocationService mlService;

	public MarketLocationProcessor()
	{
		super();
		this.mlService = (MarketLocationService) AssuranceEngineServiceFactory.getService(MarketLocationService.class);
	}

	public MarketLocationBean getMLDataForCompany(String companyName)
	{
		return mlService.getMLDataForCompany(companyName);
	}

	/**
	 * @purpose Verify business turnover and number of employee with Market Location
	 * 
	 * @param business
	 */
	public void verifyWithML(Business business)
	{
		String businessName = business.getBusinessName().getValue();

		MarketLocationBean mlBean = getMLDataForCompany(businessName);
		if (mlBean == null)
		{
			System.out.println("No company with name " + businessName
					+ " is available in MarketLocation database. Updating as unverified.");
		}
		else
		{
			String mlTurnOver = mlBean.getModelledTurnover();
			String bTurnover = business.getBusinessTurnOver().getValue();
			if (AssuranceEngineUtility.isNullOrEmptyString(bTurnover))
			{
				System.out.println(
						"No turnover has been reported in the incoming business object. Skipping verification for turnover.");
			}
			else
			{
				if (Double.valueOf(bTurnover).compareTo(Double.valueOf(mlTurnOver)) == 0)
				{
					business.getBusinessTurnOver().setVerifiedDate(AssuranceEngineUtility.formatDate(new Date()));
					business.getBusinessTurnOver()
							.setVerificationSource(AssuranceEngineConstants.VERIFICATION_SOURCE_MARKETLOCATION);
				}
				else
				{
					business.getBusinessTurnOver().setVerifiedDate(null);
					business.getBusinessTurnOver().setVerificationSource("");
					System.out.println(
							"The turnover number does not match. The process will not set verification date and source from this.");
				}
			}

			String mlNoOfEmp = mlBean.getNoOfEmployees();
			String bNoOfEmp = business.getNoOfEmployees().getValue();
			if (AssuranceEngineUtility.isNullOrEmptyString(bNoOfEmp))
			{
				System.out.println(
						"No. of employees is not reported in the incoming business object. Skipping verification for employees.");
			}
			else
			{
				if (bNoOfEmp.equals(mlNoOfEmp))
				{
					business.getNoOfEmployees().setVerifiedDate(AssuranceEngineUtility.formatDate(new Date()));
					business.getNoOfEmployees()
							.setVerificationSource(AssuranceEngineConstants.VERIFICATION_SOURCE_MARKETLOCATION);
				}
				else
				{
					business.getNoOfEmployees().setVerifiedDate(null);
					business.getNoOfEmployees().setVerificationSource("");
					System.out.println(
							"The turnover number does not match. The process will not set verification date and source from this.");
				}
			}
		}
	}

	public void getAdditionalInfo(List<Company> companiesList)
	{
		for (Company company : companiesList)
		{
			mlService.getAdditionalInfoFromMarketLocation(company);
		}
	}
}
