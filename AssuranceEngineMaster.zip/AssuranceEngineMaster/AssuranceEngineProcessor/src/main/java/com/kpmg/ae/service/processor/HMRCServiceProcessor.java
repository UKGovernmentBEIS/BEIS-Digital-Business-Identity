/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.processor;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import com.kpmg.ae.service.bean.Business;
import com.kpmg.ae.service.bean.BusinessPAYE;
import com.kpmg.ae.service.bean.BusinessUTR;
import com.kpmg.ae.service.bean.BusinessVAT;
import com.kpmg.ae.service.bean.ChBusinessId;
import com.kpmg.ae.service.bean.Company;
import com.kpmg.ae.service.constants.AssuranceEngineConstants;
import com.kpmg.ae.service.factory.AssuranceEngineServiceFactory;
import com.kpmg.ae.service.rs.intf.HMRCService;
import com.kpmg.ae.service.utilities.AssuranceEngineUtility;

public class HMRCServiceProcessor
{
	private HMRCService hmrcService;

	public HMRCServiceProcessor() throws IOException, ParseException
	{
		hmrcService = (HMRCService) AssuranceEngineServiceFactory.getService(HMRCService.class);
	}

	/**
	 * @purpose Verify UTR, PAYE, VAT, number of employees, turnover of business
	 * @since January 22, 2020 
	 * @param businessObject
	 */
	public void verifyWithHMRC(Business businessObject)
	{
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(AssuranceEngineConstants.DATE_FORMAT);

		ChBusinessId businessCompanyNumber = businessObject.getChBusinessId();

		if (!AssuranceEngineUtility.isNullOrEmptyString(businessCompanyNumber.getVerifiedDate()))
		{

			JSONObject hmrcBusinessJsonObj = hmrcService
					.findCompanyDetailsByCompanyNumber(businessCompanyNumber.getValue());

			if (null != hmrcBusinessJsonObj)
			{

				BusinessUTR businessUTR = businessObject.getBusinessUTR();
				BusinessPAYE businessPAYE = businessObject.getBusinessPAYE();
				BusinessVAT businessVAT = businessObject.getBusinessVAT();
				

				/*
				 * verify UTR
				 */
				String hmrcUTR = (String) hmrcBusinessJsonObj.get(AssuranceEngineConstants.COMPANY_UTR);
				if (!AssuranceEngineUtility.isNullOrEmptyString(hmrcUTR)
						&& businessUTR.getValue().equalsIgnoreCase(hmrcUTR))
				{
					businessUTR.setVerifiedDate(simpleDateFormat.format(new Date()));
					businessUTR.setVerificationSource(AssuranceEngineConstants.HMRC);
				}
				else
				{
					businessUTR.setVerifiedDate(null);
					businessUTR.setVerificationSource("");
				}

				/*
				 * Verify PAYE
				 */
				String hmrcPAYE = (String) hmrcBusinessJsonObj.get(AssuranceEngineConstants.COMPANY_PAYE);
				if (!AssuranceEngineUtility.isNullOrEmptyString(hmrcPAYE)
						&& businessPAYE.getValue().equalsIgnoreCase(hmrcPAYE))
				{
					businessPAYE.setVerifiedDate(simpleDateFormat.format(new Date()));
					businessPAYE.setVerificationSource(AssuranceEngineConstants.HMRC);
				}
				else
				{
					businessPAYE.setVerifiedDate(null);
					businessPAYE.setVerificationSource("");
				}

				/*
				 * Verify VAT
				 */
				String hmrcVAT = (String) hmrcBusinessJsonObj.get(AssuranceEngineConstants.COMPANY_VAT);
				if (!AssuranceEngineUtility.isNullOrEmptyString(hmrcVAT)
						&& businessVAT.getValue().equalsIgnoreCase(hmrcVAT))
				{
					businessVAT.setVerifiedDate(simpleDateFormat.format(new Date()));
					businessVAT.setVerificationSource(AssuranceEngineConstants.HMRC);
				}
				else
				{
					businessVAT.setVerifiedDate(null);
					businessVAT.setVerificationSource("");
				}
			}
		}
		
	}
	
	public void getAdditionalInfo(List<Company> companiesList) 
	{
		for(Company company : companiesList) 
		{
			hmrcService.getAdditionalInfoFromHMRC(company);
		}
	}
}
