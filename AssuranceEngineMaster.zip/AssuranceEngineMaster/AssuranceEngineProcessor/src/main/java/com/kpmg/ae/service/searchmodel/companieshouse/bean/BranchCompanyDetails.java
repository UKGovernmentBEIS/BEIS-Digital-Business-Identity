/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BranchCompanyDetails
{

	@JsonProperty("business_activity")
	private String businessActivity;
	@JsonProperty("parent_company_name")
	private String parentCompanyName;
	@JsonProperty("parent_company_number")
	private String parentCompanyNumber;

	public void setBusinessActivity(String businessActivity)
	{
		this.businessActivity = businessActivity;
	}

	public String getBusinessActivity()
	{
		return businessActivity;
	}

	public void setParentCompanyName(String parentCompanyName)
	{
		this.parentCompanyName = parentCompanyName;
	}

	public String getParentCompanyName()
	{
		return parentCompanyName;
	}

	public void setParentCompanyNumber(String parentCompanyNumber)
	{
		this.parentCompanyNumber = parentCompanyNumber;
	}

	public String getParentCompanyNumber()
	{
		return parentCompanyNumber;
	}

}
