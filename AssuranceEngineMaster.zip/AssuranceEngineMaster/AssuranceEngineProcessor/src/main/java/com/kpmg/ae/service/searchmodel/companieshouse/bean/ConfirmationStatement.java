/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ConfirmationStatement
{

	@JsonProperty("last_made_up_to")
	private String lastMadeUpTo;
	@JsonProperty("next_due")
	private String nextDue;
	@JsonProperty("next_made_up_to")
	private String nextMadeUpTo;
	private String overdue;

	public void setLastMadeUpTo(String lastMadeUpTo)
	{
		this.lastMadeUpTo = lastMadeUpTo;
	}

	public String getLastMadeUpTo()
	{
		return lastMadeUpTo;
	}

	public void setNextDue(String nextDue)
	{
		this.nextDue = nextDue;
	}

	public String getNextDue()
	{
		return nextDue;
	}

	public void setNextMadeUpTo(String nextMadeUpTo)
	{
		this.nextMadeUpTo = nextMadeUpTo;
	}

	public String getNextMadeUpTo()
	{
		return nextMadeUpTo;
	}

	public void setOverdue(String overdue)
	{
		this.overdue = overdue;
	}

	public String getOverdue()
	{
		return overdue;
	}

}
