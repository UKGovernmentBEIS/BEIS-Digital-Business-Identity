/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.processor;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import com.kpmg.ae.service.bean.AccountNumber;
import com.kpmg.ae.service.bean.Business;
import com.kpmg.ae.service.bean.ChBusinessId;
import com.kpmg.ae.service.bean.Company;
import com.kpmg.ae.service.bean.Sortcode;
import com.kpmg.ae.service.constants.AssuranceEngineConstants;
import com.kpmg.ae.service.factory.AssuranceEngineServiceFactory;
import com.kpmg.ae.service.rs.intf.LloydsBankingService;
import com.kpmg.ae.service.utilities.AssuranceEngineUtility;

public class LloydsBankingServiceProcessor
{
	private LloydsBankingService lloydsBankingService;

	public LloydsBankingServiceProcessor() throws IOException, ParseException
	{
		lloydsBankingService = (LloydsBankingService) AssuranceEngineServiceFactory.getService(LloydsBankingService.class);
	}

	/**
	 * @purpose Verify business banking details from Lloyds Bank Service
	 * @since January 22, 2020
	 * @param businessObject
	 */
	public void verifyWithLloydsBanking(Business businessObject)
	{
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(AssuranceEngineConstants.DATE_FORMAT);

		ChBusinessId businessCompanyNumber = businessObject.getChBusinessId();

		if (!AssuranceEngineUtility.isNullOrEmptyString(businessCompanyNumber.getVerifiedDate()))
		{

			Sortcode businessSortcode = businessObject.getBusinessBankDetails().getSortcode();
			AccountNumber businessAccountNumber = businessObject.getBusinessBankDetails().getAccountNumber();

			JSONObject lloydsJSONObject = lloydsBankingService
					.findCompanyDetailsByCompanyNumber(businessCompanyNumber.getValue());

			if (null != lloydsJSONObject)
			{
				String lloydsSortCode = (String) lloydsJSONObject.get(AssuranceEngineConstants.SORT_CODE);
				String lloydsAccountNumber = (String) lloydsJSONObject.get(AssuranceEngineConstants.ACCOUNT_NUMBER);

				if (!AssuranceEngineUtility.isNullOrEmptyString(lloydsSortCode)
						&& lloydsSortCode.equalsIgnoreCase(businessSortcode.getValue()))
				{
					businessSortcode.setVerifiedDate(simpleDateFormat.format(new Date()));
					businessSortcode.setVerificationSource(AssuranceEngineConstants.LLOYDS);
				}
				else
				{
					businessSortcode.setVerifiedDate(null);
					businessSortcode.setVerificationSource("");
				}

				if (!AssuranceEngineUtility.isNullOrEmptyString(lloydsAccountNumber)
						&& lloydsAccountNumber.equalsIgnoreCase(businessAccountNumber.getValue()))
				{
					businessAccountNumber.setVerifiedDate(simpleDateFormat.format(new Date()));
					businessAccountNumber.setVerificationSource(AssuranceEngineConstants.LLOYDS);
				}
				else
				{
					businessAccountNumber.setVerifiedDate(null);
					businessAccountNumber.setVerificationSource("");
				}
			}
		}
	}
	
	public void getAdditionalInfo(List<Company> companiesList) 
	{
		for(Company company : companiesList) 
		{
			lloydsBankingService.getAdditionalInfoFromLBService(company);
		}
	}
}
