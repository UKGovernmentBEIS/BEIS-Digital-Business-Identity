/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.bean;

public class MarketLocationBean
{

	private String errorMessage;
	private String businessName;
	private String noOfEmployees;
	private String recorded_turnover;
	private String total_liabilities;
	private String networth;
	private String email;
	private String modelled_turnover;
	private String sic_code;

	public String getErrorMessage()
	{
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage)
	{
		this.errorMessage = errorMessage;
	}

	public String getBusinessName()
	{
		return businessName;
	}

	public void setBusinessName(String businessName)
	{
		this.businessName = businessName;
	}

	public String getNoOfEmployees()
	{
		return noOfEmployees;
	}

	public void setNoOfEmployees(String noOfEmployees)
	{
		this.noOfEmployees = noOfEmployees;
	}

	public String getRecordedTurnover()
	{
		return recorded_turnover;
	}

	public void setRecordedTurnover(String recorded_turnover)
	{
		this.recorded_turnover = recorded_turnover;
	}

	public String getTotalLiabilities()
	{
		return total_liabilities;
	}

	public void setTotalLiabilities(String total_liabilities)
	{
		this.total_liabilities = total_liabilities;
	}

	public String getNetworth()
	{
		return networth;
	}

	public void setNetworth(String networth)
	{
		this.networth = networth;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public String getModelledTurnover()
	{
		return modelled_turnover;
	}

	public void setModelledTurnover(String modelled_turnover)
	{
		this.modelled_turnover = modelled_turnover;
	}

	public String getSicCode()
	{
		return sic_code;
	}

	public void setSicCode(String sic_code)
	{
		this.sic_code = sic_code;
	}

}
