/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class NaturalDisqualifiedOfficer
{

	@JsonProperty("date_of_birth")
	private Date dateOfBirth;
	private List<Disqualifications> disqualifications;
	private String etag;
	private String forename;
	private String honours;
	private String kind;
	private Links links;
	private String nationality;
	@JsonProperty("other_forenames")
	private String otherForenames;
	@JsonProperty("permissions_to_act")
	private List<PermissionsToAct> permissionsToAct;
	private String surname;
	private String title;

	public void setDateOfBirth(Date dateOfBirth)
	{
		this.dateOfBirth = dateOfBirth;
	}

	public Date getDateOfBirth()
	{
		return dateOfBirth;
	}

	public void setDisqualifications(List<Disqualifications> disqualifications)
	{
		this.disqualifications = disqualifications;
	}

	public List<Disqualifications> getDisqualifications()
	{
		return disqualifications;
	}

	public void setEtag(String etag)
	{
		this.etag = etag;
	}

	public String getEtag()
	{
		return etag;
	}

	public void setForename(String forename)
	{
		this.forename = forename;
	}

	public String getForename()
	{
		return forename;
	}

	public void setHonours(String honours)
	{
		this.honours = honours;
	}

	public String getHonours()
	{
		return honours;
	}

	public void setKind(String kind)
	{
		this.kind = kind;
	}

	public String getKind()
	{
		return kind;
	}

	public void setLinks(Links links)
	{
		this.links = links;
	}

	public Links getLinks()
	{
		return links;
	}

	public void setNationality(String nationality)
	{
		this.nationality = nationality;
	}

	public String getNationality()
	{
		return nationality;
	}

	public void setOtherForenames(String otherForenames)
	{
		this.otherForenames = otherForenames;
	}

	public String getOtherForenames()
	{
		return otherForenames;
	}

	public void setPermissionsToAct(List<PermissionsToAct> permissionsToAct)
	{
		this.permissionsToAct = permissionsToAct;
	}

	public List<PermissionsToAct> getPermissionsToAct()
	{
		return permissionsToAct;
	}

	public void setSurname(String surname)
	{
		this.surname = surname;
	}

	public String getSurname()
	{
		return surname;
	}

	public void setTitle(String title)
	{
		this.title = title;
	}

	public String getTitle()
	{
		return title;
	}
}
