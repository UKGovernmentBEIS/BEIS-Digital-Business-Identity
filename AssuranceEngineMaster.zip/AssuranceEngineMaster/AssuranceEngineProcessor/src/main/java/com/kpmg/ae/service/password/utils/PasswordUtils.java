/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.password.utils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Properties;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.iv.RandomIvGenerator;
import org.jasypt.properties.EncryptableProperties;

import com.kpmg.ae.service.constants.AssuranceEngineConstants;
import com.kpmg.ae.service.utilities.AssuranceEngineUtility;

public class PasswordUtils
{
	private Properties serverConfig = null;

	public PasswordUtils() throws IOException
	{
		final String ALGORITHM = AssuranceEngineConstants.PBE_WITH_HMACSHA512_AND_AES_256;
		final String MASTER_KEY = "<ENCODED_MASTERKEY>";
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		encryptor.setPassword(decodeInput(MASTER_KEY));
		encryptor.setAlgorithm(ALGORITHM);
		encryptor.setIvGenerator(new RandomIvGenerator());
		serverConfig = new EncryptableProperties(encryptor);
		InputStream inStream = this.getClass().getClassLoader().getResourceAsStream(AssuranceEngineConstants.SERVERCONFIG_PROPERTIES);
		serverConfig.load(inStream);

		if (serverConfig.isEmpty())
		{
			throw new IOException("Error while reading serverconfig.properties");
		}
	}

	public char[] getSecrete(String referenceProperty) throws IOException
	{
		char[] returnResult = null;

		if (!AssuranceEngineUtility.isNullOrEmptyString(referenceProperty))
		{
			if (null == serverConfig || serverConfig.isEmpty())
			{
				throw new IOException("Error while reading serverconfig.properties");
			}
			returnResult = serverConfig.getProperty(referenceProperty).toCharArray();
		}

		return returnResult;
	}

	private String decodeInput(String input)
	{
		return new String(Base64.getDecoder().decode(input), StandardCharsets.UTF_8);
	}
}
