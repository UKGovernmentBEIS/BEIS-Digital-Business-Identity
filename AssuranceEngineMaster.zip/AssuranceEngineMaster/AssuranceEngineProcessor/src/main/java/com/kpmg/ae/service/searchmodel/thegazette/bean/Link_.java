/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.thegazette.bean;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "@href", "@rel", "@title", "@type" })
public class Link_
{

	@JsonProperty("@href")
	private String href;
	@JsonProperty("@rel")
	private String rel;
	@JsonProperty("@title")
	private String title;
	@JsonProperty("@type")
	private String type;

	@JsonProperty("@href")
	public String getHref()
	{
		return href;
	}

	@JsonProperty("@href")
	public void setHref(String href)
	{
		this.href = href;
	}

	@JsonProperty("@rel")
	public String getRel()
	{
		return rel;
	}

	@JsonProperty("@rel")
	public void setRel(String rel)
	{
		this.rel = rel;
	}

	@JsonProperty("@title")
	public String getTitle()
	{
		return title;
	}

	@JsonProperty("@title")
	public void setTitle(String title)
	{
		this.title = title;
	}

	@JsonProperty("@type")
	public String getType()
	{
		return type;
	}

	@JsonProperty("@type")
	public void setType(String type)
	{
		this.type = type;
	}
}
