/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.searchmodel.companieshouse.bean;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Disqualifications
{

	private AddressBean address;
	@JsonProperty("case_identifier")
	private String caseIdentifier;
	@JsonProperty("company_names")
	private List<String> companyNames;
	@JsonProperty("court_name")
	private String courtName;
	@JsonProperty("disqualification_type")
	private String disqualificationType;
	@JsonProperty("disqualified_from")
	private Date disqualifiedFrom;
	@JsonProperty("disqualified_until")
	private Date disqualifiedUntil;
	@JsonProperty("heard_on")
	private Date heardOn;
	@JsonProperty("last_variation")
	private LastVariation lastVariation;
	private Reason reason;
	@JsonProperty("undertaken_on")
	private Date undertakenOn;

	public void setAddress(AddressBean address)
	{
		this.address = address;
	}

	public AddressBean getAddress()
	{
		return address;
	}

	public void setCaseIdentifier(String caseIdentifier)
	{
		this.caseIdentifier = caseIdentifier;
	}

	public String getCaseIdentifier()
	{
		return caseIdentifier;
	}

	public void setCompanyNames(List<String> companyNames)
	{
		this.companyNames = companyNames;
	}

	public List<String> getCompanyNames()
	{
		return companyNames;
	}

	public void setCourtName(String courtName)
	{
		this.courtName = courtName;
	}

	public String getCourtName()
	{
		return courtName;
	}

	public void setDisqualificationType(String disqualificationType)
	{
		this.disqualificationType = disqualificationType;
	}

	public String getDisqualificationType()
	{
		return disqualificationType;
	}

	public void setDisqualifiedFrom(Date disqualifiedFrom)
	{
		this.disqualifiedFrom = disqualifiedFrom;
	}

	public Date getDisqualifiedFrom()
	{
		return disqualifiedFrom;
	}

	public void setDisqualifiedUntil(Date disqualifiedUntil)
	{
		this.disqualifiedUntil = disqualifiedUntil;
	}

	public Date getDisqualifiedUntil()
	{
		return disqualifiedUntil;
	}

	public void setHeardOn(Date heardOn)
	{
		this.heardOn = heardOn;
	}

	public Date getHeardOn()
	{
		return heardOn;
	}

	public void setLastVariation(LastVariation lastVariation)
	{
		this.lastVariation = lastVariation;
	}

	public LastVariation getLastVariation()
	{
		return lastVariation;
	}

	public void setReason(Reason reason)
	{
		this.reason = reason;
	}

	public Reason getReason()
	{
		return reason;
	}

	public void setUndertakenOn(Date undertakenOn)
	{
		this.undertakenOn = undertakenOn;
	}

	public Date getUndertakenOn()
	{
		return undertakenOn;
	}

}
