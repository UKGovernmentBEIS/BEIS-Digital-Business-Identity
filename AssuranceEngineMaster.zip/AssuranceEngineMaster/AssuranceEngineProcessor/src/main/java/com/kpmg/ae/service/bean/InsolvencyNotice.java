/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.bean;

public class InsolvencyNotice
{

	String noticeId;
	String noticeStatus;
	String noticeCode;
	String title;
	String term;
	String publishedOn;
	String content;
	String linkedDataReference;
	String companyNumber;

	public String getNoticeId()
	{
		return noticeId;
	}

	public void setNoticeId(String noticeId)
	{
		this.noticeId = noticeId;
	}

	public String getNoticeStatus()
	{
		return noticeStatus;
	}

	public void setNoticeStatus(String noticeStatus)
	{
		this.noticeStatus = noticeStatus;
	}

	public String getNoticeCode()
	{
		return noticeCode;
	}

	public void setNoticeCode(String noticeCode)
	{
		this.noticeCode = noticeCode;
	}

	public String getTitle()
	{
		return title;
	}

	public void setTitle(String title)
	{
		this.title = title;
	}

	public String getTerm()
	{
		return term;
	}

	public void setTerm(String term)
	{
		this.term = term;
	}

	public String getPublishedOn()
	{
		return publishedOn;
	}

	public void setPublishedOn(String publishedOn)
	{
		this.publishedOn = publishedOn;
	}

	public String getContent()
	{
		return content;
	}

	public void setContent(String content)
	{
		this.content = content;
	}

	public String getLinkedDataReference()
	{
		return linkedDataReference;
	}

	public void setLinkedDataReference(String linkedDataReference)
	{
		this.linkedDataReference = linkedDataReference;
	}

	public String getCompanyNumber()
	{
		return companyNumber;
	}

	public void setCompanyNumber(String companyNumber)
	{
		this.companyNumber = companyNumber;
	}
}
