/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.ae.service.bean;

public class PersonWithInsolvencyNoticeResponse
{
	String insolvencyNoticeLink;
	String lastName;
	String firstName;
	String postCode;
	String category;
	boolean isDisqualified;
	boolean hasInsolvencyNotices;

	public PersonWithInsolvencyNoticeResponse()
	{
		isDisqualified = false;
		hasInsolvencyNotices = false;
	}

	public String getInsolvencyNoticeLink()
	{
		return insolvencyNoticeLink;
	}

	public void setInsolvencyNoticeLink(String insolvencyNoticeLink)
	{
		this.insolvencyNoticeLink = insolvencyNoticeLink;
	}

	public String getLastName()
	{
		return lastName;
	}

	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	public String getFirstName()
	{
		return firstName;
	}

	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	public String getPostCode()
	{
		return postCode;
	}

	public void setPostCode(String postCode)
	{
		this.postCode = postCode;
	}

	public String getCategory()
	{
		return category;
	}

	public void setCategory(String category)
	{
		this.category = category;
	}

	public boolean isDisqualified()
	{
		return isDisqualified;
	}

	public void setDisqualified(boolean isDisqualified)
	{
		this.isDisqualified = isDisqualified;
	}

	public boolean isHasInsolvencyNotices()
	{
		return hasInsolvencyNotices;
	}

	public void setHasInsolvencyNotices(boolean hasInsolvencyNotices)
	{
		this.hasInsolvencyNotices = hasInsolvencyNotices;
	}

	@Override
	public String toString()
	{
		return "PersonWithInsolvencyNoticeResponse [insolvencyNoticeLink=" + insolvencyNoticeLink + ", lastName="
				+ lastName + ", firstName=" + firstName + ", postCode=" + postCode + ", category=" + category
				+ ", isDisqualified=" + isDisqualified + ", hasInsolvencyNotices=" + hasInsolvencyNotices + "]";
	}

}
