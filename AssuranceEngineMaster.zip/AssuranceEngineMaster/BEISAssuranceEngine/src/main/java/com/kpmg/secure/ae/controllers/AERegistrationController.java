/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.secure.ae.controllers;

import java.util.Date;
import java.util.Random;

import javax.naming.NamingException;
import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kpmg.secure.ae.beans.RegistrationResponse;
import com.kpmg.secure.ae.processor.LDAPProcessor;
import com.kpmg.secure.ae.utils.SecurityConstants;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@RestController
@Consumes(MediaType.APPLICATION_XML)
@Produces(MediaType.APPLICATION_JSON)
public class AERegistrationController
{

	private static final String TYP = "typ";
	private static final String APPLICATION_NAME = "applicationName";
	private static final String API_REGISTER = "/api/register";

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PostMapping
	@Path(API_REGISTER)
	@Consumes(MediaType.APPLICATION_JSON)
	public ResponseEntity<RegistrationResponse> registerForAEAPIs(@QueryParam(APPLICATION_NAME) String applicationName)
	{
		RegistrationResponse response = null;
		if (applicationName != null)
		{
			response = new RegistrationResponse();

			byte[] signingKey = SecurityConstants.JWT_SECRET.getBytes();
			String token = Jwts.builder().signWith(Keys.hmacShaKeyFor(signingKey), SignatureAlgorithm.HS512)
					.setHeaderParam(TYP, SecurityConstants.TOKEN_TYPE).setIssuer(SecurityConstants.TOKEN_ISSUER)
					.setAudience(SecurityConstants.TOKEN_AUDIENCE).setSubject(applicationName)
					.setExpiration(new Date(System.currentTimeMillis() + 864000000)).compact();

			String client_key = generateRandomKey();

			if (createApplicationAccount(applicationName, client_key))
			{
				response.setClientKey(client_key);
				response.setAuthorisationToken(token);
				return new ResponseEntity<RegistrationResponse>(response, HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		else
		{
			return new ResponseEntity(HttpStatus.BAD_REQUEST);
		}
	}

	private boolean createApplicationAccount(String applicationName, String client_key)
	{
		boolean result = false;
		LDAPProcessor regProcessor = new LDAPProcessor();
		try
		{
			result = regProcessor.createNewDevice(applicationName, client_key);
		}
		catch (NamingException e)
		{
			e.printStackTrace();
		}
		return result;
	}

	private String generateRandomKey()
	{
		int leftLimit = 48; // numeral '0'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 32;
		Random random = new Random();

		String generatedString = random.ints(leftLimit, rightLimit + 1)
				.filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97)).limit(targetStringLength)
				.collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append).toString();
		return generatedString;
	}

}
