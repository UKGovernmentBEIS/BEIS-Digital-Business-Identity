/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.secure.ae.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpmg.ae.service.bean.Business;
import com.kpmg.ae.service.bean.Company;
import com.kpmg.ae.service.bean.CompanyOfficer;
import com.kpmg.ae.service.bean.CompanyOwnerResponse;
import com.kpmg.ae.service.bean.InsolvencyNotice;
import com.kpmg.ae.service.bean.PersonWithInsolvencyNoticeResponse;
import com.kpmg.ae.service.bean.PersonWithSignificantControl;
import com.kpmg.ae.service.processor.CompaniesHouseServiceProcessor;
import com.kpmg.ae.service.processor.DnBServiceProcessor;
import com.kpmg.ae.service.processor.HMRCServiceProcessor;
import com.kpmg.ae.service.processor.LloydsBankingServiceProcessor;
import com.kpmg.ae.service.processor.MarketLocationProcessor;
import com.kpmg.ae.service.processor.RiskAnalyser;
import com.kpmg.ae.service.processor.TheGazetteServiceProcessor;
import com.kpmg.secure.ae.utils.SecurityConstants;


@RestController
@RequestMapping(SecurityConstants.API_V1)
@Consumes(MediaType.APPLICATION_XML)
@Produces(MediaType.APPLICATION_JSON)
public class AssuranceEngineController
{

	@GetMapping(path = SecurityConstants.SEARCH_COMPANY_BY_NAME, params = SecurityConstants.SEARCH_STRING)
	public @ResponseBody ResponseEntity<Object> searchCompanyByCompanyName(
			@QueryParam(value = SecurityConstants.SEARCH_STRING) String searchString)
	{
		List<Company> listOfCompanies = new ArrayList<Company>();
		ResponseEntity<Object> response = null;
		HttpStatus httpResponseStatus = HttpStatus.INTERNAL_SERVER_ERROR;
		try
		{
			CompaniesHouseServiceProcessor companiesHouseServiceProcessor = new CompaniesHouseServiceProcessor();

			listOfCompanies = companiesHouseServiceProcessor.searchCompaniesByName(searchString);
			HMRCServiceProcessor hmrcServiceProcessor = new HMRCServiceProcessor();
			hmrcServiceProcessor.getAdditionalInfo(listOfCompanies);

			DnBServiceProcessor dnbServiceProcessor = new DnBServiceProcessor();
			dnbServiceProcessor.getAdditionalInfo(listOfCompanies);

			LloydsBankingServiceProcessor lloydsBankingServiceProcessor = new LloydsBankingServiceProcessor();
			lloydsBankingServiceProcessor.getAdditionalInfo(listOfCompanies);

			MarketLocationProcessor mlProcessor = new MarketLocationProcessor();
			mlProcessor.getAdditionalInfo(listOfCompanies);

			httpResponseStatus = HttpStatus.OK;

		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		response = new ResponseEntity<Object>(listOfCompanies, httpResponseStatus);
		return response;
	}

	@GetMapping(path = SecurityConstants.SEARCH_OFFICERS_BY_COMPANY_NUMBER_LINK, params = SecurityConstants.SEARCH_STRING)
	public @ResponseBody ResponseEntity<Object> findOfficersByCompanyNumber(
			@RequestParam(value = SecurityConstants.SEARCH_STRING) String companyNumber)
	{

		CompaniesHouseServiceProcessor serviceProcessor = new CompaniesHouseServiceProcessor();
		List<CompanyOfficer> listOfficers = new ArrayList<CompanyOfficer>();
		ResponseEntity<Object> response = null;
		HttpStatus httpResponseStatus = HttpStatus.INTERNAL_SERVER_ERROR;

		try
		{
			listOfficers = serviceProcessor.searchOfficersByCompanyNumber(companyNumber);
			httpResponseStatus = HttpStatus.OK;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		response = new ResponseEntity<Object>(listOfficers, httpResponseStatus);
		return response;
	}

	@GetMapping(path = SecurityConstants.IS_BUSINESS_OWNER_LINK, params = { SecurityConstants.COMPANY_NUMBER,
			SecurityConstants.COMPANY_NAME, SecurityConstants.FIRST_NAME, SecurityConstants.MIDDLE_NAME, SecurityConstants.LAST_NAME,
			SecurityConstants.POST_CODE })
	public @ResponseBody ResponseEntity<Object> isBusinessOwner(
			@RequestParam(value = SecurityConstants.COMPANY_NUMBER) String companyNumber,
			@RequestParam(value = SecurityConstants.COMPANY_NAME) String companyName,
			@RequestParam(value = SecurityConstants.FIRST_NAME) String firstname,
			@RequestParam(value = SecurityConstants.MIDDLE_NAME) String middlename,
			@RequestParam(value = SecurityConstants.LAST_NAME) String surname,
			@RequestParam(value = SecurityConstants.POST_CODE) String postcode)
	{

		CompanyOwnerResponse ownerResponse = new CompanyOwnerResponse();
		ResponseEntity<Object> response = null;
		HttpStatus httpResponseStatus = HttpStatus.INTERNAL_SERVER_ERROR;
		CompaniesHouseServiceProcessor serviceProcessor = new CompaniesHouseServiceProcessor();

		try
		{
			ownerResponse = serviceProcessor.isBusinessOwner(companyNumber, companyName, firstname, middlename, surname,
					postcode);
			httpResponseStatus = HttpStatus.OK;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		response = new ResponseEntity<Object>(ownerResponse, httpResponseStatus);
		return response;
	}

	@GetMapping(path = SecurityConstants.GET_PSC_BY_CRN, params = SecurityConstants.COMPANY_NUMBER)
	public @ResponseBody ResponseEntity<Object> getCompanyPersonWithSignificantControls(
			@RequestParam(value = SecurityConstants.COMPANY_NUMBER) String companyNumber)
	{
		ResponseEntity<Object> response = null;
		List<PersonWithSignificantControl> pscList = new ArrayList<PersonWithSignificantControl>();
		HttpStatus httpResponseStatus = HttpStatus.INTERNAL_SERVER_ERROR;

		CompaniesHouseServiceProcessor serviceProcessor = new CompaniesHouseServiceProcessor();
		try
		{
			pscList = serviceProcessor.getListOfPersonWithSignificantControl(companyNumber);
			httpResponseStatus = HttpStatus.OK;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		response = new ResponseEntity<Object>(pscList, httpResponseStatus);
		return response;
	}

	@PostMapping(path = SecurityConstants.VALIDATE_BUSINESS, consumes = MediaType.APPLICATION_JSON)
	public @ResponseBody ResponseEntity<Object> verifyAttributes(HttpEntity<byte[]> requestEntity)
	{
		ResponseEntity<Object> response = null;
		Business business = null;
		HttpStatus httpResponseStatus = HttpStatus.INTERNAL_SERVER_ERROR;
		try
		{
			business = new ObjectMapper().readValue(new String(requestEntity.getBody()), Business.class);

			/*
			 * Attributes to verify from Companies house - Business name, Company Address,CRN
			 */
			CompaniesHouseServiceProcessor companiesHouseServiceProcessor = new CompaniesHouseServiceProcessor();
			companiesHouseServiceProcessor.verifyWithCompaniesHouse(business);
			/*
			 * From HMRC - UTR, VAT registration, PAYE
			 */
			HMRCServiceProcessor hmrcServiceProcessor = new HMRCServiceProcessor();
			hmrcServiceProcessor.verifyWithHMRC(business);
			/* From D&B - Dunns no */

			DnBServiceProcessor dnbServiceProcessor = new DnBServiceProcessor();
			dnbServiceProcessor.verifyWithDAndB(business);

			/* From Lloyds - Bank Details */
			LloydsBankingServiceProcessor lloydsBankingServiceProcessor = new LloydsBankingServiceProcessor();
			lloydsBankingServiceProcessor.verifyWithLloydsBanking(business);

			MarketLocationProcessor mlProcessor = new MarketLocationProcessor();
			mlProcessor.verifyWithML(business);

			RiskAnalyser riskAnalyser = new RiskAnalyser();
			riskAnalyser.getRiskScoreOfBusiness(business);

			httpResponseStatus = HttpStatus.OK;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		response = new ResponseEntity<Object>(business, httpResponseStatus);
		return response;
	}

	@GetMapping(path = SecurityConstants.GET_INSOLVENCY_NOTICES, params = { SecurityConstants.COMPANY_NUMBER,
			SecurityConstants.COMPANY_NAME })
	public @ResponseBody ResponseEntity<Object> getAllNoticesOfCompany(
			@RequestParam(value = SecurityConstants.COMPANY_NUMBER) String companyNumber,
			@RequestParam(value = SecurityConstants.COMPANY_NAME) String companyName)
	{

		ResponseEntity<Object> response = null;
		List<InsolvencyNotice> noticeList = new ArrayList<InsolvencyNotice>();
		HttpStatus httpResponseStatus = HttpStatus.INTERNAL_SERVER_ERROR;

		try
		{
			TheGazetteServiceProcessor serviceProcessor = new TheGazetteServiceProcessor();
			noticeList = serviceProcessor.getAllInsolvencyNoticesByCompanyNumber(companyNumber, companyName);
			httpResponseStatus = HttpStatus.OK;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		response = new ResponseEntity<Object>(noticeList, httpResponseStatus);
		return response;
	}

	@PostMapping(path = SecurityConstants.CALCULATE_RISK_LINK, consumes = MediaType.APPLICATION_JSON)
	public ResponseEntity<Business> riskAnalysis(HttpEntity<byte[]> requestEntity)
	{
		ResponseEntity<Business> response = null;
		HttpStatus httpResponseStatus = HttpStatus.INTERNAL_SERVER_ERROR;
		Business business = null;
		try
		{
			business = new ObjectMapper().readValue(new String(requestEntity.getBody()), Business.class);
			RiskAnalyser riskAnalyser = new RiskAnalyser();
			riskAnalyser.getRiskScoreOfBusiness(business);
			httpResponseStatus = HttpStatus.OK;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		response = new ResponseEntity<Business>(business, httpResponseStatus);
		return response;
	}

	@GetMapping(path = SecurityConstants.IS_PERSON_WITH_INSOLVENCY_NOTICES_LINK, params = { SecurityConstants.COMPANY_NUMBER,
			SecurityConstants.COMPANY_NAME, SecurityConstants.FIRST_NAME, SecurityConstants.MIDDLE_NAME, SecurityConstants.LAST_NAME,
			SecurityConstants.POST_CODE })
	public @ResponseBody ResponseEntity<Object> isPersonWithInsolvencyNotices(
			@RequestParam(value = SecurityConstants.COMPANY_NUMBER) String companyNumber,
			@RequestParam(value = SecurityConstants.COMPANY_NAME) String companyName,
			@RequestParam(value = SecurityConstants.FIRST_NAME) String firstname,
			@RequestParam(value = SecurityConstants.MIDDLE_NAME) String middlename,
			@RequestParam(value = SecurityConstants.LAST_NAME) String surname,
			@RequestParam(value = SecurityConstants.POST_CODE) String postcode)
	{

		ResponseEntity<Object> response = null;
		PersonWithInsolvencyNoticeResponse insolvencyResponse = new PersonWithInsolvencyNoticeResponse();
		HttpStatus httpResponseStatus = HttpStatus.INTERNAL_SERVER_ERROR;
		try
		{
			CompaniesHouseServiceProcessor serviceProcessor = new CompaniesHouseServiceProcessor();
			TheGazetteServiceProcessor gazetteServiceProcessor = new TheGazetteServiceProcessor();
			insolvencyResponse = gazetteServiceProcessor.getInsolvencyNoticesOfUser(firstname, surname, middlename,
					postcode);
			if (insolvencyResponse == null)
			{
				insolvencyResponse = new PersonWithInsolvencyNoticeResponse();
			}
			insolvencyResponse.setDisqualified(serviceProcessor.isDisqualified(companyNumber, companyName, firstname,
					middlename, surname, postcode));
			httpResponseStatus = HttpStatus.OK;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		response = new ResponseEntity<Object>(insolvencyResponse, httpResponseStatus);
		return response;
	}
}
