/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.secure.ae.processor;

import java.util.HashMap;

import javax.naming.NamingException;
import javax.naming.directory.SearchResult;

import com.kpmg.secure.ae.utils.LdapHelper;
import com.kpmg.secure.ae.utils.LdapInfo;
import com.kpmg.secure.ae.utils.SecurityConstants;

public class LDAPProcessor {
	
	private LdapInfo ldapConnectionInfo;
	private LdapHelper ldapHelper;
	
	public LDAPProcessor() {
		this.ldapConnectionInfo = new LdapInfo(SecurityConstants.LDAP_PRINCIPAL, SecurityConstants.LDAP_SECRET, SecurityConstants.LDAP_SERVER_URL);
		this.ldapHelper = new LdapHelper(this.ldapConnectionInfo);
	}
	
	public boolean isDeviceAlreadyRegistered(String applicationName) throws NamingException {
		SearchResult searchResult = ldapHelper.findClientByApplicationName(applicationName);
		if(searchResult == null) {
			return false;
		}
		return true;
	}
	
	public boolean createNewDevice(String applicationName, String clientId) throws NamingException {
		boolean result = false;
		if(!isDeviceAlreadyRegistered(applicationName)) {
			String dn = "cn="+applicationName+","+SecurityConstants.LDAP_OU_AECLIENTS;
			HashMap<String,String> attributes = new HashMap<String,String>();
			attributes.put(SecurityConstants.LDAP_ATTR_SERIAL_NUMBER	,clientId);
			
			result = ldapHelper.addEntry(dn, attributes);
		}
		return result;
	}

	public boolean isValidDevice(String applicationName, String clientKey) throws NamingException {
		boolean result = false;
		SearchResult searchResults = ldapHelper.findClientByApplicationNameAndClientKey(applicationName, clientKey);
		if (searchResults == null) {
			System.out.println("No matching device found.");
		} else {
			result = true;
		}
		return result;
	}
}
