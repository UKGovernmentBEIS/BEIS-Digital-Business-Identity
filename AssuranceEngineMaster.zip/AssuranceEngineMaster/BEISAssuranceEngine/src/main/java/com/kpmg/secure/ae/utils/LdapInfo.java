/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.secure.ae.utils;

public class LdapInfo
{
	String principal;
	String credentials;
	String serverUrl;
	
	
	public LdapInfo(String principal, String credentials, String serverUrl)
	{
		super();
		this.principal = principal;
		this.credentials = credentials;
		this.serverUrl = serverUrl;
	}
	
	public String getPrincipal()
	{
		return principal;
	}
	public void setPrincipal(String principal)
	{
		this.principal = principal;
	}
	public String getCredentials()
	{
		return credentials;
	}
	public void setCredentials(String credentials)
	{
		this.credentials = credentials;
	}
	public String getServerUrl()
	{
		return serverUrl;
	}
	public void setServerUrl(String serverUrl)
	{
		this.serverUrl = serverUrl;
	}
	
	
}
