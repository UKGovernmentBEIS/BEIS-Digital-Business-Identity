/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.secure.ae.utils;

public interface SecurityConstants {

	public static final String AUTH_LOGIN_URL = "/api/authenticate";

    // Signing key for HS512 algorithm
    // You can use the page http://www.allkeysgenerator.com/ to generate all kinds of keys
    public static final String JWT_SECRET = "n2r5u8x/A%D*G-KaPdSgVkYp3s6v9y$B&E(H+MbQeThWmZq4t7w!z%C*F-J@NcRf";

    // JWT token defaults
    public static final String TOKEN_HEADER = "Authorization";
    public static final String TOKEN_PREFIX = "Bearer ";
    public static final String TOKEN_TYPE = "JWT";
    public static final String TOKEN_ISSUER = "secure-api";
    public static final String TOKEN_AUDIENCE = "secure-app";
    
    public static final String LDAP_PRINCIPAL ="cn=Directory Manager";
	public static final String LDAP_SECRET = "<LDAP_SERVER_SECRET>";
	public static final String LDAP_SERVER_URL = "ldap://<LDAP_SERVER_HOSTNAME>:<LDAP_SERVER_PORT>";
	public static final String LDAP_OU_AECLIENTS = "ou=aeclients,dc=mvpfedhub,dc=com";
	public static final String LDAP_ATTR_SERIAL_NUMBER = "serialNumber";
	public static final String CLIENT_ID = "client_id";  

	public static final String CH_SEARCH_COMPANY_URL = "https://api.companieshouse.gov.uk/search/companies";
	public static final String CH_SEARCH_DISQUALIFIED_OFFICERS_URL = "https://api.companieshouse.gov.uk/search/disqualified-officers";
	public static final String CH_SEARCH_OFFICERS_URL = "https://api.companieshouse.gov.uk/search/officers";
	public static final String CH_SEARCH_OFFICERS_BY_COMPANY_NUMBER_URL = "https://api.companieshouse.gov.uk/company/{company_number}/officers";

	public static final String IS_PERSON_WITH_INSOLVENCY_NOTICES = "/isPersonWithInsolvencyNotices";
	public static final String CALCULATE_RISK = "/calculate/risk";
	public static final String INSOLVENCY_NOTICE = "/insolvency/notice";
	public static final String VERIFY_BUSINESSATTRIBUTES = "/verify/businessattributes";
	public static final String PSC = "/psc";
	public static final String POST_CODE = "postCode";
	public static final String LAST_NAME = "lastName";
	public static final String MIDDLE_NAME = "middleName";
	public static final String FIRST_NAME = "firstName";
	public static final String COMPANY_NAME = "companyName";
	public static final String COMPANY_NUMBER = "companyNumber";
	public static final String IS_BUSINESS_OWNER = "/isBusinessOwner/";
	public static final String SEARCH_OFFICERS_BY_COMPANY_NUMBER = "/searchOfficersByCompanyNumber/";
	public static final String SEARCH_STRING = "searchString";
	public static final String SEARCH_BY_NAME = "/searchByName/";

	public static final String IS_PERSON_WITH_INSOLVENCY_NOTICES_LINK = "isPersonWithInsolvencyNotices";
	public static final String CALCULATE_RISK_LINK = "/calculateRisk";
	public static final String GET_INSOLVENCY_NOTICES = "getInsolvencyNotices";
	public static final String VALIDATE_BUSINESS = "/validateBusiness";
	
	public static final String GET_PSC_BY_CRN = "getPSCByCRN";
	public static final String IS_BUSINESS_OWNER_LINK = "isBusinessOwner";
	public static final String SEARCH_OFFICERS_BY_COMPANY_NUMBER_LINK = "searchOfficersByCompanyNumber";
	public static final String SEARCH_COMPANY_BY_NAME = "searchCompanyByName";
	public static final String API_V1 = "/api/v1";
	public static final String DEVICE = "device";
	public static final String TOP = "top";
	public static final String OBJECT_CLASS = "objectClass";
	public static final String SIMPLE = "simple";
	public static final String COM_SUN_JNDI_LDAP_LDAP_CTX_FACTORY = "com.sun.jndi.ldap.LdapCtxFactory";
}
