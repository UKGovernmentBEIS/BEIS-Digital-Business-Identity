/**
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.kpmg.secure.ae.filters;

import java.io.IOException;

import javax.naming.NamingException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.util.StringUtils;

import com.kpmg.secure.ae.processor.LDAPProcessor;
import com.kpmg.secure.ae.utils.SecurityConstants;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.security.SignatureException;

public class JwtAuthorizationFilter extends BasicAuthenticationFilter
{

	public JwtAuthorizationFilter(AuthenticationManager authenticationManager)
	{
		super(authenticationManager);
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws IOException, ServletException
	{
		UsernamePasswordAuthenticationToken authentication = getAuthentication(request);
		if (authentication == null)
		{
			filterChain.doFilter(request, response);
			return;
		}
		SecurityContextHolder.getContext().setAuthentication(authentication);
		filterChain.doFilter(request, response);
	}

	private UsernamePasswordAuthenticationToken getAuthentication(HttpServletRequest request)
	{
		String token = (String) request.getHeader(SecurityConstants.TOKEN_HEADER);
		String clientKey = (String) request.getParameter(SecurityConstants.CLIENT_ID);

		if (!StringUtils.isEmpty(token) && token.startsWith(SecurityConstants.TOKEN_PREFIX))
		{
			try
			{
				byte[] signingKey = SecurityConstants.JWT_SECRET.getBytes();

				Jws<Claims> parsedToken = Jwts.parser().setSigningKey(signingKey)
						.parseClaimsJws(token.replace(SecurityConstants.TOKEN_PREFIX, ""));

				String applicationName = parsedToken.getBody().getSubject();

				if (!StringUtils.isEmpty(applicationName) && !StringUtils.isEmpty(clientKey))
				{
					LDAPProcessor processor = new LDAPProcessor();
					if (processor.isValidDevice(applicationName, clientKey))
					{
						return new UsernamePasswordAuthenticationToken(applicationName, null, null);
					}
				}
			}
			catch (ExpiredJwtException exception)
			{
				System.err.println("Request to parse expired JWT : {} failed : {} Token :: " + token + " Exception :: "
						+ exception.getMessage());
			}
			catch (UnsupportedJwtException exception)
			{
				System.err.println("Request to parse unsupported JWT : {} failed : {} Token :: " + token
						+ " Exception :: " + exception.getMessage());
			}
			catch (MalformedJwtException exception)
			{
				System.err.println("Request to parse invalid JWT : {} failed : {} Token :: " + token + " Exception :: "
						+ exception.getMessage());
			}
			catch (SignatureException exception)
			{
				System.err.println("Request to parse JWT with invalid signature : {} failed : {} Token :: " + token
						+ " Exception :: " + exception.getMessage());
			}
			catch (IllegalArgumentException exception)
			{
				System.err.println("Request to parse empty or null JWT : {} failed : {} Token :: " + token
						+ " Exception :: " + exception.getMessage());
			}
			catch (NamingException e)
			{
				e.printStackTrace();
			}
		}
		return null;
	}

}
